<?php
  include("../homepage/session.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
  <style>

    .requestbody {
    font-family: "Urbanist", sans-serif;
    background-color: #e4f2d7;
    padding: 20px;
    }

  .form-container {
    max-width: 600px;
    margin: 0 auto;
    margin-top: -20px;
    height: 480px;
    background-color: #DDEDA4;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(77, 219, 21, 0.1);
  }

  .form-group {
    margin-bottom: 15px;
    color: rgb(53, 94, 59);
  }

  label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
    font-size: 20px;
  }

  input[type="date"],
  input[type="time"] {
    border: 2px solid #ffb01d;
    height: 10px;
    width: 200px;
    border-radius: 15px;
    padding: 10px;
    text-align: center;
  }

  input[type="text"],
  textarea {
    width: calc(100% - 22px); 
    height: calc(100% + 2px); 
    padding: 8px;
    border: 1px solid #cccccc;
    border-radius: 4px;
    box-sizing: border-box;
  }

  .button {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 16px;
    margin-left: 230px;
  }

  .button:hover {
    background-color: white;
    color: #4CAF50;
  }

  .background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../homepage/images/volunteer-req.jpg');
        background-size: cover;
        background-position: center;
        filter: brightness(87%); 
        z-index: -1;
        }

  #slider {
    width: 220px;
  }

  footer {
    position: fixed;
  }
    
  </style>
<body class="requestbody">
  <div>
    <?php
      include 'header_footer/seniornavbar.php';
    ?>
  </div>
  <br>
  <div class="form-container">
    <form action='../homepage/php/reqinsert.php' method='post'>
      <div class="form-group">
        <label for="assistance">Assistance Required</label>
        <textarea type="text" id="assistance" name='assistance' placeholder="Describe your issue"></textarea>
      </div>
      <div class="form-group">
        <label for="date">Date</label>
        <input type="date" name='date' id="date">
      </div>
      <div class="form-group">
        <label for="location">Location</label>
        <textarea type="text" id="location" name='location' placeholder="Enter your location"></textarea>
      </div>
      <div class="form-group">
        <label for="time">Time</label>
        <input type="time" name='time' id="time">
      </div>
      <div class="form-group">
        <label for="slider">Urgency</label>
        <input type="range" id="slider" name='priority' min="1" max="5">
      </div>
      <div class="form-group">
        <button type="submit" name='reqBtn' class="button">Send Request</button>
      </div>
    </form>
    <div class="background"></div>
  </div>
  <div>
    <?php
      include 'header_footer/seniorfooter.php';
    ?>
  </div>
</body>
</html>

