<?php
  include("../homepage/session.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Status Page</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <style>
      .statusbody {
        font-family: 'Urbanist', sans-serif;
      }
      table {
        border-collapse: collapse;
        width: 100%;
      }
      th, td {
        padding: 8px;
        text-align: left;
      }
      th {
        background-color: white;
      }
      tr:nth-child(even) {
        background-color: #c6c6c6a1;
      }
      .complete-btn {
      padding: 10px 20px;
      border: none;
      border-radius: 20px;
      background-color: #4CAF50;
      color: white;
      cursor: pointer;
      }
      .complete-btn:hover {
      background-color: #45a049;
      }
      .pending-btn {
      padding: 10px 20px;
      border: none;
      border-radius: 20px;
      background-color: yellowgreen;
      color: white;
      cursor: pointer;
      }
      .pending-btn:hover {
      background-color: yellowgreen;
      }

      footer {
        position: fixed;
      }

    </style>
</head>
<body class='statusbody'>
  <header>
    <?php
      include 'header_footer/volunteernavbar.php';
    ?>
  </header>
  <table>
    <tr>
        <th>Name</th>
        <th>Details</th>
        <th>Date/Time</th>
        <th>Location</th>
        <th>Completion</th>
    </tr>
    <?php
      include('../homepage/php/conn.php');
      $sql = "SELECT * FROM user WHERE ID=" . $_SESSION['mySession'];
      $sqlResult = mysqli_query($con, $sql);
      $row = mysqli_fetch_assoc($sqlResult);
      $_SESSION['IC'] = $row['IC_Number'];

      $volunteer = "SELECT Volunteer_ID from volunteer WHERE IC_Number=" . $_SESSION['IC'];
      $volunteerResult = mysqli_query($con, $volunteer);
      $volunteerRow = mysqli_fetch_assoc($volunteerResult);

      $query = "SELECT Senior_Name, Assistance, Location, Time, Date, Status FROM status WHERE Volunteer_ID=" . $volunteerRow['Volunteer_ID'];
      $queryResult = mysqli_query($con, $query);

      while ($row = mysqli_fetch_assoc($queryResult)) {
          echo '<tr>';
          echo '<td>' . htmlspecialchars($row['Senior_Name']) . '</td>';
          echo '<td>' . htmlspecialchars($row['Assistance']) . '</td>';
          echo '<td>';
          echo '<p>' . htmlspecialchars($row['Date']) . '</p>';
          echo '<p>' . htmlspecialchars($row['Time']) . '</p>';
          echo '</td>';
          echo '<td>' . htmlspecialchars($row['Location']) . '</td>';
          echo '<td>';
          if ($row['Status'] == 'Completed') {
              echo '<button class="complete-btn">Complete</button>';
          } elseif ($row['Status'] == 'Pending') {
              echo '<button class="pending-btn">Pending</button>';
          }
          echo '</td>';
          echo '</tr>';
      }
    ?>

  </table>
  <footer>
    <?php
      include 'header_footer/volunteerfooter.php';
    ?>
  </footer>    

</body>
</html>