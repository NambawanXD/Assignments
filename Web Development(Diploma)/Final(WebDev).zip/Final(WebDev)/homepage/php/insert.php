<?php
if (isset($_POST['signupBtn'])) {
 include('conn.php');

 if ($_POST['password'] != $_POST['confirm_password']) {
   echo "<script>alert('Passwords do not match. Please try again.');window.location.href='../userlogin/signup.html';</script>";
   exit();
 }

 $sql="INSERT INTO user (IC_Number, Email, First_Name, Last_Name, Password, Address, Phone_Number, Role)
 
 VALUES
 
 ('$_POST[IC]','$_POST[email]','$_POST[first_name]','$_POST[last_name]','$_POST[password]','$_POST[address]','$_POST[tel_num]','$_POST[role]')";
 
 if(!mysqli_query($con,$sql))  {
    die('Error:'.mysqli_error($con));
 }
 else  {
    myRole($con);
    echo '<script>alert("Succesfully Signed Up!");
    window.location.href = "../userlogin/login.php";
    </script>';
 }
 mysqli_close($con);
} else {
   echo"<script>alert('Please fill in all the fields!');window.location.href='../userlogin/signup.html';</script>";
}

function myRole($con) {
   if ($_POST['role'] == 'Volunteer'){
      $sql = "INSERT INTO volunteer (IC_Number) VALUES ('$_POST[IC]')";
   } else if ($_POST['role'] == 'Senior'){
      $sql = "INSERT INTO senior (IC_Number) VALUES ('$_POST[IC]')";
   }
 
   if(!mysqli_query($con,$sql)) {
      die('Error:'.mysqli_error($con));
   }
 }
?>