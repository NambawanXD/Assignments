<?php
session_start();  

if (isset($_POST['reqBtn'])) {
    include('../php/conn.php');

    if (!$con) {
        die('Connection failed: ' . mysqli_connect_error());  
    }

    $sqli = "SELECT * FROM user WHERE ID =" . intval($_SESSION['mySession']);
    $result = mysqli_query($con, $sqli);
  
    if(mysqli_num_rows($result) >  0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['ic'] = $row['IC_Number'];

        $id = "SELECT Senior_ID FROM senior WHERE IC_Number='" . mysqli_real_escape_string($con, $_SESSION["ic"]) . "'";
        $name = "SELECT First_Name, Last_Name FROM user WHERE ID=" . intval($_SESSION["mySession"]);
        $idResult = mysqli_query($con, $id);
        $nameResult = mysqli_query($con, $name);
        $idRow = mysqli_fetch_array($idResult);
        $nameRow = mysqli_fetch_array($nameResult);
        
        $sql = "INSERT INTO senior_req (Assistance, Location, Date, Time, Priority, Senior_ID, Name)
                VALUES
                ('" . mysqli_real_escape_string($con, $_POST['assistance']) . "',
                 '" . mysqli_real_escape_string($con, $_POST['location']) . "',
                 '" . mysqli_real_escape_string($con, $_POST['date']) . "',
                 '" . mysqli_real_escape_string($con, $_POST['time']) . "',
                 '" . mysqli_real_escape_string($con, $_POST['priority']) . "',
                 '" . intval($idRow['Senior_ID']) . "',
                 '" . mysqli_real_escape_string($con, $nameRow['First_Name']) . " " . mysqli_real_escape_string($con, $nameRow['Last_Name']) . "')";
    
        if (!mysqli_query($con, $sql)) {
            die('Error: ' . mysqli_error($con));
        } else {
            echo '<script>alert("Succesfully Sent Request!");
            window.location.href = "../seniorrequest.php";
            </script>';
        }
    } else {
        echo "<script>alert('Request was failed to send');window.location.href='../seniorrequest.php';</script>";
    }
}
mysqli_close($con);
?>
