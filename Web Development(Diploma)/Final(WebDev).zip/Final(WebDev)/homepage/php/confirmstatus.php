<?php
  if(isset($_POST['pendingBtn'])) {
    include("conn.php");
    
    if (!$con) {
      die('Connection failed: ' . mysqli_connect_error());   
    }

    $sql = "SELECT ID FROM status WHERE ID=" .$_POST['status_id'];
    $result = mysqli_query($con, $sql);

    if($row = mysqli_fetch_assoc($result)){
      $update = "UPDATE status SET Status='Completed' WHERE ID=" .$_POST['status_id'];
      mysqli_query($con, $update);
      echo "<script>alert('Successfully completed task'); window.location.href='../seniorstatus.php';</script>";
    }else{
      echo "<script>alert('Failed to send request'); window.location.href='../seniorstatus.php';</script>";
      mysqli_close($con);
    }

  } else {
    echo "<script>alert('Failed to send request'); window.location.href='../seniorstatus.php';</script>";
  }
?>
