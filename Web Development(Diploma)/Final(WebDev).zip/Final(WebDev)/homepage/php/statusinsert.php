<?php
session_start();  

if (isset($_POST['acceptBtn'])) {
    include('../php/conn.php');

    if (!$con) {
        die('Connection failed: ' . mysqli_connect_error());  
    }

    $sqli = "SELECT * FROM user WHERE ID =" . intval($_SESSION['mySession']);
    $result = mysqli_query($con, $sqli);
  
    if(mysqli_num_rows($result) >  0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['ic'] = $row['IC_Number'];

        $id = "SELECT Volunteer_ID FROM volunteer WHERE IC_Number=" . intval($_SESSION["ic"]);
        $name = "SELECT First_Name, Last_Name FROM user WHERE ID=" . intval($_SESSION["mySession"]);
        $req = "SELECT * FROM senior_req WHERE Request_ID=" . intval($_POST['senior_req_id']);
        $idResult = mysqli_query($con, $id);
        $nameResult = mysqli_query($con, $name);
        $reqResult = mysqli_query($con, $req);
        $idRow = mysqli_fetch_array($idResult);
        $nameRow = mysqli_fetch_array($nameResult);
        $reqRow = mysqli_fetch_array($reqResult);
        
        $sql = "INSERT INTO status (Assistance, Location, Time, Date, Volunteer_Name, Senior_Name, Volunteer_ID, Senior_ID)
                VALUES
                ('" . mysqli_real_escape_string($con, $reqRow['Assistance']) . "',
                 '" . mysqli_real_escape_string($con, $reqRow['Location']) . "',
                 '" . mysqli_real_escape_string($con, $reqRow['Time']) . "',
                 '" . mysqli_real_escape_string($con, $reqRow['Date']) . "',
                 '" . mysqli_real_escape_string($con, $nameRow['First_Name']) . ' ' . mysqli_real_escape_string($con, $nameRow['Last_Name']) . "',
                 '" . mysqli_real_escape_string($con, $reqRow['Name']) . "',
                 '" . intval($idRow['Volunteer_ID']) . "',
                 '" . intval($reqRow['Senior_ID']) . "' )";    

        if (!mysqli_query($con, $sql)) {
            die('Error: ' . mysqli_error($con));
        } else {
            $deleteQuery = "DELETE FROM senior_req WHERE Request_ID=" . intval($_POST['senior_req_id']);
            $delresult = mysqli_query($con, $deleteQuery);
            if ($delresult == true) {
                echo '<script>alert("Succesfully Accepted Request!");
                window.location.href = "../volunteerstatus.php";
                </script>';
            } else {
                echo "<script>alert('Failed to accept request');window.location.href='../volunteerrequest.php';</script>";
            }
        }
    } else {
        echo "<script>alert('Failed to accept request');window.location.href='../volunteerrequest.php';</script>";
    }
}

if (isset($con)) {
    mysqli_close($con);
} else {
  echo "<script>alert('Failed to accept request');window.location.href='../volunteerrequest.php';</script>";
}
?>
