<?php
function myPassword() {
  if (isset($_POST["verifyBtn"])) {
    include('../php/conn.php');
 
    $IC = $_POST['IC'];
    $email = $_POST['email'];
 
    $sql = "SELECT * FROM user WHERE IC_Number = '$IC' AND Email = '$email'";
    $result = mysqli_query($con, $sql);
 
    if(mysqli_num_rows($result) > 0) {
      $row = mysqli_fetch_assoc($result);
      session_start();
      $_SESSION['ic'] = $row['IC_Number'];
 
      header("Location: ../userlogin/confirmpass.html");
      exit();
    } else {
      echo "<script>alert('IC and Email does not match.'); window.location.href='../userlogin/forgotpass.html';</script>";
    }
 
    mysqli_close($con);
  }
 }
 
 
 if ($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST['loginBtn'])) {
   myLogin();
 } elseif ($_SERVER["REQUEST_METHOD"] == "POST" AND isset($_POST["verifyBtn"])) {
  myPassword();
 }
 
?>
