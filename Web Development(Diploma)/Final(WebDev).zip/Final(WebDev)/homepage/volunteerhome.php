<?php
  include("../homepage/session.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
</head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<style>
  body, html {
  height: 100%;
  margin: 0;
  font-family: 'Urbanist', sans-serif;
  background-color: #355e3b;
  }

  .example::-webkit-scrollbar {
  display: none;
  }

  .bg-image {
  height: 100%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  }
  .img1 { background-image: url("images/pic1.jpg"); }
  .img2 { background-image: url("images/pic2.jpg"); }
  .img3 { background-image: url("images/pic3.jpeg"); }

  /* Position text in the middle of the page/image */
  .bg-text {
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0, 0.6); /* Black w/opacity/see-through */
  color: white;
  font-weight: bold;
  font-size: 80px;
  position: fixed; /* Stay fixed */
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 3000px;
  padding: 20px;
  text-align: center;
  }

  footer {
    background-color: ##355e3b;
    position: relative;
  }

</style>

<body id="homebody">
  <div>
    <?php
      include 'header_footer/volunteernavbar.php'
    ?>
  </div>
  <div class="bg-image img1"></div>
  <div class="bg-image img2"></div>
  <div class="bg-image img3"></div>

  <div class="bg-text">Caring Volunteers, Happy Seniors<br> - Together, We Thrive</div>

  <footer>
      <?php
        include 'header_footer/volunteerfooter.php';
      ?>
  </footer>
  <br>
</body>
</html>