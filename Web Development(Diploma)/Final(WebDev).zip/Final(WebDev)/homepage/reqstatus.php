<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up or Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Urbanist', sans-serif;
            background-color: #ffe5b4; 
            margin:   0;
            padding:   0;
            display: flex;
            justify-content: center;
            align-items: center;
            height:   100vh;
        }

        .container {
            background-color: #f0f0f0; 
            border-radius:   15px; 
            padding:   20px;
            box-shadow:   0   0   10px rgba(0,   0,   0,   0.1);
            width:   80%;
            max-width:   500px;
        }

        .content {
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom:   10px;
        }

        p {
            color: #666;
            margin-bottom:   20px;
        }

        .buttons {
            display: flex;
            justify-content: center;
        }

        .btn {
            display: inline-block;
            padding:   10px   20px;
            color: #fff;
            text-decoration: none;
            margin:   0   10px;
        }

        .signup {
            background-color: #007bff;
        }

        .login {
            background-color: #6c757d;
        }

        .btn:hover {
            opacity:   0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <h1>Welcome to SeniorConnect</h1>
            <p>Please sign up or login to continue.</p>
            <div class="buttons">
                <a href="../homepage/userlogin/signup.php" class="btn signup">Sign Up</a>
                <a href="../homepage/userlogin/login.php" class="btn login">Login</a>
            </div>
        </div>
    </div>
</body>
</html>

