<?php
  include("../homepage/session.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Status Page</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<style>
    .statusbody {
      font-family: 'Urbanist', sans-serif;
    }
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: white;
    }
    tr:nth-child(even) {
      background-color: whitesmoke;
    }
    .complete-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    background-color: #4CAF50;
    color: white;
    cursor: pointer;
    }
    .complete-btn:hover {
    background-color: #45a049;
    }
    .pending-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    background-color: yellowgreen;
    color: white;
    cursor: pointer;
    }
    .pending-btn:hover {
    background-color: yellowgreen;
    }

    .icon {
      vertical-align: middle;
      height: 20px;
      width: 20px;
      display: block;
      }

    footer {
      position: fixed;
    }

  </style>
  </head>
  <body class='statusbody'>
    <header>
      <?php
        include 'header_footer/seniornavbar.php';
      ?>
    </header>
    <table>
      <tr>
          <th>Name</th>
          <th>Details</th>
          <th>Date/Time</th>
          <th>Location</th>
          <th>Completion</th>
      </tr>
      <?php
        include('../homepage/php/conn.php');
        $sql = "SELECT * FROM user WHERE ID=" . $_SESSION['mySession'];
        $sqlResult = mysqli_query($con, $sql);
        $userRow = mysqli_fetch_assoc($sqlResult);
        $_SESSION['IC'] = $userRow['IC_Number'];

        $senior = "SELECT Senior_ID from senior WHERE IC_Number=" . $_SESSION['IC'];
        $seniorResult = mysqli_query($con, $senior);
        $seniorRow = mysqli_fetch_assoc($seniorResult);

        $query = "SELECT ID, Volunteer_Name, Assistance, Location, Time, Date, Status FROM status WHERE Senior_ID=" . $seniorRow['Senior_ID'];
        $queryResult = mysqli_query($con, $query);

        while ($statusRow = mysqli_fetch_assoc($queryResult)) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($statusRow['Volunteer_Name']) . '</td>';
            echo '<td>' . htmlspecialchars($statusRow['Assistance']) . '</td>';
            echo '<td>';
            echo '<p>' . htmlspecialchars($statusRow['Date']) . '</p>';
            echo '<p>' . htmlspecialchars($statusRow['Time']) . '</p>';
            echo '</td>';
            echo '<td>' . htmlspecialchars($statusRow['Location']) . '</td>';
            echo '<td>';
            echo '<form action="../homepage/php/confirmstatus.php" method="post">';
            echo '<input type="hidden" name="status_id" value="' . htmlspecialchars($statusRow['ID']) . '">';
            if ($statusRow['Status'] == 'Completed') {
                echo '<button class="complete-btn">Complete</button>';
            } elseif ($statusRow['Status'] == 'Pending') {
                echo '<button type="submit" class="pending-btn" name="pendingBtn" >Pending</button>';
            }
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
      ?>


    </table>
    <footer>
      <?php
        include 'header_footer/seniorfooter.php';
      ?>
    </footer>    

  </body>
</html>