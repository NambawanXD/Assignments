<!DOCTYPE html>
<html lang="en">
<head>
    <title>About Us</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
        <style>
      .aboutusbody {
      font-family: "Urbanist", sans-serif;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      background-color: #edc09d;
      font-weight: bold;
      }

      section {
      padding: 20px;
      }

      .container {
      max-width: 1200px;
      margin: 0 auto;
      display: flex;
      align-items: flex-start;
      flex-wrap: wrap;
      }

      .mission-heading {
      flex: 1;
      text-align: center;
      padding-right: 20px;
      }

      .mission-heading h1 {
      margin-bottom: 0.5em; 
      text-decoration: underline;
      color: #fefefb;
      letter-spacing: 1.5px;
      }

      .mission-heading h2 {
      font-size: 20px; 
      font-weight: normal;
      color: #f7f7f7; 
      margin-top: 0; 
      text-align: justify;
      letter-spacing: 1.5px;
      }

      .mission-images {
      flex-basis: 500px;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      padding-left: 20px;
      }

      .mission-images img {
      width: 100%;
      margin-bottom: 10px;
      }

      .mission-images img:last-child {
      margin-bottom: 0;
      }

      .background {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      margin-bottom: 100px;
      background-image: url('../homepage/images/Background_About_Us.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      background-position: center;
      filter: brightness(50%); 
      z-index: -1;
      }

      a {
      color: yellowgreen;
      }

      .account:hover {
        color: white;
      }

      footer {
      text-align: center;
      position: relative;
      }
      

      
    </style>
</head>
<body class='aboutusbody'>
  <header>
    <?php
      include 'header_footer/navbar.html';
    ?>
  </header>   
  <section>
      <div class="container">
          <div class="mission-heading">
              <h1>ABOUT US</h1>
              <br>
              <h2>Welcome to SeniorConnect, a dedicated web application designed to connect compassionate volunteers with elderly individuals in need of assistance. Our platform is committed to fostering a supportive community where users can offer help, share experiences, and enhance the well-being of seniors.</h2>
              <br>
              <br>
              <br>
              <h1>
                  OBJECTIVES
              </h1>
              <br>
              <h2>
                  We aim to provide a user-friendly interface that caters to both volunteers and seniors, ensuring accessibility for individuals with varying levels of technological proficiency.
                  Our secure user registration system captures detailed profiles, including skills, availability, and preferences, to facilitate efficient matching between volunteers and seniors based on their needs, location, and availability.
              </h2>
              <h2>
                  SeniorConnect incorporates a task management system that allows volunteers and seniors to organize, track, and prioritize assistance tasks.
                  Our platform features tools for setting task deadlines, reminders, and feedback mechanisms to ensure efficient communication and task management.
              </h2>
              <br>
              <br>
              <br>
              <h1>JOIN US NOW!</h1>
              <br>
              <h2>Whether you're a compassionate volunteer looking to lend a helping hand or a senior seeking support and companionship, SeniorConnect welcomes you with open arms. Together, let's create a community where kindness knows no bounds, and every act of generosity makes a world of difference. Join SeniorConnect today and be a part of something truly special.</h2>
              <a href="../homepage/reqstatus.php" class='account'> Create an Account
              </a>
          <br>
          <br>
          <br>

          </div>
          <div class="mission-images">
              <img src="../homepage/images/AboutUs_-_Img_1.jpg" alt="Image 1">
              <img src="../homepage/images/AboutUs_-_Img_2.jpg" alt="Image 2">
              <img src="../homepage/images/AboutUs_-_Img_3.jpg" alt="Image 3">
              <div class="background"></div>


          </div>
      </div>
  </section>
  <footer>
      <?php
        include 'header_footer/footer.html';
      ?>
  </footer>
</body>
</html>