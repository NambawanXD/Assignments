<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <style>
    body {
    background-color:#AFC8AD;
    transform: scale(1.3);
    transform-origin: 0 0;
    font-family: 'Urbanist', sans-serif;
    margin-left: 575.6px;
    margin-top: 100px;
    overflow-x: hidden;
    }

    #sign_up {
    border: 2px solid #f3ff6f;
    height: 30px;
    width: 100px;
    border-radius: 15px;
    color: #f3ff6f;
    background-color:#ffb01d;
    font-weight: bold;
    margin-left: 220px;
    transition: height 0.2s, width 0.2s;
    cursor: pointer;
    }

    #sign_up:hover {
    cursor:pointer;
    height: 40px;
    width: 110px;
    }

    #sign_up:active {
    opacity: 0.6;
    }

    input {
    border: 2px solid #ffb01d;
    height: 10px;
    width: 200px;
    border-radius: 15px;
    padding: 10px;
    text-align: center;
    }

    .icon {
    vertical-align: middle;
    height: 20px;
    width: 20px;
    margin-left: 10px;
    }

    .ibox {
    margin-right: 10px;
    }
    
    #rolecheck {
    display: flex;
    justify-content: space-between;
    margin-left: 100px;
    }

    input[type="radio"] {
    vertical-align: middle;
    margin-left: -150px;
    margin-top: 5px;
    background-color: #304674;
    }

    .ibox::placeholder {
    color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    opacity: 0.5s
    }

    .ibox:focus::placeholder {
    opacity: 0;
    }

  </style>

</head>

<body>
  <div style="float: left;">
    <h1 style="clear: left; margin-left: -300px; margin-top: 80px;">
      Sign Up to<br><span style="color:#e88f1a; font-family:'Times New Roman', Times, serif;">Senior</span><span style="color:#f3ff6f; font-family:'Times New Roman', Times, serif; font-style:italic;">Connect</span>
    </h1>
  </div>

  <div style="display: flex; align-items: center;">
    <form action="../php/insert.php" method="post">
      <label>
        <img src="../icons/user-icon.png" alt="user_icon" class="icon">
        <input type="text" id="u_fname" class='ibox' name="first_name" required autocomplete="off" placeholder="First Name">
      </label>
      
      <label>
        <img src="../icons/user-icon.png" alt="user_icon" class="icon">
        <input type="text" id="u_lname" class='ibox'  name="last_name" required autocomplete="off" placeholder="Last Name">
      </label>
      <br><br>
      <label>
        <img src="../icons/phone-icon.png" alt="tel_icon" class="icon">
        <input type="tel" id="u_tel" class='ibox'  name="tel_num" required autocomplete="off" placeholder="+60|        Tel">
      </label>
      
      <label>
        <img src="../icons/email-icon.webp" alt="email_icon" class="icon">
        <input type="email" id="u_email" class='ibox'  name="email" required autocomplete="off" placeholder="Email Address">
      </label>
      <br><br>
      <label>
        <img src="../icons/location-icon.png" alt="location_icon" class="icon">
        <input type="text" id="u_address" class='ibox'  name="address" required autocomplete="off" placeholder="Address" maxlength="255">
      </label>
      
      <label>
        <img src="../icons/fingerprint-icon.png" alt="fingerprint_icon" class="icon">
        <input type="text" id="u_ic" class='ibox'  name="IC" required autocomplete="off" placeholder="IC Number">
      </label>
      <br><br>
      <label>
        <img src="../icons/lock-icon.png" alt="lock_icon" class="icon">
        <input type="password" id="u_pass" class='ibox'  name="password" required autocomplete="off" placeholder="Password">
      </label>
      
      <label>
        <img src="../icons/lock-icon.png" alt="lock_icon" class="icon">
        <input type="password" id="u_conpass" class='ibox' name="confirm_password" required autocomplete="off" placeholder="Confirm Password">
      </label>
      <br><br><br>
      <label id='rolecheck' style="font-weight: bold">
        Volunteer <input type="radio" id="u_volunteer" class='ibox' name="role" value="Volunteer" required>
        Senior <input type="radio" id="u_senior" class='ibox' name="role" value="Senior" required> 
      </label>
      <br><br>
      <button type="submit" name="signupBtn" id='sign_up'>Sign Up</button>
    </form> 
  </div>

</body>
</html>