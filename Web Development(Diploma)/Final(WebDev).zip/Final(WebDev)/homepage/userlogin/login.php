<?php
    session_start();
    include '../php/conn.php';
    if (isset($_POST['loginBtn'])) {     
      $email = $_POST['email'];
      $password = $_POST['password'];
   
      $sql = "SELECT * FROM user WHERE Email = '$email' AND Password = '$password'";
      $result = mysqli_query($con, $sql);
   
      $row = mysqli_fetch_assoc($result);
      $rowcount = mysqli_num_rows($result);

      if ($rowcount ==   1){
          $_SESSION["mySession"] = $row['ID'];
         
          if ($row['Role'] === 'Volunteer') {
              header("location: ../volunteerhome.php");
              exit();
          } elseif ($row['Role'] === 'Senior') {
              header("location: ../seniorhome.php");
              exit();}
          
      } else {
        echo "<script>alert('Email and Password does not match.'); window.location.href='../userlogin/login.php';</script>";
      }
   
      mysqli_close($con);
    }   
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <style>

    body {
    background-color: #afc8adfa;
    transform: scale(1.5);
    transform-origin: 0 0;
    font-family: 'Urbanist', sans-serif;
    margin-left: 575.6px;
    margin-top: 100px;
    overflow-x: hidden;
    }

    #u_email {
    border: 2px solid #ffb01d;
    height: 10px;
    width: 200px;
    border-radius: 15px;
    padding: 10px;
    }

    #u_email::placeholder, #u_pass::placeholder {
    color: rgba(0, 0, 0, 0.5);
    transition: opacity 0.3s;
    }

    #u_email:focus::placeholder, #u_pass:focus::placeholder {
    opacity: 0;
    }

    #u_pass {
    border: 2px solid #ffb01d;
    height: 10px;
    width: 200px;
    border-radius: 15px;
    padding: 10px;
    position: relative; 
    z-index: 0;
    }

    #forget_link {
    font-size: 12px;
    font-weight: bold;
    margin-left: 175px;
    font-style: italic;
    color: #8a3324;
    text-decoration: none;
    cursor: pointer;
    position: relative; 
    z-index: 1;
    top: 22px;
    }

    #forget_link:hover {
    color: grey;
    text-decoration: underline;
    }

    #sign_in {
    border: 2px solid #f3ff6f;
    height: 30px;
    width: 100px;
    border-radius: 15px;
    color: white;
    background-color: #ffb01d;
    font-weight: bold;
    margin-left: 63px;
    transition: height 0.2s, width 0.2s;
    cursor: pointer;
    }

    #sign_in:hover {
    cursor:pointer;
    height: 40px;
    width: 110px;
    }

    #sign_in:active {
    opacity: 0.6;
    }

    #sign_up {
    color: #8a3324;
    text-decoration: none;
    cursor: pointer;
    font-weight: bold;
    }

    #sign_up:hover {
    color: grey;
    text-decoration: underline;
    }

    .icon {
    vertical-align: middle;
    height: 20px;
    width: 20px;
    }

    .password-container {
    position: relative;
    width: 200px;
    height: 10px;
    }

    .password-container input {
    width: 100%;
    height: 100%;
    padding-right: 20px; /
    }

    .password-container .eyeicon {
    position: absolute;
    top: 60%;
    right: -10px;
    width: 20px;
    height: 20px;
    cursor: pointer;
    }



  </style>

</head>

<body>
  <div>
    <h1 id="web_title" >
      <span style="color:#e88f1a; font-family:'Times New Roman', Times, serif;">Senior</span><span style="color:#f3ff6f; font-style:italic; font-family:'Times New Roman', Times, serif;">Connect</span>
    </h1>
    <form method="post">
      <div>
        <label>
          <img src="../icons/email-icon.webp" alt="email_icon" class="icon">
          <span style="color:#8a3324;">Email</span>
          <br>
          <input type='email' id="u_email" name="email" placeholder='Email Address' required autocomplete="off" >
        </label>
      </div>
      <br>
      <div>
        <label>
          <img src="../icons/lock-icon.png" alt="lock-icon" class="icon">
          <span style="color:#8a3324;">Password</span>
          <br>
          <div class="password-container">
            <input type="password" id="u_pass" name="password" placeholder='Password' required autocomplete="off">
            <img src="../icons/eye-close-icon.png" id="eyeicon" class="eyeicon" >
          </div>
        </label>
      </div>
      <a href="forgotpass.html" id="forget_link" >Forgot?</a>
      <br><br><br>
      <button type="submit" name="loginBtn" id="sign_in">Sign In</button>
    </form>
    <br>
    <p>
      Haven't joined us yet?
      <a href="signup.php" id='sign_up'>Sign Up</a>    
    <p>
  </div>  
  <div>
    <script>
      let eyeicon = document.getElementById("eyeicon")
      let password = document.getElementById("u_pass")

      eyeicon.onclick = function() {
        togglePasswordVisibility(eyeicon, password);
      }

      function togglePasswordVisibility(eyeicon, password) {
        if (password.type === "password" ) {
          password.type = "text";
          eyeicon.src = "../icons/eye-open-icon.png";
        } else {
          password.type = "password";
          eyeicon.src = "../icons/eye-close-icon.png"
        }
      }
    </script>
  </div>
</body>
</html>