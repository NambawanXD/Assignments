<?php
  session_start();

  if (isset($_POST['resetBtn'])) {
  include('../php/conn.php');

  $id = $_SESSION['ic'];
  $new_password = $_POST['newpass'];
  $confirm_new_password = $_POST['confirmpass'];

  echo "Session IC: ".$id;
  echo "New Password: ".$new_password;

  if ($new_password !== $confirm_new_password) {
  echo "<script>alert('Passwords do not match.'); window.location.href='../userlogin/confirmpass.html';</script>";
  } else {

  $sql = "UPDATE user SET Password = '$new_password' WHERE IC_Number = '$id'";
  $result = mysqli_query($con, $sql);

  if ($result) {
  echo "<script>alert('Password updated successfully.'); window.location.href='../userlogin/login.php';</script>";
  } else {
  echo "<script>alert('Failed to update password.'); window.location.href='../userlogin/confirmpass.html';</script>";
  }
  }

  mysqli_close($con);
  }
?>
