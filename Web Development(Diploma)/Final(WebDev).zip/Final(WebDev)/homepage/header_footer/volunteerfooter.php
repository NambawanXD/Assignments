<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
  <style>
    #footerbody {
      margin: 0;
      padding: 0
    }

    footer {
    bottom: 0;
    width: 100%;
    background-color: #355e3b;
    margin: 0;
    height: 140px;
    z-index: 1;
    }

    .foot_title {
      text-align: center;
      font-family:'Times New Roman', Times, serif;
    }

    .footer {
    display: inline;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    font-weight: bolder;
    font-size: 16px;
    padding-right: 20px;
    padding-left: 20px;
    color: #ecffdc;
    text-align: center;
    }

    .footer-container {
      text-align: center;
    }

    .menu:visited {
    color: #ecffdc;
    text-decoration: none;
    }

    .menu:link {
      text-decoration: none;
    }

    .menu:hover {
    color: inherit; 
    }

    .menu:active {
    color: inherit; 
    }

  </style>

<body id="footerbody">
  <footer>
    <h1 class="foot_title">
        <span style="color:#e88f1a;">Senior</span><span style="color:#f3ff6f; font-style:italic;">Connect</span>
    </h1>
    <div class="footer-container">
      <ul class="footer">
        <li class="footer">
          <a class="menu" href="volunteerhome.php">
            HOME
          </a>
        </li>
        <li class="footer">
          <a class="menu" href="volunteerrequest.php">
            REQUEST
          </a>
        </li>
        <li  class="footer">
          <a class="menu" href="volunteerstatus.php">
            STATUS
          </a>
        </li>
        <li class="footer">
          <a class="menu" href="volunteeraboutus.php">
            ABOUT US
          </a>
        </li>
        <li  class="footer">
          <a class="menu" href="volunteercontactus.php">
            CONTACT US
          </a>
        </li>
      </ul>
    </div>
    <p class="foot_title">
      <span style="color: white;">
        &copy; 2024 Senior Connect. All rights reserved.
      </span>
    </p>
  </footer>

</body>
</html>