<?php
  include("php/conn.php");
  $sql = "SELECT First_Name, Role FROM user WHERE ID =" .$_SESSION['mySession'];
  $result = mysqli_query($con,$sql);
  while ($row = mysqli_fetch_array($result)){
    $name = $row['First_Name'];
    $role = $row['Role'];
  }
  mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>navbar</title>
</head>

  <style>

    #page_title {
    font-family: 'Times New Roman', Times, serif;
    display: inline;
    margin-left: 40px;
    margin-right: 100px;
    font-size: 30px;
    }

    .navbar{
    display: inline;
    font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    font-weight: bolder;
    font-size: 20px;
    margin-left: 10px;
    margin-right: 15px;
    padding-right: 20px;
    padding-left: 20px;
    color: rgb(236, 255, 220);
    }

    #navbar {
    background-color: white;
    height:fit-content;
    width:fit-content;
    }

    .menu:hover {
    border-bottom: 1px solid white;
    }

    .menu:active {
    color: white;
    text-decoration: none;
    }

    .menu:visited {
    color: inherit;
    text-decoration: none;
    }

    .menu:link {
      text-decoration: none;
    }

    nav {
      background-color: #355e3b;
      margin: 0;
      padding:0;
      padding-top: 10px;
      padding-bottom: 10px; 
      height: 50px;
      width: auto;
    }

    #navbody {
      padding: 0;
      margin: 0;
    }

    #icon {
    vertical-align: middle;
    height: 40px;
    width: 40px;
    padding-right: 50px;
    }

  </style>
<body id="navbody">
  <nav>
    <h1 id="page_title">
      <span style="color:#e88f1a;">Senior</span><span style="color:#f3ff6f; font-style:italic;">Connect</span>
    </h1>
    <ul class="navbar">
      <li class="navbar">
        <a id="home" class="menu" href="seniorhome.php">
          HOME
        </a>
      </li>
      <li class="navbar">
        <a id="req" class="menu" href="seniorrequest.php">
          REQUEST
        </a>
      </li>
      <li  class="navbar">
        <a id="status" class="menu" href='seniorstatus.php'>
          STATUS
        </a>
      </li>
      <li class="navbar">
        <a id="about" class="menu" href="senioraboutus.php">
          ABOUT US
        </a>
      </li>
      <li class="navbar">
        <a id="contact" class="menu" href="seniorcontactus.php">
          CONTACT US
        </a>
      </li>
      <li id="signout" class="navbar">
        <a class='menu' href="../homepage/php/logout.php">
          <?php
            echo $name . ' (' . $role . ')'; // Corrected echo statement
          ?>
          <span style="color:#e7ab7b;">SIGN OUT</span>
        </a>
      </li>
    </ul>
  </nav>
</body>
</html>