<?php
include("../homepage/session.php");
if (isset($_POST['contactBtn'])) {
    include('../homepage/php/conn.php');

    if (!$con) {
        die("Database connection failed: " . mysqli_connect_error());
    }

    $icQuery = "SELECT IC_Number FROM user WHERE ID=" . intval($_SESSION['mySession']);
    $icResult = mysqli_query($con, $icQuery);

    if (!$icResult) {
        die("Error fetching IC Number: " . mysqli_error($con));
    }

    $icRow = mysqli_fetch_assoc($icResult);
    
    if (!$icRow) {
        die("Error: IC Number not found for user.");
    }

    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $feedback = mysqli_real_escape_string($con, $_POST['feedback']);
    
    $sql = "INSERT INTO contact_us (Email, Phone_Number, Feedback, IC_Number) 
            VALUES ('$email', '$phone', '$feedback', '" . $icRow['IC_Number'] . "')";

    if (!mysqli_query($con, $sql)) {
      die('Error inserting data: ' . mysqli_error($con) . ' - Query: ' . $sql);
    } else {
        echo '<script>alert("Successfully Sent Feedback!");
        window.location.href = "volunteercontactus.php";
        </script>';
    }

    mysqli_close($con);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <style>
    .contactusbody {
      background-color: #d8e1e8;
      font-family: 'Urbanist', sans-serif;
      overflow-x: hidden;
    }

    .container {
      width: 90%;
      margin: 0 auto;
    }

    .contact-info, .feedback-form {
      width: 48%;
      box-sizing: border-box;
    }

    .contact-info {
      float: left;
    }

    .feedback-form {
      float: right;
      font-size: 20px;
    }

    h1, h2 {
      font-size: 24px;
      margin-bottom: 20px;
    }

    .contact-info h1, .feedback-form h2 {
      padding-bottom: 10px;
      border-bottom: 2px solid #000;
      margin-bottom: 20px;
      text-align: center; /* Centering the headings */
      font-size: 40px;
    }

    .feedback-form h2 {
      text-align: center; /* Centering the headings */
    }

    img {
      width: 100%;
      height: 100%x;
      border: 2px solid #000;
      margin-bottom: 10px;
      opacity: 0.9; /* Making the image slightly transparent */
    }

    .contact-details {
      background-color: rgba(255, 255, 255, 0.8); /* Background color with opacity */
      padding: 10px;
      border-radius: 5px;
      font-size: 20px;
      font-weight: bold;
    }

    label {
      display: block;
      margin: 0px 0;
    }

    .ibox {
      width:  100%;
      padding:  10px;
      padding-left:  10px; /* This will shift the input fields   10px to the right */
      margin-bottom:  10px;
      box-sizing: border-box;
      border:  2px solid #ffb01d;
      border-radius:  15px;
    }


    #submit {
      border: 2px solid #98BAD5;
      height: 40px;
      width: 110px;
      border-radius: 15px;
      color: white;
      background-color:#304674;
      font-weight: bold;
      transition: height 0.2s, width 0.2s;
      cursor: pointer;
      display: block;
      margin:  0 auto; 
      font-size: 17px;

    }

    .feedback-form label {
      padding-left:  10px; /* This will shift the labels  10px to the right */
    }



    #submit:hover {
    cursor:pointer;
    height: 50px;
    width: 120px;
    }

    #submit:active {
    opacity: 0.6;
    }

    footer {
    position: relative;
    margin-top: -15px;
    padding: 10px;
    }

    text area {
      height: 100px;
    }

    /* Clearfix hack for floating elements */
    .clearfix::after {
      content: "";
      clear: both;
      display: table;
    }
  </style>
</head>
<body class='contactusbody'>
  <header>
    <?php include 'header_footer/volunteernavbar.php'; ?>
  </header>
  <div class="container clearfix">
    <section class="contact-info">
      <h1>Feel Free To Contact Us</h1>
      <div class="contact-details">
        <img src="../homepage/images/contact-us.jpg" alt="Contact Information">
        <p>Company email: SeniorConnect@mail.my</p>
        <p>Company tel: +601116665060</p>
        <p>Street: 21 Jln 8/1D Seksyen 8 Petaling Jaya</p>
        <p>City: Petaling Jaya</p>
        <p>State/province/area: Selangor</p>
        <p>Zip code: 46050</p>
        <p>Country: Malaysia</p>
      </div>
    </section>

    <section class="feedback-form">
      <h2>Tell us how we can improve</h2>
      <form method="post">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required class="ibox" required autocomplete="off">
        
        <label for="phone">Phone Number</label>
        <input type="tel" id="phone" name="phone" class="ibox" required autocomplete="off"> 
        
        <label for="feedback">Feedback</label>
        <textarea id="feedback" name="feedback" rows="4" required class="ibox" style="height: 200px;"></textarea>
        
        <button type="submit" id="submit" name="contactBtn">Submit</button>
      </form>
    </section>
  </div>
  <footer>
      <?php include 'header_footer/volunteerfooter.php'; ?>
  </footer>
  <br>
</body>
</html>