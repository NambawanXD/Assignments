<?php
  include("../homepage/session.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Volunteer Requests Page</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Urbanist:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<style>
  body {
    font-family: "Urbanist", sans-serif;
  }

  .request-list {
    list-style: none;
    padding: 0;
    margin: 0;
  }

  .request {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px;
    border-bottom: 2px solid #fefdfd;
  }

  .details {
    flex-grow: 1;
    color: rgb(245, 245, 238);
  }

  .acceptBtn {
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    background-color: #4CAF50;
    color: white;
    cursor: pointer;
  }

  .acceptBtn:hover {
    background-color: white;
    color: #4CAF50;
  }

  .background {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../homepage/images/volunteer-request.jpg');
        background-size: cover;
        background-position: center;
        filter: brightness(30%); 
        z-index: -1;
        }
    
  footer {
    position: fixed;
  }
</style>
</head>
<body>
  <header>
    <?php
      include 'header_footer/volunteernavbar.php';
    ?>
  </header>
  <div>
    <?php
    include("../homepage/php/conn.php");
    $query = "SELECT Request_ID, Name, Assistance, Location, Date, Time, Priority FROM senior_req"; // Include the ID in the query
    $result = mysqli_query($con, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<ul class="request-list">';
        echo '<li class="request">';
        echo '<div class="details">';
        echo '<p>Name: ' . htmlspecialchars($row['Name']) . '</p>';
        echo '<p>Assistance: ' . htmlspecialchars($row['Assistance']) . '</p>';
        echo '<p>Location: ' . htmlspecialchars($row['Location']) . '</p>';
        echo '</div>';
        echo '<div class="details">';
        echo '<p>Date: ' . htmlspecialchars($row['Date']) . '</p>';
        echo '<p>Time: ' . htmlspecialchars($row['Time']) . '</p>';
        echo '<p class="priority">Priority: ' . htmlspecialchars($row['Priority']) . '</p>';
        echo '</div>';

        echo '<form action="../homepage/php/statusinsert.php" method="post">';
        echo '<input type="hidden" name="senior_req_id" value="' . htmlspecialchars($row['Request_ID']) . '">';
        echo '<button type="submit" class="acceptBtn" name="acceptBtn">Accept Request</button>';
        echo '</form>'; 
        echo '</li>';
        echo '</ul>';
    }
    ?>

  <div class='background'></div>
  <footer>
    <?php
      include 'header_footer/volunteerfooter.php';
    ?>
  </footer> 

</div>
</body>
</html>