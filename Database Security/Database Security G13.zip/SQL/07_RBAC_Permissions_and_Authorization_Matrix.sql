/*
SmartBankDB - Role-Based Access Control and authorization matrix.
No business user receives direct permissions; all permissions are assigned to roles.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Authorization matrix documentation table
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.AuthorizationMatrix', N'U') IS NULL
BEGIN
    CREATE TABLE sec.AuthorizationMatrix
    (
        MatrixID              int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuthorizationMatrix PRIMARY KEY,
        RoleName              sysname NOT NULL,
        FunctionalArea        nvarchar(100) NOT NULL,
        RequiredAccess        nvarchar(300) NOT NULL,
        ImplementedUsing      nvarchar(500) NOT NULL,
        DirectBaseTableDML    varchar(10) NOT NULL,
        CONSTRAINT CK_AuthorizationMatrix_DML CHECK (DirectBaseTableDML IN ('Allowed', 'Denied', 'None'))
    );
END;
GO

TRUNCATE TABLE sec.AuthorizationMatrix;
INSERT sec.AuthorizationMatrix
(RoleName, FunctionalArea, RequiredAccess, ImplementedUsing, DirectBaseTableDML)
VALUES
(N'role_dba', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_dba', N'Own staff record', N'View and update own staff record except salary update.', N'api.usp_GetMyStaffRecord and api.usp_Staff_UpdateOwnRecord.', 'Denied'),
(N'role_dba', N'Database definition', N'Create and manage bank tables, but not business data.', N'CREATE TABLE plus ALTER on bank/history schemas; explicit SELECT/INSERT/UPDATE/DELETE DENY.', 'Denied'),
(N'role_bank_manager', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_bank_manager', N'Staff records', N'View own record and all Bank Officer records; manage officer details and salary.', N'Secure encrypted-data procedures and filtered staff view.', 'Denied'),
(N'role_bank_manager', N'Accounts and transactions', N'View all customer accounts and transactions.', N'SELECT on RLS-protected account and transaction views; predicate allows manager role.', 'Denied'),
(N'role_bank_officer', N'Own staff record', N'View and update own staff record except salary.', N'api.usp_GetMyStaffRecord and api.usp_Staff_UpdateOwnRecord.', 'Denied'),
(N'role_bank_officer', N'Customer accounts', N'View all accounts/transactions; onboard customers; create/update account status.', N'RLS-protected views, officer procedures, and UNMASK for operational contact data.', 'Denied'),
(N'role_customer', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_customer', N'Own profile', N'View own decrypted sensitive information.', N'api.usp_GetMyCustomerProfile automatically opens the key and filters by ORIGINAL_LOGIN().', 'Denied'),
(N'role_customer', N'Own accounts and transactions', N'View only own rows.', N'RLS policies on bank.Account and bank.TransactionRecord.', 'Denied'),
(N'role_customer', N'Financial transactions', N'Perform valid deposit, withdrawal and transfer only.', N'Transactional stored procedures with ownership, amount, balance, status and idempotency checks.', 'Denied'),
(N'role_security_auditor', N'Audit evidence', N'Read audit matrix, business, DML, DDL, permission, login/logout and backup evidence.', N'Read-only permissions on audit schema and SQL Server Audit reader.', 'Denied');
GO

/* -------------------------------------------------------------------------
   2. Baseline denials - business roles cannot manipulate base tables directly
   ------------------------------------------------------------------------- */
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_dba;
DENY SELECT ON SCHEMA::bank TO role_dba;

DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_bank_manager;
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_bank_officer;
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_customer;
DENY SELECT, INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_security_auditor;
GO

/* No non-DBA business role may create or manage tables. */
DENY CREATE TABLE TO role_bank_manager;
DENY CREATE TABLE TO role_bank_officer;
DENY CREATE TABLE TO role_customer;
DENY CREATE TABLE TO role_security_auditor;
GO

/* -------------------------------------------------------------------------
   3. DBA role: table definition only, plus own staff functions
   ------------------------------------------------------------------------- */
GRANT CREATE TABLE TO role_dba;
GRANT ALTER ON SCHEMA::bank TO role_dba;
GRANT ALTER ON SCHEMA::history TO role_dba;
GRANT VIEW DEFINITION ON SCHEMA::bank TO role_dba;
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_dba;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_dba;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_dba;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_dba;
GO

/* -------------------------------------------------------------------------
   4. Bank Manager role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_CustomerContact TO role_bank_manager;
GRANT SELECT ON OBJECT::reporting.vw_BranchAccountSummary TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_GetStaffRecords TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_CreateBankOfficer TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_UpdateBankOfficer TO role_bank_manager;
GO

/* -------------------------------------------------------------------------
   5. Bank Officer role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_CustomerContact TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_CreateCustomer TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_UpdateCustomer TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_CreateAccount TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_UpdateAccountStatus TO role_bank_officer;
GRANT UNMASK TO role_bank_officer;
GO

/* -------------------------------------------------------------------------
   6. Customer role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_customer;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_customer;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_GetMyCustomerProfile TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Deposit TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Withdraw TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Transfer TO role_customer;
GO

/* -------------------------------------------------------------------------
   7. Security Auditor role - separation of duties
   ------------------------------------------------------------------------- */
GRANT SELECT ON SCHEMA::audit TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.vw_RoleUserMapping TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.vw_ExplicitRolePermissions TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.AuthorizationMatrix TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.DataDictionary TO role_security_auditor;
GRANT SELECT ON OBJECT::reporting.CustomerAnalyticsMasked TO role_security_auditor;
GRANT EXECUTE ON OBJECT::audit.usp_ReadSqlServerAudit TO role_security_auditor;
GRANT VIEW DEFINITION ON DATABASE::SmartBankDB TO role_security_auditor;
GO

/* SQL Server 2022+ granular permission for reading .sqlaudit files. */
USE master;
GO
BEGIN TRY
    GRANT VIEW SERVER SECURITY AUDIT TO SB_AUDITOR01;
END TRY
BEGIN CATCH
    PRINT 'VIEW SERVER SECURITY AUDIT is not supported by this SQL Server version.';
    PRINT 'Use a sysadmin login to query the .sqlaudit file during the demonstration.';
END CATCH;
GO

USE SmartBankDB;
GO

/* -------------------------------------------------------------------------
   8. Proof: users, memberships, and explicit role permissions
   ------------------------------------------------------------------------- */
SELECT * FROM sec.vw_RoleUserMapping ORDER BY RoleName, UserName;
SELECT * FROM sec.vw_ExplicitRolePermissions ORDER BY RoleName, PermissionState, SecurableName, PermissionName;
SELECT * FROM sec.AuthorizationMatrix ORDER BY RoleName, MatrixID;
GO

PRINT '07 RBAC and permissions completed successfully.';
GO
