/*
SmartBankDB COMPLETE INSTALLATION
Run as a sysadmin in SSMS. This file installs scripts 01 through 08 in order.
It does NOT reset/drop an existing environment and does NOT execute restore drills.
For a clean lab rebuild, run 00_Reset_Demo_Environment.sql first in a separate window.
*/


/* =====================================================================
   INCLUDED FILE: 01_Server_Database_and_Encryption_Setup.sql
   ===================================================================== */

/*
SmartBankDB - Server, database, folders, and encryption setup
Run as a sysadmin in SSMS.
Tested design target: SQL Server 2019/2022/2025 Developer or Standard Edition.
*/
USE master;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Backup-encryption certificate in master
   ------------------------------------------------------------------------- */
IF NOT EXISTS
(
    SELECT 1
    FROM sys.symmetric_keys
    WHERE name = N'##MS_DatabaseMasterKey##'
)
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'MasterKey#SmartBank2026!';
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.certificates
    WHERE name = N'SmartBankBackupCertificate'
)
BEGIN
    CREATE CERTIFICATE SmartBankBackupCertificate
        WITH SUBJECT = N'SmartBank AES-256 backup encryption certificate',
             EXPIRY_DATE = '20361231';
END;
GO

/* -------------------------------------------------------------------------
   2. Create database with integrity and recovery settings
   ------------------------------------------------------------------------- */
IF DB_ID(N'SmartBankDB') IS NULL
BEGIN
    CREATE DATABASE SmartBankDB;
END;
GO

ALTER DATABASE SmartBankDB SET RECOVERY FULL;
ALTER DATABASE SmartBankDB SET PAGE_VERIFY CHECKSUM;
ALTER DATABASE SmartBankDB SET AUTO_CLOSE OFF;
ALTER DATABASE SmartBankDB SET AUTO_SHRINK OFF;
ALTER DATABASE SmartBankDB SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
ALTER DATABASE SmartBankDB SET TRUSTWORTHY OFF;
GO

USE SmartBankDB;
GO

/* -------------------------------------------------------------------------
   3. Organisational schemas
   ------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'bank')
    EXEC(N'CREATE SCHEMA bank AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'sec')
    EXEC(N'CREATE SCHEMA sec AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'api')
    EXEC(N'CREATE SCHEMA api AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'audit')
    EXEC(N'CREATE SCHEMA audit AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'admin')
    EXEC(N'CREATE SCHEMA admin AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'reporting')
    EXEC(N'CREATE SCHEMA reporting AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'history')
    EXEC(N'CREATE SCHEMA history AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'demo')
    EXEC(N'CREATE SCHEMA demo AUTHORIZATION dbo;');
GO

/* -------------------------------------------------------------------------
   4. Configuration table and SQL Server-accessible folders
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'admin.Configuration', N'U') IS NULL
BEGIN
    CREATE TABLE admin.Configuration
    (
        ConfigKey       sysname          NOT NULL CONSTRAINT PK_Configuration PRIMARY KEY,
        ConfigValue     nvarchar(4000)   NOT NULL,
        Description     nvarchar(500)    NULL,
        ModifiedAt      datetime2(3)     NOT NULL CONSTRAINT DF_Configuration_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname          NOT NULL CONSTRAINT DF_Configuration_ModifiedBy DEFAULT ORIGINAL_LOGIN()
    );
END;
GO

DECLARE @DefaultBackupPath nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultBackupPath'));
DECLARE @DefaultLogPath    nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultLogPath'));

IF @DefaultBackupPath IS NULL OR LTRIM(RTRIM(@DefaultBackupPath)) = N''
BEGIN
    SELECT TOP (1) @DefaultBackupPath = LEFT(physical_name, LEN(physical_name) - CHARINDEX(N'\', REVERSE(physical_name)) + 1)
    FROM master.sys.master_files
    WHERE database_id = 1 AND file_id = 1;
END;

IF @DefaultLogPath IS NULL OR LTRIM(RTRIM(@DefaultLogPath)) = N''
BEGIN
    SET @DefaultLogPath = @DefaultBackupPath;
END;

IF RIGHT(@DefaultBackupPath, 1) <> N'\' SET @DefaultBackupPath += N'\';
IF RIGHT(@DefaultLogPath, 1) <> N'\' SET @DefaultLogPath += N'\';

DECLARE @SmartBankBackupPath nvarchar(4000) = @DefaultBackupPath + N'SmartBankDB\';
DECLARE @SmartBankAuditPath  nvarchar(4000) = @DefaultLogPath + N'SmartBankAudit\';

BEGIN TRY
    EXEC master.dbo.xp_create_subdir @SmartBankBackupPath;
    EXEC master.dbo.xp_create_subdir @SmartBankAuditPath;
END TRY
BEGIN CATCH
    PRINT 'Folder creation warning: ' + ERROR_MESSAGE();
    PRINT 'Create the folders manually and grant the SQL Server service account Modify permission.';
END CATCH;

MERGE admin.Configuration AS target
USING
(
    SELECT N'BackupPath' AS ConfigKey, @SmartBankBackupPath AS ConfigValue,
           N'Folder for encrypted full, differential, and transaction-log backups.' AS Description
    UNION ALL
    SELECT N'AuditPath', @SmartBankAuditPath,
           N'Folder for SQL Server Audit .sqlaudit files.'
    UNION ALL
    SELECT N'RPO_Minutes', N'15',
           N'Maximum acceptable data loss. Supported by 15-minute transaction-log backups.'
    UNION ALL
    SELECT N'RTO_Minutes', N'60',
           N'Target recovery time for restoring service in the lab environment.'
    UNION ALL
    SELECT N'DatabaseMasterKeyPassword', N'DbMasterKey#SmartBank2026!',
           N'Lab-only password needed after restoring the database to another instance. Store securely in production.'
    UNION ALL
    SELECT N'CertificateExportPassword', N'BackupCert#SmartBank2026!',
           N'Lab-only password protecting the exported backup-certificate private key.'
) AS source
ON target.ConfigKey = source.ConfigKey
WHEN MATCHED THEN
    UPDATE SET ConfigValue = source.ConfigValue,
               Description = source.Description,
               ModifiedAt = SYSUTCDATETIME(),
               ModifiedBy = ORIGINAL_LOGIN()
WHEN NOT MATCHED THEN
    INSERT (ConfigKey, ConfigValue, Description)
    VALUES (source.ConfigKey, source.ConfigValue, source.Description);
GO

/* -------------------------------------------------------------------------
   5. Column-level encryption hierarchy inside SmartBankDB
   ------------------------------------------------------------------------- */
IF NOT EXISTS
(
    SELECT 1
    FROM sys.symmetric_keys
    WHERE name = N'##MS_DatabaseMasterKey##'
)
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'DbMasterKey#SmartBank2026!';
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name = N'SmartBankColumnCertificate')
BEGIN
    CREATE CERTIFICATE SmartBankColumnCertificate
        WITH SUBJECT = N'SmartBank column-level encryption certificate',
             EXPIRY_DATE = '20361231';
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name = N'SmartBankColumnKey')
BEGIN
    CREATE SYMMETRIC KEY SmartBankColumnKey
        WITH ALGORITHM = AES_256
        ENCRYPTION BY CERTIFICATE SmartBankColumnCertificate;
END;
GO

SELECT
    DB_NAME() AS DatabaseName,
    recovery_model_desc,
    page_verify_option_desc,
    is_read_committed_snapshot_on,
    is_trustworthy_on
FROM sys.databases
WHERE name = N'SmartBankDB';

SELECT ConfigKey, ConfigValue, Description
FROM admin.Configuration
ORDER BY ConfigKey;
GO

PRINT '01 setup completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 02_Secure_Data_Model_and_Classification.sql
   ===================================================================== */

/*
SmartBankDB - Improved relational model, constraints, data dictionary,
data classification, temporal history, masking-ready columns, and audit tables.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* -------------------------------------------------------------------------
   1. Core banking tables
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'bank.Staff', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Staff
    (
        StaffID         char(6)         NOT NULL CONSTRAINT PK_Staff PRIMARY KEY,
        StaffName       nvarchar(100)   NOT NULL,
        Position        varchar(20)     NOT NULL,
        Branch          nvarchar(50)    NOT NULL,
        Phone           varchar(20)     NOT NULL,
        IsActive        bit             NOT NULL CONSTRAINT DF_Staff_IsActive DEFAULT (1),
        CreatedAt       datetime2(3)    NOT NULL CONSTRAINT DF_Staff_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy       sysname         NOT NULL CONSTRAINT DF_Staff_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt      datetime2(3)    NOT NULL CONSTRAINT DF_Staff_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname         NOT NULL CONSTRAINT DF_Staff_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        RowVer          rowversion      NOT NULL,
        CONSTRAINT CK_Staff_ID CHECK (StaffID LIKE 'ST[0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Staff_Position CHECK (Position IN ('DBA', 'Bank Manager', 'Bank Officer')),
        CONSTRAINT CK_Staff_Phone CHECK (LEN(Phone) BETWEEN 8 AND 20)
    );
END;
GO

IF OBJECT_ID(N'bank.StaffPrivate', N'U') IS NULL
BEGIN
    CREATE TABLE bank.StaffPrivate
    (
        StaffID                 char(6)         NOT NULL CONSTRAINT PK_StaffPrivate PRIMARY KEY,
        SalaryCipher            varbinary(256)  NOT NULL,
        SalaryIntegrityHash     varbinary(32)   NOT NULL,
        LastSalaryReviewDate    date            NULL,
        ModifiedAt              datetime2(3)    NOT NULL CONSTRAINT DF_StaffPrivate_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy              sysname         NOT NULL CONSTRAINT DF_StaffPrivate_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        RowVer                  rowversion      NOT NULL,
        CONSTRAINT FK_StaffPrivate_Staff FOREIGN KEY (StaffID) REFERENCES bank.Staff(StaffID)
    );
END;
GO

IF OBJECT_ID(N'bank.Customer', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Customer
    (
        CustomerID       char(6)         NOT NULL CONSTRAINT PK_Customer PRIMARY KEY,
        CustomerName     nvarchar(100)   NOT NULL,
        Email            varchar(254)    MASKED WITH (FUNCTION = 'email()') NOT NULL,
        Phone            varchar(20)     MASKED WITH (FUNCTION = 'partial(0,"XXX-XXX-",4)') NOT NULL,
        DateOfBirth      date            MASKED WITH (FUNCTION = 'default()') NOT NULL,
        ICNumberCipher   varbinary(256)  NOT NULL,
        AddressCipher    varbinary(512)  NOT NULL,
        HashSalt         uniqueidentifier NOT NULL CONSTRAINT DF_Customer_HashSalt DEFAULT NEWID(),
        ICNumberHash     varbinary(32)   NOT NULL,
        CustomerStatus   varchar(15)     NOT NULL CONSTRAINT DF_Customer_Status DEFAULT ('Active'),
        CreatedAt        datetime2(3)    NOT NULL CONSTRAINT DF_Customer_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy        sysname         NOT NULL CONSTRAINT DF_Customer_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt       datetime2(3)    NOT NULL CONSTRAINT DF_Customer_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy       sysname         NOT NULL CONSTRAINT DF_Customer_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        ValidFrom        datetime2(3) GENERATED ALWAYS AS ROW START HIDDEN NOT NULL CONSTRAINT DF_Customer_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo          datetime2(3) GENERATED ALWAYS AS ROW END HIDDEN NOT NULL CONSTRAINT DF_Customer_ValidTo DEFAULT CONVERT(datetime2(3), '9999-12-31 23:59:59.999'),
        PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
        RowVer           rowversion      NOT NULL,
        CONSTRAINT CK_Customer_ID CHECK (CustomerID LIKE 'CU[0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Customer_Email CHECK (Email LIKE '%_@_%._%'),
        CONSTRAINT CK_Customer_Phone CHECK (LEN(Phone) BETWEEN 8 AND 20),
        CONSTRAINT CK_Customer_Status CHECK (CustomerStatus IN ('Active', 'Suspended', 'Closed'))
    )
    WITH
    (
        SYSTEM_VERSIONING = ON
        (
            HISTORY_TABLE = history.CustomerHistory,
            DATA_CONSISTENCY_CHECK = ON
        )
    );
END;
GO

IF OBJECT_ID(N'bank.Account', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Account
    (
        AccountID       char(10)        NOT NULL CONSTRAINT PK_Account PRIMARY KEY,
        CustomerID      char(6)         NOT NULL,
        AccountType     varchar(20)     NOT NULL,
        Balance         decimal(15,2)   NOT NULL CONSTRAINT DF_Account_Balance DEFAULT (0),
        AccountStatus   varchar(15)     NOT NULL CONSTRAINT DF_Account_Status DEFAULT ('Active'),
        OpenedAt        datetime2(3)    NOT NULL CONSTRAINT DF_Account_OpenedAt DEFAULT SYSUTCDATETIME(),
        ClosedAt        datetime2(3)    NULL,
        CreatedBy       sysname         NOT NULL CONSTRAINT DF_Account_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt      datetime2(3)    NOT NULL CONSTRAINT DF_Account_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname         NOT NULL CONSTRAINT DF_Account_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        ValidFrom       datetime2(3) GENERATED ALWAYS AS ROW START HIDDEN NOT NULL CONSTRAINT DF_Account_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo         datetime2(3) GENERATED ALWAYS AS ROW END HIDDEN NOT NULL CONSTRAINT DF_Account_ValidTo DEFAULT CONVERT(datetime2(3), '9999-12-31 23:59:59.999'),
        PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
        RowVer          rowversion      NOT NULL,
        CONSTRAINT FK_Account_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT CK_Account_ID CHECK (AccountID LIKE 'AC[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Account_Type CHECK (AccountType IN ('Savings', 'Current', 'Fixed Deposit')),
        CONSTRAINT CK_Account_Balance CHECK (Balance >= 0),
        CONSTRAINT CK_Account_Status CHECK (AccountStatus IN ('Active', 'Frozen', 'Closed')),
        CONSTRAINT CK_Account_ClosedAt CHECK
        (
            (AccountStatus <> 'Closed' AND ClosedAt IS NULL)
            OR
            (AccountStatus = 'Closed' AND ClosedAt IS NOT NULL)
        )
    )
    WITH
    (
        SYSTEM_VERSIONING = ON
        (
            HISTORY_TABLE = history.AccountHistory,
            DATA_CONSISTENCY_CHECK = ON
        )
    );
END;
GO

IF OBJECT_ID(N'bank.TransactionRecord', N'U') IS NULL
BEGIN
    CREATE TABLE bank.TransactionRecord
    (
        TransID                bigint           IDENTITY(1,1) NOT NULL CONSTRAINT PK_TransactionRecord PRIMARY KEY,
        TransactionReference   uniqueidentifier NOT NULL CONSTRAINT DF_Transaction_Reference DEFAULT NEWSEQUENTIALID(),
        TransferGroupID        uniqueidentifier NULL,
        CustomerID             char(6)          NOT NULL,
        AccountID              char(10)         NOT NULL,
        CounterpartyAccountID  char(10)         NULL,
        TransDate              datetime2(3)     NOT NULL CONSTRAINT DF_Transaction_Date DEFAULT SYSUTCDATETIME(),
        Amount                 decimal(15,2)    NOT NULL,
        TransactionType        varchar(12)      NOT NULL,
        Direction              varchar(6)       NOT NULL,
        BalanceBefore          decimal(15,2)    NOT NULL,
        BalanceAfter           decimal(15,2)    NOT NULL,
        Remarks                nvarchar(250)    NULL,
        IdempotencyKey         uniqueidentifier NULL,
        InitiatedByLogin       sysname          NOT NULL CONSTRAINT DF_Transaction_Login DEFAULT ORIGINAL_LOGIN(),
        SourceApplication      nvarchar(128)    NOT NULL CONSTRAINT DF_Transaction_App DEFAULT APP_NAME(),
        CONSTRAINT UQ_Transaction_Reference UNIQUE (TransactionReference),
        CONSTRAINT FK_Transaction_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT FK_Transaction_Account FOREIGN KEY (AccountID) REFERENCES bank.Account(AccountID),
        CONSTRAINT FK_Transaction_Counterparty FOREIGN KEY (CounterpartyAccountID) REFERENCES bank.Account(AccountID),
        CONSTRAINT CK_Transaction_Amount CHECK (Amount > 0),
        CONSTRAINT CK_Transaction_Type CHECK (TransactionType IN ('Deposit', 'Withdrawal', 'Transfer')),
        CONSTRAINT CK_Transaction_Direction CHECK (Direction IN ('Credit', 'Debit')),
        CONSTRAINT CK_Transaction_Balance CHECK (BalanceBefore >= 0 AND BalanceAfter >= 0),
        CONSTRAINT CK_Transaction_Semantics CHECK
        (
            (TransactionType = 'Deposit' AND Direction = 'Credit' AND CounterpartyAccountID IS NULL)
            OR
            (TransactionType = 'Withdrawal' AND Direction = 'Debit' AND CounterpartyAccountID IS NULL)
            OR
            (TransactionType = 'Transfer' AND CounterpartyAccountID IS NOT NULL)
        )
    );

    CREATE UNIQUE INDEX UX_Transaction_IdempotencyKey
        ON bank.TransactionRecord(IdempotencyKey)
        WHERE IdempotencyKey IS NOT NULL;

    CREATE INDEX IX_Transaction_Customer_Date
        ON bank.TransactionRecord(CustomerID, TransDate DESC);

    CREATE INDEX IX_Transaction_Account_Date
        ON bank.TransactionRecord(AccountID, TransDate DESC);
END;
GO

/* -------------------------------------------------------------------------
   2. Security identity map
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.LoginIdentityMap', N'U') IS NULL
BEGIN
    CREATE TABLE sec.LoginIdentityMap
    (
        DatabaseUserName   sysname       NOT NULL CONSTRAINT PK_LoginIdentityMap PRIMARY KEY,
        LoginName          sysname       NOT NULL CONSTRAINT UQ_LoginIdentityMap_Login UNIQUE,
        RoleCode           varchar(25)   NOT NULL,
        StaffID            char(6)       NULL,
        CustomerID         char(6)       NULL,
        IsActive           bit           NOT NULL CONSTRAINT DF_LoginIdentityMap_IsActive DEFAULT (1),
        CreatedAt          datetime2(3)  NOT NULL CONSTRAINT DF_LoginIdentityMap_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy          sysname       NOT NULL CONSTRAINT DF_LoginIdentityMap_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        CONSTRAINT FK_LoginIdentityMap_Staff FOREIGN KEY (StaffID) REFERENCES bank.Staff(StaffID),
        CONSTRAINT FK_LoginIdentityMap_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT CK_LoginIdentityMap_Role CHECK
        (
            RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER', 'CUSTOMER', 'SECURITY_AUDITOR')
        ),
        CONSTRAINT CK_LoginIdentityMap_Association CHECK
        (
            (RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER') AND StaffID IS NOT NULL AND CustomerID IS NULL)
            OR
            (RoleCode = 'CUSTOMER' AND CustomerID IS NOT NULL AND StaffID IS NULL)
            OR
            (RoleCode = 'SECURITY_AUDITOR' AND StaffID IS NULL AND CustomerID IS NULL)
        )
    );
END;
GO

/* -------------------------------------------------------------------------
   3. Auditing and operational evidence tables
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'audit.BusinessActionLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.BusinessActionLog
    (
        AuditID             bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BusinessActionLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_BusinessActionLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL,
        DatabaseUserName    sysname NOT NULL,
        RoleCode            varchar(25) NULL,
        SessionID           int NOT NULL,
        HostName            nvarchar(128) NULL,
        ApplicationName     nvarchar(128) NULL,
        ClientAddress       varchar(48) NULL,
        ActionCategory      varchar(30) NOT NULL,
        ActionName          nvarchar(128) NOT NULL,
        TargetObject        nvarchar(256) NULL,
        Success             bit NOT NULL,
        ErrorNumber         int NULL,
        ErrorMessage        nvarchar(2048) NULL,
        KeyValuesJson       nvarchar(max) NULL,
        OldValuesJson       nvarchar(max) NULL,
        NewValuesJson       nvarchar(max) NULL,
        CorrelationID       uniqueidentifier NOT NULL CONSTRAINT DF_BusinessActionLog_Correlation DEFAULT NEWID(),
        CONSTRAINT CK_BusinessActionLog_KeyJson CHECK (KeyValuesJson IS NULL OR ISJSON(KeyValuesJson) = 1),
        CONSTRAINT CK_BusinessActionLog_OldJson CHECK (OldValuesJson IS NULL OR ISJSON(OldValuesJson) = 1),
        CONSTRAINT CK_BusinessActionLog_NewJson CHECK (NewValuesJson IS NULL OR ISJSON(NewValuesJson) = 1)
    );

    CREATE INDEX IX_BusinessActionLog_Time ON audit.BusinessActionLog(EventTimeUtc DESC);
    CREATE INDEX IX_BusinessActionLog_Login ON audit.BusinessActionLog(LoginName, EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.DMLChangeLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.DMLChangeLog
    (
        ChangeAuditID       bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DMLChangeLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_DMLChangeLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL CONSTRAINT DF_DMLChangeLog_Login DEFAULT ORIGINAL_LOGIN(),
        DatabaseUserName    sysname NOT NULL CONSTRAINT DF_DMLChangeLog_User DEFAULT USER_NAME(),
        SessionID           int NOT NULL CONSTRAINT DF_DMLChangeLog_Session DEFAULT @@SPID,
        SchemaName          sysname NOT NULL,
        TableName           sysname NOT NULL,
        DMLAction           varchar(10) NOT NULL,
        RowCountAffected    int NOT NULL,
        OldRowsJson         nvarchar(max) NULL,
        NewRowsJson         nvarchar(max) NULL,
        HostName            nvarchar(128) NULL CONSTRAINT DF_DMLChangeLog_Host DEFAULT HOST_NAME(),
        ApplicationName     nvarchar(128) NULL CONSTRAINT DF_DMLChangeLog_App DEFAULT APP_NAME(),
        CONSTRAINT CK_DMLChangeLog_Action CHECK (DMLAction IN ('INSERT', 'UPDATE', 'DELETE')),
        CONSTRAINT CK_DMLChangeLog_OldJson CHECK (OldRowsJson IS NULL OR ISJSON(OldRowsJson) = 1),
        CONSTRAINT CK_DMLChangeLog_NewJson CHECK (NewRowsJson IS NULL OR ISJSON(NewRowsJson) = 1)
    );

    CREATE INDEX IX_DMLChangeLog_Time ON audit.DMLChangeLog(EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.DDLSecurityChangeLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.DDLSecurityChangeLog
    (
        DDLAuditID          bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DDLSecurityChangeLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_DDLSecurityChangeLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL,
        DatabaseUserName    sysname NOT NULL,
        EventType           sysname NOT NULL,
        ObjectType          sysname NULL,
        SchemaName          sysname NULL,
        ObjectName          sysname NULL,
        TSQLCommand         nvarchar(max) NULL,
        EventDataXml        xml NOT NULL,
        HostName            nvarchar(128) NULL,
        ApplicationName     nvarchar(128) NULL
    );

    CREATE INDEX IX_DDLSecurityChangeLog_Time ON audit.DDLSecurityChangeLog(EventTimeUtc DESC);
    CREATE INDEX IX_DDLSecurityChangeLog_Event ON audit.DDLSecurityChangeLog(EventType, EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.BackupEvidence', N'U') IS NULL
BEGIN
    CREATE TABLE audit.BackupEvidence
    (
        BackupEvidenceID    bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BackupEvidence PRIMARY KEY,
        BackupStartUtc      datetime2(3) NOT NULL,
        BackupFinishUtc     datetime2(3) NOT NULL,
        BackupType          varchar(12) NOT NULL,
        BackupFile          nvarchar(4000) NOT NULL,
        Encrypted           bit NOT NULL,
        CompressionUsed     bit NOT NULL,
        ChecksumUsed        bit NOT NULL,
        VerifyOnlyPassed    bit NOT NULL,
        Success             bit NOT NULL,
        ErrorMessage        nvarchar(2048) NULL,
        ExecutedBy          sysname NOT NULL,
        SqlAgentJobName     sysname NULL,
        CONSTRAINT CK_BackupEvidence_Type CHECK (BackupType IN ('FULL', 'DIFFERENTIAL', 'LOG'))
    );

    CREATE INDEX IX_BackupEvidence_Time ON audit.BackupEvidence(BackupFinishUtc DESC);
END;
GO

/* -------------------------------------------------------------------------
   4. Static-masked analytics table
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'reporting.CustomerAnalyticsMasked', N'U') IS NULL
BEGIN
    CREATE TABLE reporting.CustomerAnalyticsMasked
    (
        CustomerToken      char(64)       NOT NULL CONSTRAINT PK_CustomerAnalyticsMasked PRIMARY KEY,
        CustomerAlias      nvarchar(40)   NOT NULL,
        EmailDomain        nvarchar(128)  NULL,
        PhoneMasked        varchar(20)    NOT NULL,
        AgeBand            varchar(15)    NOT NULL,
        AccountCount       int            NOT NULL,
        TotalBalanceBand   varchar(20)    NOT NULL,
        SnapshotUtc        datetime2(3)   NOT NULL
    );
END;
GO

/* -------------------------------------------------------------------------
   5. Queryable data dictionary
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.DataDictionary', N'U') IS NULL
BEGIN
    CREATE TABLE sec.DataDictionary
    (
        DictionaryID       int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DataDictionary PRIMARY KEY,
        SchemaName         sysname NOT NULL,
        TableName          sysname NOT NULL,
        ColumnName         sysname NOT NULL,
        DataType           nvarchar(100) NOT NULL,
        AllowsNull         bit NOT NULL,
        Classification     varchar(20) NOT NULL,
        InformationType    nvarchar(100) NOT NULL,
        BusinessPurpose    nvarchar(500) NOT NULL,
        ProtectionControl  nvarchar(500) NOT NULL,
        CONSTRAINT UQ_DataDictionary UNIQUE (SchemaName, TableName, ColumnName),
        CONSTRAINT CK_DataDictionary_Class CHECK (Classification IN ('Public', 'Internal', 'Confidential', 'Private'))
    );
END;
GO

TRUNCATE TABLE sec.DataDictionary;

INSERT sec.DataDictionary
(
    SchemaName, TableName, ColumnName, DataType, AllowsNull,
    Classification, InformationType, BusinessPurpose, ProtectionControl
)
VALUES
(N'bank', N'Staff', N'StaffID', N'char(6)', 0, 'Internal', N'Employee identifier', N'Uniquely identifies staff.', N'Primary key; RBAC; not exposed publicly.'),
(N'bank', N'Staff', N'StaffName', N'nvarchar(100)', 0, 'Public', N'Name', N'Identifies bank staff.', N'Exposed only with Phone through the public staff-directory view.'),
(N'bank', N'Staff', N'Position', N'varchar(20)', 0, 'Internal', N'Job role', N'Drives staff responsibilities.', N'CHECK constraint and restricted staff views/procedures.'),
(N'bank', N'Staff', N'Branch', N'nvarchar(50)', 0, 'Internal', N'Organisational unit', N'Identifies work location.', N'RBAC and self-service procedure.'),
(N'bank', N'Staff', N'Phone', N'varchar(20)', 0, 'Public', N'Contact number', N'Allows authenticated users to contact staff.', N'Public directory view; direct table access denied.'),
(N'bank', N'StaffPrivate', N'SalaryCipher', N'varbinary(256)', 0, 'Private', N'Financial information', N'Stores staff salary.', N'AES-256 column-level encryption with authenticated ciphertext; decrypted only inside authorised stored procedures.'),
(N'bank', N'Customer', N'CustomerID', N'char(6)', 0, 'Internal', N'Customer identifier', N'Links customer records and accounts.', N'Primary key and row-level security mapping.'),
(N'bank', N'Customer', N'CustomerName', N'nvarchar(100)', 0, 'Internal', N'Name', N'Customer servicing.', N'Views, RBAC, and no direct table access.'),
(N'bank', N'Customer', N'Email', N'varchar(254)', 0, 'Confidential', N'Contact information', N'Customer communication.', N'Dynamic Data Masking; UNMASK only for Bank Officers; customers receive own value through a secure procedure.'),
(N'bank', N'Customer', N'Phone', N'varchar(20)', 0, 'Confidential', N'Contact information', N'Customer verification and communication.', N'Dynamic Data Masking; UNMASK only for Bank Officers.'),
(N'bank', N'Customer', N'DateOfBirth', N'date', 0, 'Confidential', N'Personal information', N'Identity verification.', N'Dynamic Data Masking and secure customer-profile procedure.'),
(N'bank', N'Customer', N'ICNumberCipher', N'varbinary(256)', 0, 'Private', N'National identifier', N'Identity verification and regulatory compliance.', N'AES-256 column-level encryption with per-record authenticator.'),
(N'bank', N'Customer', N'AddressCipher', N'varbinary(512)', 0, 'Private', N'Address', N'Customer correspondence and KYC.', N'AES-256 column-level encryption with per-record authenticator.'),
(N'bank', N'Customer', N'ICNumberHash', N'varbinary(32)', 0, 'Private', N'Hashed identifier', N'One-way integrity and duplicate-check support.', N'SHA2-256 salted hash; table access denied.'),
(N'bank', N'Account', N'AccountID', N'char(10)', 0, 'Confidential', N'Financial account identifier', N'Identifies a customer account.', N'RLS, views, foreign keys, and direct DML denial.'),
(N'bank', N'Account', N'CustomerID', N'char(6)', 0, 'Confidential', N'Ownership link', N'Associates account with a customer.', N'Foreign key and RLS predicate.'),
(N'bank', N'Account', N'Balance', N'decimal(15,2)', 0, 'Private', N'Financial balance', N'Current available balance.', N'RLS; transaction procedures; CHECK constraint; encrypted backups.'),
(N'bank', N'TransactionRecord', N'TransID', N'bigint', 0, 'Internal', N'Transaction identifier', N'Immutable transaction identifier.', N'Identity primary key; append-only access model.'),
(N'bank', N'TransactionRecord', N'Amount', N'decimal(15,2)', 0, 'Private', N'Financial transaction', N'Value transferred.', N'RLS; CHECK constraint; secure stored procedures; encrypted backups.'),
(N'bank', N'TransactionRecord', N'TransactionType', N'varchar(12)', 0, 'Confidential', N'Transaction category', N'Deposit, withdrawal, or transfer.', N'CHECK constraint limiting valid values.'),
(N'audit', N'BusinessActionLog', N'ErrorMessage', N'nvarchar(2048)', 1, 'Confidential', N'Security audit evidence', N'Explains valid and invalid attempted operations.', N'Read-only auditor access; encrypted backups; append-only permissions.'),
(N'audit', N'DMLChangeLog', N'OldRowsJson', N'nvarchar(max)', 1, 'Private', N'Change history', N'Captures before-images of changed records.', N'Restricted auditor access and encrypted backups.'),
(N'audit', N'DDLSecurityChangeLog', N'TSQLCommand', N'nvarchar(max)', 1, 'Confidential', N'DDL and permission audit', N'Captures database definition and permission changes.', N'DDL trigger plus SQL Server Audit; auditor-only access.');
GO

/* -------------------------------------------------------------------------
   6. SQL Server sensitivity classifications
   ------------------------------------------------------------------------- */
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.StaffPrivate.SalaryCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Customer.ICNumberCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'National ID', RANK = CRITICAL);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Customer.AddressCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Address', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Account.Balance
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.TransactionRecord.Amount
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO

SELECT SchemaName, TableName, ColumnName, Classification, ProtectionControl
FROM sec.DataDictionary
ORDER BY SchemaName, TableName, DictionaryID;
GO

PRINT '02 secure data model and classification completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 03_Authentication_Users_Roles_and_Sample_Data.sql
   ===================================================================== */

/*
SmartBankDB - SQL authentication, database users, roles, identity mapping,
and encrypted sample records.

IMPORTANT: SQL Server must use Mixed Mode authentication for these demo logins.
The passwords are lab credentials only and must be replaced outside the assignment.
*/
USE master;
GO
SET NOCOUNT ON;
GO

IF SUSER_ID(N'SB_DBA01') IS NULL
    CREATE LOGIN SB_DBA01 WITH PASSWORD = 'Dba#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_MANAGER01') IS NULL
    CREATE LOGIN SB_MANAGER01 WITH PASSWORD = 'Mgr#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_OFFICER01') IS NULL
    CREATE LOGIN SB_OFFICER01 WITH PASSWORD = 'Off1#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_OFFICER02') IS NULL
    CREATE LOGIN SB_OFFICER02 WITH PASSWORD = 'Off2#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER01') IS NULL
    CREATE LOGIN SB_CUSTOMER01 WITH PASSWORD = 'Cust1#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER02') IS NULL
    CREATE LOGIN SB_CUSTOMER02 WITH PASSWORD = 'Cust2#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER03') IS NULL
    CREATE LOGIN SB_CUSTOMER03 WITH PASSWORD = 'Cust3#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_AUDITOR01') IS NULL
    CREATE LOGIN SB_AUDITOR01 WITH PASSWORD = 'Audit#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
GO

/* Idempotent login hardening for existing lab logins. */
IF SUSER_ID(N'SB_DBA01') IS NOT NULL ALTER LOGIN [SB_DBA01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_MANAGER01') IS NOT NULL ALTER LOGIN [SB_MANAGER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_OFFICER01') IS NOT NULL ALTER LOGIN [SB_OFFICER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_OFFICER02') IS NOT NULL ALTER LOGIN [SB_OFFICER02] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER01') IS NOT NULL ALTER LOGIN [SB_CUSTOMER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER02') IS NOT NULL ALTER LOGIN [SB_CUSTOMER02] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER03') IS NOT NULL ALTER LOGIN [SB_CUSTOMER03] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_AUDITOR01') IS NOT NULL ALTER LOGIN [SB_AUDITOR01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;

ALTER AUTHORIZATION ON DATABASE::SmartBankDB TO sa;
GO

USE SmartBankDB;
GO

/* Database roles: permissions are assigned to roles, never directly to business users. */
IF DATABASE_PRINCIPAL_ID(N'role_dba') IS NULL
    CREATE ROLE role_dba AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_bank_manager') IS NULL
    CREATE ROLE role_bank_manager AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_bank_officer') IS NULL
    CREATE ROLE role_bank_officer AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_customer') IS NULL
    CREATE ROLE role_customer AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_security_auditor') IS NULL
    CREATE ROLE role_security_auditor AUTHORIZATION dbo;
GO

/* Database users */
IF DATABASE_PRINCIPAL_ID(N'SB_DBA01') IS NULL CREATE USER SB_DBA01 FOR LOGIN SB_DBA01;
IF DATABASE_PRINCIPAL_ID(N'SB_MANAGER01') IS NULL CREATE USER SB_MANAGER01 FOR LOGIN SB_MANAGER01;
IF DATABASE_PRINCIPAL_ID(N'SB_OFFICER01') IS NULL CREATE USER SB_OFFICER01 FOR LOGIN SB_OFFICER01;
IF DATABASE_PRINCIPAL_ID(N'SB_OFFICER02') IS NULL CREATE USER SB_OFFICER02 FOR LOGIN SB_OFFICER02;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER01') IS NULL CREATE USER SB_CUSTOMER01 FOR LOGIN SB_CUSTOMER01;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER02') IS NULL CREATE USER SB_CUSTOMER02 FOR LOGIN SB_CUSTOMER02;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER03') IS NULL CREATE USER SB_CUSTOMER03 FOR LOGIN SB_CUSTOMER03;
IF DATABASE_PRINCIPAL_ID(N'SB_AUDITOR01') IS NULL CREATE USER SB_AUDITOR01 FOR LOGIN SB_AUDITOR01;
GO

IF IS_ROLEMEMBER(N'role_dba', N'SB_DBA01') = 0
    ALTER ROLE role_dba ADD MEMBER SB_DBA01;
IF IS_ROLEMEMBER(N'role_bank_manager', N'SB_MANAGER01') = 0
    ALTER ROLE role_bank_manager ADD MEMBER SB_MANAGER01;
IF IS_ROLEMEMBER(N'role_bank_officer', N'SB_OFFICER01') = 0
    ALTER ROLE role_bank_officer ADD MEMBER SB_OFFICER01;
IF IS_ROLEMEMBER(N'role_bank_officer', N'SB_OFFICER02') = 0
    ALTER ROLE role_bank_officer ADD MEMBER SB_OFFICER02;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER01') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER01;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER02') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER02;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER03') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER03;
IF IS_ROLEMEMBER(N'role_security_auditor', N'SB_AUDITOR01') = 0
    ALTER ROLE role_security_auditor ADD MEMBER SB_AUDITOR01;
GO

/* -------------------------------------------------------------------------
   Encrypted sample data
   ------------------------------------------------------------------------- */
OPEN SYMMETRIC KEY SmartBankColumnKey
    DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

IF NOT EXISTS (SELECT 1 FROM bank.Staff WHERE StaffID = 'ST0001')
BEGIN
    INSERT bank.Staff (StaffID, StaffName, Position, Branch, Phone)
    VALUES
    ('ST0001', N'Aiman Rahman', 'DBA', N'Kuala Lumpur HQ', '03-21001001'),
    ('ST0002', N'Siti Nur Aisyah', 'Bank Manager', N'Kuala Lumpur HQ', '03-21001002'),
    ('ST0003', N'Daniel Lim', 'Bank Officer', N'Cheras Branch', '03-21001003'),
    ('ST0004', N'Priya Nair', 'Bank Officer', N'Petaling Jaya Branch', '03-21001004');

    INSERT bank.StaffPrivate (StaffID, SalaryCipher, SalaryIntegrityHash, LastSalaryReviewDate)
    VALUES
    ('ST0001',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'8500.00'), 1, CONVERT(varbinary(128), 'ST0001')),
        HASHBYTES('SHA2_256', N'ST0001|8500.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0002',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'12000.00'), 1, CONVERT(varbinary(128), 'ST0002')),
        HASHBYTES('SHA2_256', N'ST0002|12000.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0003',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'5200.00'), 1, CONVERT(varbinary(128), 'ST0003')),
        HASHBYTES('SHA2_256', N'ST0003|5200.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0004',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'5400.00'), 1, CONVERT(varbinary(128), 'ST0004')),
        HASHBYTES('SHA2_256', N'ST0004|5400.00|SmartBankSalaryIntegrity'), '2026-01-01');
END;

IF NOT EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = 'CU0001')
BEGIN
    DECLARE @Salt1 uniqueidentifier = NEWID();
    DECLARE @Salt2 uniqueidentifier = NEWID();
    DECLARE @Salt3 uniqueidentifier = NEWID();

    INSERT bank.Customer
    (
        CustomerID, CustomerName, Email, Phone, DateOfBirth,
        ICNumberCipher, AddressCipher, HashSalt, ICNumberHash
    )
    VALUES
    ('CU0001', N'Nur Izzati Hassan', 'izzati@example.com', '012-3456789', '1998-04-12',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'980412-14-5678'), 1, CONVERT(varbinary(128), 'CU0001')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'12 Jalan Ampang, 50450 Kuala Lumpur'), 1, CONVERT(varbinary(128), 'CU0001')),
        @Salt1,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt1) + N'|980412145678')),
    ('CU0002', N'Jason Wong', 'jason.wong@example.com', '013-7788990', '1995-09-21',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'950921-10-2244'), 1, CONVERT(varbinary(128), 'CU0002')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'88 Jalan Kuchai Lama, 58200 Kuala Lumpur'), 1, CONVERT(varbinary(128), 'CU0002')),
        @Salt2,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt2) + N'|950921102244')),
    ('CU0003', N'Kavitha Raman', 'kavitha.r@example.com', '016-4455667', '2000-02-18',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'000218-08-7788'), 1, CONVERT(varbinary(128), 'CU0003')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'27 Jalan SS2, 47300 Petaling Jaya'), 1, CONVERT(varbinary(128), 'CU0003')),
        @Salt3,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt3) + N'|000218087788'));
END;

CLOSE SYMMETRIC KEY SmartBankColumnKey;
GO

IF NOT EXISTS (SELECT 1 FROM bank.Account WHERE AccountID = 'AC00000001')
BEGIN
    INSERT bank.Account (AccountID, CustomerID, AccountType, Balance, AccountStatus)
    VALUES
    ('AC00000001', 'CU0001', 'Savings', 5000.00, 'Active'),
    ('AC00000002', 'CU0001', 'Current', 1500.00, 'Active'),
    ('AC00000003', 'CU0002', 'Savings', 8000.00, 'Active'),
    ('AC00000004', 'CU0003', 'Savings', 3200.00, 'Active');
END;
GO

IF NOT EXISTS (SELECT 1 FROM bank.TransactionRecord)
BEGIN
    INSERT bank.TransactionRecord
    (
        CustomerID, AccountID, TransDate, Amount, TransactionType,
        Direction, BalanceBefore, BalanceAfter, Remarks, InitiatedByLogin
    )
    VALUES
    ('CU0001', 'AC00000001', DATEADD(day, -10, SYSUTCDATETIME()), 5000.00, 'Deposit', 'Credit', 0.00, 5000.00, N'Opening deposit', 'SB_CUSTOMER01'),
    ('CU0001', 'AC00000002', DATEADD(day, -9, SYSUTCDATETIME()), 1500.00, 'Deposit', 'Credit', 0.00, 1500.00, N'Opening deposit', 'SB_CUSTOMER01'),
    ('CU0002', 'AC00000003', DATEADD(day, -8, SYSUTCDATETIME()), 8000.00, 'Deposit', 'Credit', 0.00, 8000.00, N'Opening deposit', 'SB_CUSTOMER02'),
    ('CU0003', 'AC00000004', DATEADD(day, -7, SYSUTCDATETIME()), 3200.00, 'Deposit', 'Credit', 0.00, 3200.00, N'Opening deposit', 'SB_CUSTOMER03');
END;
GO

/* Login/user-to-business-identity mapping used by RLS and procedures. */
MERGE sec.LoginIdentityMap AS target
USING
(
    SELECT N'SB_DBA01' AS DatabaseUserName, N'SB_DBA01' AS LoginName, 'DBA' AS RoleCode, 'ST0001' AS StaffID, CAST(NULL AS char(6)) AS CustomerID
    UNION ALL SELECT N'SB_MANAGER01', N'SB_MANAGER01', 'BANK_MANAGER', 'ST0002', NULL
    UNION ALL SELECT N'SB_OFFICER01', N'SB_OFFICER01', 'BANK_OFFICER', 'ST0003', NULL
    UNION ALL SELECT N'SB_OFFICER02', N'SB_OFFICER02', 'BANK_OFFICER', 'ST0004', NULL
    UNION ALL SELECT N'SB_CUSTOMER01', N'SB_CUSTOMER01', 'CUSTOMER', NULL, 'CU0001'
    UNION ALL SELECT N'SB_CUSTOMER02', N'SB_CUSTOMER02', 'CUSTOMER', NULL, 'CU0002'
    UNION ALL SELECT N'SB_CUSTOMER03', N'SB_CUSTOMER03', 'CUSTOMER', NULL, 'CU0003'
    UNION ALL SELECT N'SB_AUDITOR01', N'SB_AUDITOR01', 'SECURITY_AUDITOR', NULL, NULL
) AS source
ON target.DatabaseUserName = source.DatabaseUserName
WHEN MATCHED THEN
    UPDATE SET LoginName = source.LoginName,
               RoleCode = source.RoleCode,
               StaffID = source.StaffID,
               CustomerID = source.CustomerID,
               IsActive = 1
WHEN NOT MATCHED THEN
    INSERT (DatabaseUserName, LoginName, RoleCode, StaffID, CustomerID)
    VALUES (source.DatabaseUserName, source.LoginName, source.RoleCode, source.StaffID, source.CustomerID);
GO

SELECT
    p.name AS DatabaseUser,
    r.name AS DatabaseRole,
    m.RoleCode,
    m.StaffID,
    m.CustomerID,
    m.IsActive
FROM sys.database_principals AS p
LEFT JOIN sys.database_role_members AS drm
    ON drm.member_principal_id = p.principal_id
LEFT JOIN sys.database_principals AS r
    ON r.principal_id = drm.role_principal_id
LEFT JOIN sec.LoginIdentityMap AS m
    ON m.DatabaseUserName = p.name
WHERE p.name LIKE N'SB[_]%'
ORDER BY p.name;
GO

PRINT '03 authentication, roles, users, mappings, and sample data completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 04_Row_Level_Security_Views_and_Masking.sql
   ===================================================================== */

/*
SmartBankDB - Row-Level Security, secure views, and masking demonstration.
RLS protects Account and TransactionRecord even if a direct SELECT is granted accidentally.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. RLS predicate functions
   ------------------------------------------------------------------------- */
CREATE OR ALTER FUNCTION sec.fn_AccountAccessPredicate
(
    @CustomerID char(6)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS AccessAllowed
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.RoleCode IN ('BANK_MANAGER', 'BANK_OFFICER')
                  OR (m.RoleCode = 'CUSTOMER' AND m.CustomerID = @CustomerID)
              )
        )
);
GO

CREATE OR ALTER FUNCTION sec.fn_TransactionAccessPredicate
(
    @CustomerID char(6)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS AccessAllowed
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.RoleCode IN ('BANK_MANAGER', 'BANK_OFFICER')
                  OR (m.RoleCode = 'CUSTOMER' AND m.CustomerID = @CustomerID)
              )
        )
);
GO

/* -------------------------------------------------------------------------
   2. Security policies: filter reads and block unauthorized writes
   ------------------------------------------------------------------------- */
IF EXISTS (SELECT 1 FROM sys.security_policies WHERE name = N'AccountAccessPolicy')
    DROP SECURITY POLICY sec.AccountAccessPolicy;
GO

CREATE SECURITY POLICY sec.AccountAccessPolicy
ADD FILTER PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account,
ADD BLOCK PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account AFTER INSERT,
ADD BLOCK PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account AFTER UPDATE
WITH (STATE = ON, SCHEMABINDING = ON);
GO

IF EXISTS (SELECT 1 FROM sys.security_policies WHERE name = N'TransactionAccessPolicy')
    DROP SECURITY POLICY sec.TransactionAccessPolicy;
GO

CREATE SECURITY POLICY sec.TransactionAccessPolicy
ADD FILTER PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord,
ADD BLOCK PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord AFTER INSERT,
ADD BLOCK PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord AFTER UPDATE
WITH (STATE = ON, SCHEMABINDING = ON);
GO

/* -------------------------------------------------------------------------
   3. Views
   ------------------------------------------------------------------------- */
CREATE OR ALTER VIEW sec.vw_PublicStaffDirectory
AS
    SELECT StaffName, Phone
    FROM bank.Staff
    WHERE IsActive = 1;
GO

CREATE OR ALTER VIEW sec.vw_StaffBasicAccess
AS
    SELECT
        s.StaffID,
        s.StaffName,
        s.Position,
        s.Branch,
        s.Phone,
        s.IsActive,
        s.ModifiedAt,
        s.ModifiedBy
    FROM bank.Staff AS s
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.StaffID = s.StaffID
                  OR (m.RoleCode = 'BANK_MANAGER' AND s.Position = 'Bank Officer')
              )
        );
GO

CREATE OR ALTER VIEW sec.vw_AccountAccess
AS
    SELECT
        AccountID,
        CustomerID,
        AccountType,
        Balance,
        AccountStatus,
        OpenedAt,
        ClosedAt,
        ModifiedAt
    FROM bank.Account;
GO

CREATE OR ALTER VIEW sec.vw_TransactionAccess
AS
    SELECT
        TransID,
        TransactionReference,
        TransferGroupID,
        CustomerID,
        AccountID,
        CounterpartyAccountID,
        TransDate,
        Amount,
        TransactionType,
        Direction,
        BalanceBefore,
        BalanceAfter,
        Remarks,
        InitiatedByLogin
    FROM bank.TransactionRecord;
GO

/* DDM is preserved through this view. Manager sees masked contact values.
   Bank Officer receives UNMASK later because the role requires customer servicing. */
CREATE OR ALTER VIEW sec.vw_CustomerContact
AS
    SELECT
        CustomerID,
        CustomerName,
        Email,
        Phone,
        DateOfBirth,
        CustomerStatus,
        ModifiedAt
    FROM bank.Customer;
GO

CREATE OR ALTER VIEW reporting.vw_BranchAccountSummary
AS
    SELECT
        s.Branch,
        a.AccountType,
        COUNT_BIG(*) AS NumberOfAccounts,
        SUM(a.Balance) AS TotalBalance,
        AVG(a.Balance) AS AverageBalance
    FROM bank.Account AS a
    CROSS JOIN
    (
        SELECT TOP (1) Branch
        FROM bank.Staff
        WHERE Position = 'Bank Manager' AND IsActive = 1
        ORDER BY StaffID
    ) AS s
    GROUP BY s.Branch, a.AccountType;
GO

CREATE OR ALTER VIEW sec.vw_RoleUserMapping
AS
    SELECT
        roles.name AS RoleName,
        members.name AS UserName,
        map.RoleCode,
        map.StaffID,
        map.CustomerID,
        map.IsActive
    FROM sys.database_role_members AS drm
    INNER JOIN sys.database_principals AS roles
        ON roles.principal_id = drm.role_principal_id
    INNER JOIN sys.database_principals AS members
        ON members.principal_id = drm.member_principal_id
    LEFT JOIN sec.LoginIdentityMap AS map
        ON map.DatabaseUserName = members.name
    WHERE roles.name LIKE N'role[_]%';
GO

CREATE OR ALTER VIEW sec.vw_ExplicitRolePermissions
AS
    SELECT
        principal.name AS RoleName,
        permission.state_desc AS PermissionState,
        permission.permission_name AS PermissionName,
        permission.class_desc AS PermissionClass,
        CASE permission.class
            WHEN 0 THEN DB_NAME()
            WHEN 1 THEN QUOTENAME(OBJECT_SCHEMA_NAME(permission.major_id)) + N'.' + QUOTENAME(OBJECT_NAME(permission.major_id))
            WHEN 3 THEN QUOTENAME(SCHEMA_NAME(permission.major_id))
            ELSE CONVERT(nvarchar(128), permission.major_id)
        END AS SecurableName
    FROM sys.database_permissions AS permission
    INNER JOIN sys.database_principals AS principal
        ON principal.principal_id = permission.grantee_principal_id
    WHERE principal.name LIKE N'role[_]%';
GO

/* -------------------------------------------------------------------------
   4. Demonstration of RLS metadata and DDM metadata
   ------------------------------------------------------------------------- */
SELECT
    policy.name AS SecurityPolicy,
    predicate.predicate_type_desc,
    OBJECT_SCHEMA_NAME(predicate.target_object_id) AS TargetSchema,
    OBJECT_NAME(predicate.target_object_id) AS TargetTable,
    predicate.predicate_definition
FROM sys.security_policies AS policy
INNER JOIN sys.security_predicates AS predicate
    ON predicate.object_id = policy.object_id
ORDER BY policy.name, predicate.predicate_type_desc;

SELECT
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS ColumnName,
    masking_function
FROM sys.masked_columns
WHERE is_masked = 1
ORDER BY SchemaName, TableName, ColumnName;
GO

PRINT '04 RLS, views, and masking objects completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 05_Secure_Stored_Procedures.sql
   ===================================================================== */

/*
SmartBankDB - Controlled data access and modification procedures.
All procedures validate ORIGINAL_LOGIN(), apply least privilege, use transactions,
and write success/failure evidence to audit.BusinessActionLog.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* -------------------------------------------------------------------------
   1. Internal business-action audit writer
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE audit.usp_WriteBusinessAction
    @ActionCategory   varchar(30),
    @ActionName       nvarchar(128),
    @TargetObject     nvarchar(256) = NULL,
    @Success          bit,
    @ErrorNumber      int = NULL,
    @ErrorMessage     nvarchar(2048) = NULL,
    @KeyValuesJson    nvarchar(max) = NULL,
    @OldValuesJson    nvarchar(max) = NULL,
    @NewValuesJson    nvarchar(max) = NULL,
    @CorrelationID    uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname;
    DECLARE @RoleCode varchar(25);
    DECLARE @ClientAddress varchar(48) = CONVERT(varchar(48), CONNECTIONPROPERTY('client_net_address'));

    SELECT
        @DatabaseUserName = DatabaseUserName,
        @RoleCode = RoleCode
    FROM sec.LoginIdentityMap
    WHERE LoginName = @LoginName;

    INSERT audit.BusinessActionLog
    (
        LoginName, DatabaseUserName, RoleCode, SessionID, HostName,
        ApplicationName, ClientAddress, ActionCategory, ActionName,
        TargetObject, Success, ErrorNumber, ErrorMessage,
        KeyValuesJson, OldValuesJson, NewValuesJson, CorrelationID
    )
    VALUES
    (
        @LoginName,
        COALESCE(@DatabaseUserName, USER_NAME()),
        @RoleCode,
        @@SPID,
        HOST_NAME(),
        APP_NAME(),
        @ClientAddress,
        @ActionCategory,
        @ActionName,
        @TargetObject,
        @Success,
        @ErrorNumber,
        @ErrorMessage,
        @KeyValuesJson,
        @OldValuesJson,
        @NewValuesJson,
        COALESCE(@CorrelationID, NEWID())
    );
END;
GO

/* -------------------------------------------------------------------------
   2. Staff confidentiality and controlled management
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_GetMyStaffRecord
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @StaffID char(6);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @StaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER')
          AND IsActive = 1;

        IF @StaffID IS NULL
            THROW 51001, 'The current login is not mapped to an active staff record.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            s.StaffID,
            s.StaffName,
            s.Position,
            s.Branch,
            s.Phone,
            TRY_CONVERT(decimal(12,2),
                CONVERT(nvarchar(32),
                    DecryptByKey
                    (
                        sp.SalaryCipher,
                        1,
                        CONVERT(varbinary(128), s.StaffID)
                    )
                )
            ) AS Salary,
            sp.LastSalaryReviewDate,
            s.IsActive,
            s.ModifiedAt
        FROM bank.Staff AS s
        INNER JOIN bank.StaffPrivate AS sp
            ON sp.StaffID = s.StaffID
        WHERE s.StaffID = @StaffID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'VIEW_OWN_STAFF_RECORD',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'VIEW_OWN_STAFF_RECORD',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_GetStaffRecords
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @ManagerStaffID char(6);

    BEGIN TRY
        SELECT @ManagerStaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode = 'BANK_MANAGER'
          AND IsActive = 1;

        IF @ManagerStaffID IS NULL
            THROW 51002, 'Only an active Bank Manager may view manager-level staff records.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            s.StaffID,
            s.StaffName,
            s.Position,
            s.Branch,
            s.Phone,
            TRY_CONVERT(decimal(12,2),
                CONVERT(nvarchar(32),
                    DecryptByKey(sp.SalaryCipher, 1, CONVERT(varbinary(128), s.StaffID))
                )
            ) AS Salary,
            sp.LastSalaryReviewDate,
            s.IsActive,
            s.ModifiedAt
        FROM bank.Staff AS s
        INNER JOIN bank.StaffPrivate AS sp
            ON sp.StaffID = s.StaffID
        WHERE s.StaffID = @ManagerStaffID
           OR s.Position = 'Bank Officer'
        ORDER BY s.Position, s.StaffID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'MANAGER_VIEW_STAFF_RECORDS',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'MANAGER_VIEW_STAFF_RECORDS',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Staff_UpdateOwnRecord
    @Branch nvarchar(50) = NULL,
    @Phone varchar(20) = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @StaffID char(6);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @StaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER')
          AND IsActive = 1;

        IF @StaffID IS NULL
            THROW 51003, 'Only active staff may use staff self-service.', 1;

        IF @Branch IS NULL AND @Phone IS NULL
            THROW 51004, 'Provide at least one value to update.', 1;

        SELECT @OldJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        UPDATE bank.Staff
        SET Branch = COALESCE(@Branch, Branch),
            Phone = COALESCE(@Phone, Phone),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE StaffID = @StaffID;

        SELECT @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'STAFF_UPDATE_OWN_RECORD',
            @TargetObject = N'bank.Staff',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM sec.vw_StaffBasicAccess WHERE StaffID = @StaffID;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'STAFF_UPDATE_OWN_RECORD',
            @TargetObject = N'bank.Staff',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_CreateBankOfficer
    @StaffID char(6),
    @StaffName nvarchar(100),
    @Branch nvarchar(50),
    @Phone varchar(20),
    @Salary decimal(12,2)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_MANAGER' AND IsActive = 1
        )
            THROW 51005, 'Only an active Bank Manager may create a Bank Officer record.', 1;

        IF @Salary <= 0
            THROW 51006, 'Salary must be greater than zero.', 1;

        IF EXISTS (SELECT 1 FROM bank.Staff WHERE StaffID = @StaffID)
            THROW 51007, 'The StaffID already exists.', 1;

        BEGIN TRANSACTION;

        INSERT bank.Staff (StaffID, StaffName, Position, Branch, Phone)
        VALUES (@StaffID, @StaffName, 'Bank Officer', @Branch, @Phone);

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        INSERT bank.StaffPrivate
        (
            StaffID, SalaryCipher, SalaryIntegrityHash, LastSalaryReviewDate,
            ModifiedAt, ModifiedBy
        )
        VALUES
        (
            @StaffID,
            EncryptByKey
            (
                Key_GUID('SmartBankColumnKey'),
                CONVERT(varbinary(128), CONVERT(nvarchar(32), @Salary)),
                1,
                CONVERT(varbinary(128), @StaffID)
            ),
            HASHBYTES
            (
                'SHA2_256',
                CONVERT(nvarchar(20), @StaffID) + N'|' + CONVERT(nvarchar(32), @Salary) + N'|SmartBankSalaryIntegrity'
            ),
            CAST(SYSUTCDATETIME() AS date),
            SYSUTCDATETIME(),
            @LoginName
        );

        CLOSE SYMMETRIC KEY SmartBankColumnKey;
        COMMIT TRANSACTION;

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        SET @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(1 AS bit) AS SalaryEncrypted
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_CREATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_CREATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_UpdateBankOfficer
    @StaffID char(6),
    @StaffName nvarchar(100) = NULL,
    @Branch nvarchar(50) = NULL,
    @Phone varchar(20) = NULL,
    @Salary decimal(12,2) = NULL,
    @IsActive bit = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_MANAGER' AND IsActive = 1
        )
            THROW 51008, 'Only an active Bank Manager may update Bank Officer details.', 1;

        IF NOT EXISTS
        (
            SELECT 1 FROM bank.Staff
            WHERE StaffID = @StaffID AND Position = 'Bank Officer'
        )
            THROW 51009, 'The target StaffID is not a Bank Officer.', 1;

        IF @Salary IS NOT NULL AND @Salary <= 0
            THROW 51010, 'Salary must be greater than zero.', 1;

        SELECT @OldJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(CASE WHEN @Salary IS NULL THEN 0 ELSE 1 END AS bit) AS SalaryChangeRequested
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        BEGIN TRANSACTION;

        UPDATE bank.Staff
        SET StaffName = COALESCE(@StaffName, StaffName),
            Branch = COALESCE(@Branch, Branch),
            Phone = COALESCE(@Phone, Phone),
            IsActive = COALESCE(@IsActive, IsActive),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE StaffID = @StaffID;

        IF @Salary IS NOT NULL
        BEGIN
            OPEN SYMMETRIC KEY SmartBankColumnKey
                DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

            UPDATE bank.StaffPrivate
            SET SalaryCipher = EncryptByKey
                (
                    Key_GUID('SmartBankColumnKey'),
                    CONVERT(varbinary(128), CONVERT(nvarchar(32), @Salary)),
                    1,
                    CONVERT(varbinary(128), @StaffID)
                ),
                SalaryIntegrityHash = HASHBYTES
                (
                    'SHA2_256',
                    CONVERT(nvarchar(20), @StaffID) + N'|' + CONVERT(nvarchar(32), @Salary) + N'|SmartBankSalaryIntegrity'
                ),
                LastSalaryReviewDate = CAST(SYSUTCDATETIME() AS date),
                ModifiedAt = SYSUTCDATETIME(),
                ModifiedBy = @LoginName
            WHERE StaffID = @StaffID;

            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END;

        COMMIT TRANSACTION;

        SELECT @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(CASE WHEN @Salary IS NULL THEN 0 ELSE 1 END AS bit) AS SalaryChanged
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_UPDATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_UPDATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   3. Customer and account management by Bank Officers
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_Officer_CreateCustomer
    @CustomerID char(6),
    @CustomerName nvarchar(100),
    @Email varchar(254),
    @Phone varchar(20),
    @DateOfBirth date,
    @ICNumber nvarchar(30),
    @Address nvarchar(200)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @Salt uniqueidentifier = NEWID();
    DECLARE @NormalisedIC nvarchar(30);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51101, 'Only an active Bank Officer may create customer records.', 1;

        IF EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = @CustomerID)
            THROW 51102, 'The CustomerID already exists.', 1;

        IF @DateOfBirth >= CAST(SYSUTCDATETIME() AS date)
            THROW 51103, 'Date of birth must be earlier than today.', 1;

        SET @NormalisedIC = UPPER(REPLACE(REPLACE(LTRIM(RTRIM(@ICNumber)), '-', ''), ' ', ''));

        BEGIN TRANSACTION;
        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        INSERT bank.Customer
        (
            CustomerID, CustomerName, Email, Phone, DateOfBirth,
            ICNumberCipher, AddressCipher, HashSalt, ICNumberHash,
            CreatedBy, ModifiedBy
        )
        VALUES
        (
            @CustomerID,
            @CustomerName,
            @Email,
            @Phone,
            @DateOfBirth,
            EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), @ICNumber), 1, CONVERT(varbinary(128), @CustomerID)),
            EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), @Address), 1, CONVERT(varbinary(128), @CustomerID)),
            @Salt,
            HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt) + N'|' + @NormalisedIC),
            @LoginName,
            @LoginName
        );

        CLOSE SYMMETRIC KEY SmartBankColumnKey;
        COMMIT TRANSACTION;

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        SET @NewJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(1 AS bit) AS ICNumberEncrypted,
                   CAST(1 AS bit) AS AddressEncrypted,
                   CAST(1 AS bit) AS ICNumberHashed
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_UpdateCustomer
    @CustomerID char(6),
    @CustomerName nvarchar(100) = NULL,
    @Email varchar(254) = NULL,
    @Phone varchar(20) = NULL,
    @DateOfBirth date = NULL,
    @ICNumber nvarchar(30) = NULL,
    @Address nvarchar(200) = NULL,
    @CustomerStatus varchar(15) = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewSalt uniqueidentifier;
    DECLARE @NormalisedIC nvarchar(30);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51104, 'Only an active Bank Officer may update customer records.', 1;

        IF NOT EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = @CustomerID)
            THROW 51105, 'The CustomerID does not exist.', 1;

        IF @DateOfBirth IS NOT NULL AND @DateOfBirth >= CAST(SYSUTCDATETIME() AS date)
            THROW 51106, 'Date of birth must be earlier than today.', 1;

        SELECT @OldJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(CASE WHEN @ICNumber IS NULL THEN 0 ELSE 1 END AS bit) AS ICNumberChangeRequested,
                   CAST(CASE WHEN @Address IS NULL THEN 0 ELSE 1 END AS bit) AS AddressChangeRequested
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        BEGIN TRANSACTION;

        UPDATE bank.Customer
        SET CustomerName = COALESCE(@CustomerName, CustomerName),
            Email = COALESCE(@Email, Email),
            Phone = COALESCE(@Phone, Phone),
            DateOfBirth = COALESCE(@DateOfBirth, DateOfBirth),
            CustomerStatus = COALESCE(@CustomerStatus, CustomerStatus),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE CustomerID = @CustomerID;

        IF @ICNumber IS NOT NULL OR @Address IS NOT NULL
        BEGIN
            OPEN SYMMETRIC KEY SmartBankColumnKey
                DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

            IF @ICNumber IS NOT NULL
            BEGIN
                SET @NewSalt = NEWID();
                SET @NormalisedIC = UPPER(REPLACE(REPLACE(LTRIM(RTRIM(@ICNumber)), '-', ''), ' ', ''));

                UPDATE bank.Customer
                SET ICNumberCipher = EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), @ICNumber), 1, CONVERT(varbinary(128), @CustomerID)),
                    HashSalt = @NewSalt,
                    ICNumberHash = HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @NewSalt) + N'|' + @NormalisedIC)
                WHERE CustomerID = @CustomerID;
            END;

            IF @Address IS NOT NULL
            BEGIN
                UPDATE bank.Customer
                SET AddressCipher = EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), @Address), 1, CONVERT(varbinary(128), @CustomerID))
                WHERE CustomerID = @CustomerID;
            END;

            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END;

        COMMIT TRANSACTION;

        SELECT @NewJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(CASE WHEN @ICNumber IS NULL THEN 0 ELSE 1 END AS bit) AS ICNumberChanged,
                   CAST(CASE WHEN @Address IS NULL THEN 0 ELSE 1 END AS bit) AS AddressChanged
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_CreateAccount
    @AccountID char(10),
    @CustomerID char(6),
    @AccountType varchar(20)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51107, 'Only an active Bank Officer may create customer accounts.', 1;

        IF NOT EXISTS
        (
            SELECT 1 FROM bank.Customer
            WHERE CustomerID = @CustomerID AND CustomerStatus = 'Active'
        )
            THROW 51108, 'The customer does not exist or is not active.', 1;

        IF EXISTS (SELECT 1 FROM bank.Account WHERE AccountID = @AccountID)
            THROW 51109, 'The AccountID already exists.', 1;

        INSERT bank.Account
        (
            AccountID, CustomerID, AccountType, Balance,
            AccountStatus, CreatedBy, ModifiedBy
        )
        VALUES
        (
            @AccountID, @CustomerID, @AccountType, 0.00,
            'Active', @LoginName, @LoginName
        );

        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @CustomerID AS CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_ACCOUNT',
            @TargetObject = N'bank.Account',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @CustomerID AS CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_ACCOUNT',
            @TargetObject = N'bank.Account',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_UpdateAccountStatus
    @AccountID char(10),
    @NewStatus varchar(15)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @Balance decimal(15,2);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51110, 'Only an active Bank Officer may change account status.', 1;

        SELECT @Balance = Balance
        FROM bank.Account
        WHERE AccountID = @AccountID;

        IF @Balance IS NULL
            THROW 51111, 'The AccountID does not exist.', 1;

        IF @NewStatus = 'Closed' AND @Balance <> 0
            THROW 51112, 'An account can be closed only when its balance is zero.', 1;

        SELECT @OldJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus, ClosedAt
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        UPDATE bank.Account
        SET AccountStatus = @NewStatus,
            ClosedAt = CASE WHEN @NewStatus = 'Closed' THEN SYSUTCDATETIME() ELSE NULL END,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        SELECT @NewJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus, ClosedAt
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @AccountID AS AccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_ACCOUNT_STATUS',
            @TargetObject = N'bank.Account',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @AccountID AS AccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_ACCOUNT_STATUS',
            @TargetObject = N'bank.Account',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   4. Customer self-service confidentiality
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_GetMyCustomerProfile
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode = 'CUSTOMER'
          AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51201, 'The current login is not mapped to an active customer.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            CustomerID,
            CustomerName,
            Email,
            Phone,
            DateOfBirth,
            CONVERT(nvarchar(30),
                DecryptByKey(ICNumberCipher, 1, CONVERT(varbinary(128), CustomerID))
            ) AS ICNumber,
            CONVERT(nvarchar(200),
                DecryptByKey(AddressCipher, 1, CONVERT(varbinary(128), CustomerID))
            ) AS Address,
            CustomerStatus,
            ModifiedAt
        FROM bank.Customer
        WHERE CustomerID = @CustomerID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'CUSTOMER_VIEW_OWN_DECRYPTED_PROFILE',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'CUSTOMER_VIEW_OWN_DECRYPTED_PROFILE',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   5. Customer-only financial transactions
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_Customer_Deposit
    @AccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @BalanceBefore decimal(15,2);
    DECLARE @BalanceAfter decimal(15,2);
    DECLARE @TransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51301, 'Only an active Customer may perform a deposit.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51302, 'Deposit amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT * FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey;
            RETURN;
        END;

        BEGIN TRANSACTION;

        SELECT @BalanceBefore = Balance
        FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccountID = @AccountID
          AND CustomerID = @CustomerID
          AND AccountStatus = 'Active';

        IF @BalanceBefore IS NULL
            THROW 51303, 'The account is not active or is not owned by the current customer.', 1;

        SET @BalanceAfter = @BalanceBefore + @Amount;

        UPDATE bank.Account
        SET Balance = @BalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        INSERT bank.TransactionRecord
        (
            CustomerID, AccountID, Amount, TransactionType, Direction,
            BalanceBefore, BalanceAfter, Remarks, IdempotencyKey,
            InitiatedByLogin
        )
        VALUES
        (
            @CustomerID, @AccountID, @Amount, 'Deposit', 'Credit',
            @BalanceBefore, @BalanceAfter, COALESCE(@Remarks, N'Customer deposit'),
            @IdempotencyKey, @LoginName
        );

        SET @TransID = CONVERT(bigint, SCOPE_IDENTITY());
        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransID AS TransID, @AccountID AS AccountID, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @AccountID AS AccountID, @BalanceBefore AS Balance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @AccountID AS AccountID, @BalanceAfter AS Balance, @Amount AS DepositAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_DEPOSIT',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM bank.TransactionRecord WHERE TransID = @TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @Amount AS AttemptedAmount, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_DEPOSIT',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Customer_Withdraw
    @AccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @BalanceBefore decimal(15,2);
    DECLARE @BalanceAfter decimal(15,2);
    DECLARE @TransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51304, 'Only an active Customer may perform a withdrawal.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51305, 'Withdrawal amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT * FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey;
            RETURN;
        END;

        BEGIN TRANSACTION;

        SELECT @BalanceBefore = Balance
        FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccountID = @AccountID
          AND CustomerID = @CustomerID
          AND AccountStatus = 'Active';

        IF @BalanceBefore IS NULL
            THROW 51306, 'The account is not active or is not owned by the current customer.', 1;
        IF @BalanceBefore < @Amount
            THROW 51307, 'Insufficient funds for the withdrawal.', 1;

        SET @BalanceAfter = @BalanceBefore - @Amount;

        UPDATE bank.Account
        SET Balance = @BalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        INSERT bank.TransactionRecord
        (
            CustomerID, AccountID, Amount, TransactionType, Direction,
            BalanceBefore, BalanceAfter, Remarks, IdempotencyKey,
            InitiatedByLogin
        )
        VALUES
        (
            @CustomerID, @AccountID, @Amount, 'Withdrawal', 'Debit',
            @BalanceBefore, @BalanceAfter, COALESCE(@Remarks, N'Customer withdrawal'),
            @IdempotencyKey, @LoginName
        );

        SET @TransID = CONVERT(bigint, SCOPE_IDENTITY());
        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransID AS TransID, @AccountID AS AccountID, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @AccountID AS AccountID, @BalanceBefore AS Balance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @AccountID AS AccountID, @BalanceAfter AS Balance, @Amount AS WithdrawalAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_WITHDRAWAL',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM bank.TransactionRecord WHERE TransID = @TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @Amount AS AttemptedAmount, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_WITHDRAWAL',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Customer_Transfer
    @FromAccountID char(10),
    @ToAccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @SourceCustomerID char(6);
    DECLARE @DestinationCustomerID char(6);
    DECLARE @FromBalanceBefore decimal(15,2);
    DECLARE @ToBalanceBefore decimal(15,2);
    DECLARE @FromBalanceAfter decimal(15,2);
    DECLARE @ToBalanceAfter decimal(15,2);
    DECLARE @TransferGroupID uniqueidentifier = NEWID();
    DECLARE @SourceTransID bigint;
    DECLARE @DestinationTransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @SourceCustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @SourceCustomerID IS NULL
            THROW 51308, 'Only an active Customer may perform a transfer.', 1;
        IF @FromAccountID = @ToAccountID
            THROW 51309, 'Source and destination accounts must be different.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51310, 'Transfer amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT *
            FROM bank.TransactionRecord
            WHERE TransferGroupID =
            (
                SELECT TransferGroupID
                FROM bank.TransactionRecord
                WHERE IdempotencyKey = @IdempotencyKey
            )
            ORDER BY TransID;
            RETURN;
        END;

        BEGIN TRANSACTION;

        /* Deterministic lock order reduces transfer deadlocks. */
        IF @FromAccountID < @ToAccountID
        BEGIN
            SELECT @FromBalanceBefore = Balance
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @FromAccountID
              AND CustomerID = @SourceCustomerID
              AND AccountStatus = 'Active';

            SELECT @ToBalanceBefore = Balance, @DestinationCustomerID = CustomerID
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @ToAccountID
              AND AccountStatus = 'Active';
        END
        ELSE
        BEGIN
            SELECT @ToBalanceBefore = Balance, @DestinationCustomerID = CustomerID
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @ToAccountID
              AND AccountStatus = 'Active';

            SELECT @FromBalanceBefore = Balance
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @FromAccountID
              AND CustomerID = @SourceCustomerID
              AND AccountStatus = 'Active';
        END;

        IF @FromBalanceBefore IS NULL
            THROW 51311, 'The source account is not active or is not owned by the current customer.', 1;
        IF @ToBalanceBefore IS NULL OR @DestinationCustomerID IS NULL
            THROW 51312, 'The destination account does not exist or is not active.', 1;
        IF @FromBalanceBefore < @Amount
            THROW 51313, 'Insufficient funds for the transfer.', 1;

        SET @FromBalanceAfter = @FromBalanceBefore - @Amount;
        SET @ToBalanceAfter = @ToBalanceBefore + @Amount;

        UPDATE bank.Account
        SET Balance = @FromBalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @FromAccountID;

        UPDATE bank.Account
        SET Balance = @ToBalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @ToAccountID;

        INSERT bank.TransactionRecord
        (
            TransferGroupID, CustomerID, AccountID, CounterpartyAccountID,
            Amount, TransactionType, Direction, BalanceBefore, BalanceAfter,
            Remarks, IdempotencyKey, InitiatedByLogin
        )
        VALUES
        (
            @TransferGroupID, @SourceCustomerID, @FromAccountID, @ToAccountID,
            @Amount, 'Transfer', 'Debit', @FromBalanceBefore, @FromBalanceAfter,
            COALESCE(@Remarks, N'Customer transfer - outgoing'), @IdempotencyKey, @LoginName
        );
        SET @SourceTransID = CONVERT(bigint, SCOPE_IDENTITY());

        INSERT bank.TransactionRecord
        (
            TransferGroupID, CustomerID, AccountID, CounterpartyAccountID,
            Amount, TransactionType, Direction, BalanceBefore, BalanceAfter,
            Remarks, IdempotencyKey, InitiatedByLogin
        )
        VALUES
        (
            @TransferGroupID, @DestinationCustomerID, @ToAccountID, @FromAccountID,
            @Amount, 'Transfer', 'Credit', @ToBalanceBefore, @ToBalanceAfter,
            COALESCE(@Remarks, N'Customer transfer - incoming'), NULL, @LoginName
        );
        SET @DestinationTransID = CONVERT(bigint, SCOPE_IDENTITY());

        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransferGroupID AS TransferGroupID,
                   @SourceTransID AS SourceTransID,
                   @DestinationTransID AS DestinationTransID,
                   @FromAccountID AS FromAccountID,
                   @ToAccountID AS ToAccountID,
                   @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @FromBalanceBefore AS SourceBalance,
                   @ToBalanceBefore AS DestinationBalance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @FromBalanceAfter AS SourceBalance,
                   @ToBalanceAfter AS DestinationBalance,
                   @Amount AS TransferAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_TRANSFER',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson,
            @CorrelationID = @TransferGroupID;

        SELECT *
        FROM bank.TransactionRecord
        WHERE TransferGroupID = @TransferGroupID
        ORDER BY TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @FromAccountID AS FromAccountID,
                   @ToAccountID AS ToAccountID,
                   @Amount AS AttemptedAmount,
                   @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_TRANSFER',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson,
            @CorrelationID = @TransferGroupID;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   6. Non-production static masking / anonymisation refresh
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE reporting.usp_RefreshCustomerAnalyticsMasked
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SnapshotUtc datetime2(3) = SYSUTCDATETIME();

    BEGIN TRY
        BEGIN TRANSACTION;
        TRUNCATE TABLE reporting.CustomerAnalyticsMasked;

        INSERT reporting.CustomerAnalyticsMasked
        (
            CustomerToken, CustomerAlias, EmailDomain, PhoneMasked,
            AgeBand, AccountCount, TotalBalanceBand, SnapshotUtc
        )
        SELECT
            CONVERT(char(64), HASHBYTES('SHA2_256', CONVERT(nvarchar(36), c.HashSalt) + N'|' + c.CustomerID), 2),
            N'Customer-' + RIGHT(c.CustomerID, 4),
            CASE WHEN CHARINDEX('@', c.Email) > 0 THEN SUBSTRING(c.Email, CHARINDEX('@', c.Email) + 1, 254) END,
            REPLICATE('X', CASE WHEN LEN(c.Phone) > 4 THEN LEN(c.Phone) - 4 ELSE 0 END) + RIGHT(c.Phone, 4),
            CASE
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) < 21 THEN 'Under 21'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 21 AND 30 THEN '21-30'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 31 AND 45 THEN '31-45'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 46 AND 60 THEN '46-60'
                ELSE '61+'
            END,
            COUNT(a.AccountID),
            CASE
                WHEN COALESCE(SUM(a.Balance), 0) < 5000 THEN 'Below 5,000'
                WHEN COALESCE(SUM(a.Balance), 0) < 20000 THEN '5,000-19,999'
                WHEN COALESCE(SUM(a.Balance), 0) < 100000 THEN '20,000-99,999'
                ELSE '100,000+'
            END,
            @SnapshotUtc
        FROM bank.Customer AS c
        LEFT JOIN bank.Account AS a
            ON a.CustomerID = c.CustomerID
        GROUP BY c.CustomerID, c.HashSalt, c.Email, c.Phone, c.DateOfBirth;

        COMMIT TRANSACTION;

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_PROTECTION',
            @ActionName = N'REFRESH_STATIC_MASKED_ANALYTICS',
            @TargetObject = N'reporting.CustomerAnalyticsMasked',
            @Success = 1;

        SELECT * FROM reporting.CustomerAnalyticsMasked ORDER BY CustomerAlias;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_PROTECTION',
            @ActionName = N'REFRESH_STATIC_MASKED_ANALYTICS',
            @TargetObject = N'reporting.CustomerAnalyticsMasked',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

EXEC reporting.usp_RefreshCustomerAnalyticsMasked;
GO

PRINT '05 secure stored procedures completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 06_Auditing_DML_DDL_Login_Logout_and_Permissions.sql
   ===================================================================== */

/*
SmartBankDB - Defence-in-depth auditing
1. SQL Server Audit: login, logout, DML, DDL, and permission changes.
2. DML triggers: before/after JSON for successful changes.
3. Database DDL trigger: command text and EVENTDATA for DDL/security changes.
4. BusinessActionLog: successful and failed business operations.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Audit matrix stored inside the database
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'audit.AuditMatrix', N'U') IS NULL
BEGIN
    CREATE TABLE audit.AuditMatrix
    (
        AuditMatrixID      int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditMatrix PRIMARY KEY,
        AuditArea          nvarchar(80) NOT NULL,
        EventsCaptured     nvarchar(500) NOT NULL,
        ObjectsCovered     nvarchar(500) NOT NULL,
        Mechanism          nvarchar(300) NOT NULL,
        LogLocation        nvarchar(500) NOT NULL,
        ReviewResponsibility nvarchar(200) NOT NULL,
        RetentionGuideline nvarchar(200) NOT NULL
    );
END;
GO

TRUNCATE TABLE audit.AuditMatrix;
INSERT audit.AuditMatrix
(
    AuditArea, EventsCaptured, ObjectsCovered, Mechanism,
    LogLocation, ReviewResponsibility, RetentionGuideline
)
VALUES
(N'Login and logout', N'Successful login, failed login, and logout events.', N'All SQL Server logins, especially SB_* demo users.', N'SQL Server Audit server action groups.', N'SmartBankAudit folder configured in admin.Configuration.', N'Security Auditor / DBA oversight.', N'Minimum 90 days for the assignment demonstration.'),
(N'Data access', N'SELECT and stored-procedure execution, including success or failure.', N'bank schema and api schema.', N'SQL Server Database Audit Specification.', N'.sqlaudit files.', N'Security Auditor.', N'Minimum 90 days.'),
(N'Valid DML', N'INSERT, UPDATE, DELETE with before/after images.', N'bank.Staff, StaffPrivate, Customer, Account, TransactionRecord.', N'AFTER DML triggers plus SQL Server Audit.', N'audit.DMLChangeLog and .sqlaudit files.', N'Security Auditor and investigation team.', N'Minimum 1 year for financial-change evidence.'),
(N'Invalid business action', N'Invalid amount, insufficient balance, wrong ownership, invalid role, and other rejected procedure calls.', N'api stored procedures.', N'TRY/CATCH logging to audit.BusinessActionLog.', N'audit.BusinessActionLog.', N'Security Auditor.', N'Minimum 1 year.'),
(N'Invalid direct DML', N'Permission denied or RLS-blocked INSERT, UPDATE, DELETE.', N'bank schema.', N'SQL Server Audit records succeeded = 0.', N'.sqlaudit files.', N'Security Auditor.', N'Minimum 1 year.'),
(N'DDL', N'CREATE, ALTER, DROP, and other database-level definition events.', N'Database, schemas, tables, views, procedures, functions, triggers, keys, and certificates.', N'Database DDL trigger plus SQL Server Audit action groups.', N'audit.DDLSecurityChangeLog and .sqlaudit files.', N'Security Auditor / DBA oversight.', N'Minimum 1 year.'),
(N'Permission changes', N'GRANT, DENY, REVOKE, CREATE/ALTER/DROP USER or ROLE, and role membership changes.', N'Server logins, database users, roles, and securables.', N'DDL trigger plus server/database audit permission action groups.', N'audit.DDLSecurityChangeLog and .sqlaudit files.', N'Security Auditor.', N'Minimum 1 year.'),
(N'Backup operations', N'Full, differential, and log backup status, verification status, and failures.', N'SmartBankDB backup jobs.', N'Backup procedure evidence table plus msdb backup/job history.', N'audit.BackupEvidence, msdb, and backup files.', N'DBA and Security Auditor.', N'Keep enough generations to satisfy RPO and restore testing.');
GO

/* -------------------------------------------------------------------------
   2. Successful DML change triggers
   Trigger schema matches the target-table schema, preventing Msg 2103.
   ------------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER bank.trg_Staff_DMLAudit
ON bank.Staff
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Staff', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_StaffPrivate_DMLAudit
ON bank.StaffPrivate
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'StaffPrivate', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_Customer_DMLAudit
ON bank.Customer
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Customer', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_Account_DMLAudit
ON bank.Account
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Account', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_TransactionRecord_DMLAudit
ON bank.TransactionRecord
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'TransactionRecord', @Action, @Rows, @OldJson, @NewJson);
END;
GO

/* -------------------------------------------------------------------------
   3. Database-level DDL and permission-change trigger
   A DDL trigger has no schema prefix, preventing Msg 1094.
   ------------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER trg_DatabaseDDLAndPermissionAudit
ON DATABASE
WITH EXECUTE AS 'dbo'
FOR DDL_DATABASE_LEVEL_EVENTS
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @EventData xml = EVENTDATA();

    INSERT audit.DDLSecurityChangeLog
    (
        LoginName, DatabaseUserName, EventType, ObjectType,
        SchemaName, ObjectName, TSQLCommand, EventDataXml,
        HostName, ApplicationName
    )
    VALUES
    (
        ORIGINAL_LOGIN(),
        COALESCE(@EventData.value('(/EVENT_INSTANCE/UserName)[1]', 'sysname'), USER_NAME()),
        @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'sysname'),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/ObjectType)[1]', 'sysname'), N''),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/SchemaName)[1]', 'sysname'), N''),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'sysname'), N''),
        @EventData.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'nvarchar(max)'),
        @EventData,
        HOST_NAME(),
        APP_NAME()
    );
END;
GO

/* -------------------------------------------------------------------------
   4. SQL Server Audit target and server audit specification
   ------------------------------------------------------------------------- */
USE master;
GO

IF EXISTS (SELECT 1 FROM sys.server_audit_specifications WHERE name = N'SmartBank_ServerAuditSpec')
BEGIN
    ALTER SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec WITH (STATE = OFF);
    DROP SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec;
END;
GO

IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = N'SmartBank_ServerAudit')
BEGIN
    ALTER SERVER AUDIT SmartBank_ServerAudit WITH (STATE = OFF);
    DROP SERVER AUDIT SmartBank_ServerAudit;
END;
GO

DECLARE @AuditPath nvarchar(4000) =
(
    SELECT ConfigValue
    FROM SmartBankDB.admin.Configuration
    WHERE ConfigKey = N'AuditPath'
);

IF @AuditPath IS NULL
    THROW 51401, 'AuditPath is missing from SmartBankDB.admin.Configuration.', 1;

BEGIN TRY
    EXEC master.dbo.xp_create_subdir @AuditPath;
END TRY
BEGIN CATCH
    PRINT 'Audit directory warning: ' + ERROR_MESSAGE();
END CATCH;

DECLARE @CreateAuditSql nvarchar(max) =
    N'CREATE SERVER AUDIT SmartBank_ServerAudit
      TO FILE
      (
          FILEPATH = N''' + REPLACE(@AuditPath, '''', '''''') + N''',
          MAXSIZE = 512 MB,
          MAX_ROLLOVER_FILES = 50,
          RESERVE_DISK_SPACE = OFF
      )
      WITH
      (
          QUEUE_DELAY = 1000,
          ON_FAILURE = CONTINUE
      );';
EXEC sys.sp_executesql @CreateAuditSql;
GO

CREATE SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec
FOR SERVER AUDIT SmartBank_ServerAudit
    ADD (SUCCESSFUL_LOGIN_GROUP),
    ADD (FAILED_LOGIN_GROUP),
    ADD (LOGOUT_GROUP),
    ADD (SERVER_PRINCIPAL_CHANGE_GROUP),
    ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
    ADD (SERVER_OBJECT_PERMISSION_CHANGE_GROUP),
    ADD (AUDIT_CHANGE_GROUP)
WITH (STATE = ON);
GO

ALTER SERVER AUDIT SmartBank_ServerAudit WITH (STATE = ON);
GO

/* -------------------------------------------------------------------------
   5. Database audit specification
   ------------------------------------------------------------------------- */
USE SmartBankDB;
GO

IF EXISTS (SELECT 1 FROM sys.database_audit_specifications WHERE name = N'SmartBank_DatabaseAuditSpec')
BEGIN
    ALTER DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec WITH (STATE = OFF);
    DROP DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec;
END;
GO

CREATE DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec
FOR SERVER AUDIT SmartBank_ServerAudit
    ADD (SELECT ON SCHEMA::bank BY public),
    ADD (INSERT, UPDATE, DELETE ON SCHEMA::bank BY public),
    ADD (EXECUTE ON SCHEMA::api BY public),
    ADD (DATABASE_OBJECT_CHANGE_GROUP),
    ADD (SCHEMA_OBJECT_CHANGE_GROUP),
    ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),
    ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),
    ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),
    ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)
WITH (STATE = ON);
GO

/* -------------------------------------------------------------------------
   6. Audit reporting views and procedure
   ------------------------------------------------------------------------- */
CREATE OR ALTER VIEW audit.vw_RecentBusinessActions
AS
    SELECT
        AuditID, EventTimeUtc, LoginName, DatabaseUserName, RoleCode,
        ActionCategory, ActionName, TargetObject, Success,
        ErrorNumber, ErrorMessage, KeyValuesJson, HostName, ApplicationName
    FROM audit.BusinessActionLog;
GO

CREATE OR ALTER VIEW audit.vw_RecentDMLChanges
AS
    SELECT
        ChangeAuditID, EventTimeUtc, LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson, HostName, ApplicationName
    FROM audit.DMLChangeLog;
GO

CREATE OR ALTER VIEW audit.vw_RecentDDLAndPermissionChanges
AS
    SELECT
        DDLAuditID, EventTimeUtc, LoginName, DatabaseUserName,
        EventType, ObjectType, SchemaName, ObjectName,
        TSQLCommand, HostName, ApplicationName
    FROM audit.DDLSecurityChangeLog;
GO

CREATE OR ALTER PROCEDURE audit.usp_ReadSqlServerAudit
    @TopRows int = 500,
    @LoginName sysname = NULL,
    @DatabaseName sysname = N'SmartBankDB'
WITH EXECUTE AS CALLER
AS
BEGIN
    SET NOCOUNT ON;

    IF IS_SRVROLEMEMBER('sysadmin') <> 1
       AND USER_NAME() <> N'SB_AUDITOR01'
        THROW 51402, 'Only a sysadmin or the designated Security Auditor may read consolidated audit output.', 1;

    DECLARE @AuditPath nvarchar(4000) =
    (
        SELECT ConfigValue
        FROM admin.Configuration
        WHERE ConfigKey = N'AuditPath'
    );

    DECLARE @Pattern nvarchar(4000) = @AuditPath + N'*.sqlaudit';

    SELECT TOP (@TopRows)
        event_time,
        sequence_number,
        action_id,
        succeeded,
        permission_bitmask,
        is_column_permission,
        session_id,
        server_principal_name,
        session_server_principal_name,
        database_principal_name,
        target_server_principal_name,
        target_database_principal_name,
        database_name,
        schema_name,
        object_name,
        statement,
        additional_information,
        application_name,
        client_ip
    FROM sys.fn_get_audit_file(@Pattern, DEFAULT, DEFAULT)
    WHERE (@LoginName IS NULL OR session_server_principal_name = @LoginName OR server_principal_name = @LoginName)
      AND (@DatabaseName IS NULL OR database_name = @DatabaseName OR database_name IS NULL)
    ORDER BY event_time DESC, sequence_number DESC;
END;
GO

SELECT
    s.name AS audit_specification_name,
    s.is_state_enabled,
    d.audit_action_name,
    d.class_desc,
    d.audited_result
FROM sys.database_audit_specifications AS s
INNER JOIN sys.database_audit_specification_details AS d
    ON d.database_specification_id = s.database_specification_id
ORDER BY s.name, d.audit_action_name;
GO

PRINT '06 auditing infrastructure completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 07_RBAC_Permissions_and_Authorization_Matrix.sql
   ===================================================================== */

/*
SmartBankDB - Role-Based Access Control and authorization matrix.
No business user receives direct permissions; all permissions are assigned to roles.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Authorization matrix documentation table
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.AuthorizationMatrix', N'U') IS NULL
BEGIN
    CREATE TABLE sec.AuthorizationMatrix
    (
        MatrixID              int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuthorizationMatrix PRIMARY KEY,
        RoleName              sysname NOT NULL,
        FunctionalArea        nvarchar(100) NOT NULL,
        RequiredAccess        nvarchar(300) NOT NULL,
        ImplementedUsing      nvarchar(500) NOT NULL,
        DirectBaseTableDML    varchar(10) NOT NULL,
        CONSTRAINT CK_AuthorizationMatrix_DML CHECK (DirectBaseTableDML IN ('Allowed', 'Denied', 'None'))
    );
END;
GO

TRUNCATE TABLE sec.AuthorizationMatrix;
INSERT sec.AuthorizationMatrix
(RoleName, FunctionalArea, RequiredAccess, ImplementedUsing, DirectBaseTableDML)
VALUES
(N'role_dba', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_dba', N'Own staff record', N'View and update own staff record except salary update.', N'api.usp_GetMyStaffRecord and api.usp_Staff_UpdateOwnRecord.', 'Denied'),
(N'role_dba', N'Database definition', N'Create and manage bank tables, but not business data.', N'CREATE TABLE plus ALTER on bank/history schemas; explicit SELECT/INSERT/UPDATE/DELETE DENY.', 'Denied'),
(N'role_bank_manager', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_bank_manager', N'Staff records', N'View own record and all Bank Officer records; manage officer details and salary.', N'Secure encrypted-data procedures and filtered staff view.', 'Denied'),
(N'role_bank_manager', N'Accounts and transactions', N'View all customer accounts and transactions.', N'SELECT on RLS-protected account and transaction views; predicate allows manager role.', 'Denied'),
(N'role_bank_officer', N'Own staff record', N'View and update own staff record except salary.', N'api.usp_GetMyStaffRecord and api.usp_Staff_UpdateOwnRecord.', 'Denied'),
(N'role_bank_officer', N'Customer accounts', N'View all accounts/transactions; onboard customers; create/update account status.', N'RLS-protected views, officer procedures, and UNMASK for operational contact data.', 'Denied'),
(N'role_customer', N'Public staff directory', N'View all staff names and contact numbers.', N'SELECT on sec.vw_PublicStaffDirectory.', 'Denied'),
(N'role_customer', N'Own profile', N'View own decrypted sensitive information.', N'api.usp_GetMyCustomerProfile automatically opens the key and filters by ORIGINAL_LOGIN().', 'Denied'),
(N'role_customer', N'Own accounts and transactions', N'View only own rows.', N'RLS policies on bank.Account and bank.TransactionRecord.', 'Denied'),
(N'role_customer', N'Financial transactions', N'Perform valid deposit, withdrawal and transfer only.', N'Transactional stored procedures with ownership, amount, balance, status and idempotency checks.', 'Denied'),
(N'role_security_auditor', N'Audit evidence', N'Read audit matrix, business, DML, DDL, permission, login/logout and backup evidence.', N'Read-only permissions on audit schema and SQL Server Audit reader.', 'Denied');
GO

/* -------------------------------------------------------------------------
   2. Baseline denials - business roles cannot manipulate base tables directly
   ------------------------------------------------------------------------- */
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_dba;
DENY SELECT ON SCHEMA::bank TO role_dba;

DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_bank_manager;
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_bank_officer;
DENY INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_customer;
DENY SELECT, INSERT, UPDATE, DELETE ON SCHEMA::bank TO role_security_auditor;
GO

/* No non-DBA business role may create or manage tables. */
DENY CREATE TABLE TO role_bank_manager;
DENY CREATE TABLE TO role_bank_officer;
DENY CREATE TABLE TO role_customer;
DENY CREATE TABLE TO role_security_auditor;
GO

/* -------------------------------------------------------------------------
   3. DBA role: table definition only, plus own staff functions
   ------------------------------------------------------------------------- */
GRANT CREATE TABLE TO role_dba;
GRANT ALTER ON SCHEMA::bank TO role_dba;
GRANT ALTER ON SCHEMA::history TO role_dba;
GRANT VIEW DEFINITION ON SCHEMA::bank TO role_dba;
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_dba;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_dba;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_dba;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_dba;
GO

/* -------------------------------------------------------------------------
   4. Bank Manager role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_bank_manager;
GRANT SELECT ON OBJECT::sec.vw_CustomerContact TO role_bank_manager;
GRANT SELECT ON OBJECT::reporting.vw_BranchAccountSummary TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_GetStaffRecords TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_CreateBankOfficer TO role_bank_manager;
GRANT EXECUTE ON OBJECT::api.usp_Manager_UpdateBankOfficer TO role_bank_manager;
GO

/* -------------------------------------------------------------------------
   5. Bank Officer role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_StaffBasicAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_bank_officer;
GRANT SELECT ON OBJECT::sec.vw_CustomerContact TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_GetMyStaffRecord TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Staff_UpdateOwnRecord TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_CreateCustomer TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_UpdateCustomer TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_CreateAccount TO role_bank_officer;
GRANT EXECUTE ON OBJECT::api.usp_Officer_UpdateAccountStatus TO role_bank_officer;
GRANT UNMASK TO role_bank_officer;
GO

/* -------------------------------------------------------------------------
   6. Customer role
   ------------------------------------------------------------------------- */
GRANT SELECT ON OBJECT::sec.vw_PublicStaffDirectory TO role_customer;
GRANT SELECT ON OBJECT::sec.vw_AccountAccess TO role_customer;
GRANT SELECT ON OBJECT::sec.vw_TransactionAccess TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_GetMyCustomerProfile TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Deposit TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Withdraw TO role_customer;
GRANT EXECUTE ON OBJECT::api.usp_Customer_Transfer TO role_customer;
GO

/* -------------------------------------------------------------------------
   7. Security Auditor role - separation of duties
   ------------------------------------------------------------------------- */
GRANT SELECT ON SCHEMA::audit TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.vw_RoleUserMapping TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.vw_ExplicitRolePermissions TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.AuthorizationMatrix TO role_security_auditor;
GRANT SELECT ON OBJECT::sec.DataDictionary TO role_security_auditor;
GRANT SELECT ON OBJECT::reporting.CustomerAnalyticsMasked TO role_security_auditor;
GRANT EXECUTE ON OBJECT::audit.usp_ReadSqlServerAudit TO role_security_auditor;
GRANT VIEW DEFINITION ON DATABASE::SmartBankDB TO role_security_auditor;
GO

/* SQL Server 2022+ granular permission for reading .sqlaudit files. */
USE master;
GO
BEGIN TRY
    GRANT VIEW SERVER SECURITY AUDIT TO SB_AUDITOR01;
END TRY
BEGIN CATCH
    PRINT 'VIEW SERVER SECURITY AUDIT is not supported by this SQL Server version.';
    PRINT 'Use a sysadmin login to query the .sqlaudit file during the demonstration.';
END CATCH;
GO

USE SmartBankDB;
GO

/* -------------------------------------------------------------------------
   8. Proof: users, memberships, and explicit role permissions
   ------------------------------------------------------------------------- */
SELECT * FROM sec.vw_RoleUserMapping ORDER BY RoleName, UserName;
SELECT * FROM sec.vw_ExplicitRolePermissions ORDER BY RoleName, PermissionState, SecurableName, PermissionName;
SELECT * FROM sec.AuthorizationMatrix ORDER BY RoleName, MatrixID;
GO

PRINT '07 RBAC and permissions completed successfully.';
GO

/* =====================================================================
   INCLUDED FILE: 08_Encrypted_Backup_Automation_and_Readiness.sql
   ===================================================================== */

/*
SmartBankDB - Encrypted backup strategy and SQL Server Agent automation
RPO: 15 minutes. RTO target: 60 minutes in the lab.
Schedules:
- Full: daily 01:00
- Differential: every 6 hours from 07:00
- Transaction log: every 15 minutes

Requires SQL Server Developer/Standard and SQL Server Agent running.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Backup procedure with AES-256, compression, checksum and VERIFYONLY
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE admin.usp_RunBackup
    @BackupType varchar(12),
    @JobName sysname = NULL
WITH EXECUTE AS CALLER
AS
BEGIN
    SET NOCOUNT ON;

    IF IS_SRVROLEMEMBER('sysadmin') <> 1
        THROW 51501, 'Only a sysadmin or a sysadmin-owned SQL Agent job may run database backups.', 1;

    SET @BackupType = UPPER(LTRIM(RTRIM(@BackupType)));
    IF @BackupType NOT IN ('FULL', 'DIFFERENTIAL', 'LOG')
        THROW 51502, 'BackupType must be FULL, DIFFERENTIAL, or LOG.', 1;

    DECLARE @BackupPath nvarchar(4000) =
    (
        SELECT ConfigValue
        FROM admin.Configuration
        WHERE ConfigKey = N'BackupPath'
    );
    DECLARE @Timestamp char(15) =
        CONVERT(char(8), GETDATE(), 112) + N'_' + REPLACE(CONVERT(char(8), GETDATE(), 108), ':', '');
    DECLARE @Extension varchar(4) = CASE WHEN @BackupType = 'LOG' THEN '.trn' ELSE '.bak' END;
    DECLARE @BackupFile nvarchar(4000) =
        @BackupPath + N'SmartBankDB_' + @BackupType + N'_' + @Timestamp + @Extension;
    DECLARE @BackupStartUtc datetime2(3) = SYSUTCDATETIME();
    DECLARE @BackupFinishUtc datetime2(3);
    DECLARE @BackupSql nvarchar(max);
    DECLARE @VerifySql nvarchar(max);

    BEGIN TRY
        IF @BackupPath IS NULL
            THROW 51503, 'BackupPath is missing from admin.Configuration.', 1;

        BEGIN TRY
            EXEC master.dbo.xp_create_subdir @BackupPath;
        END TRY
        BEGIN CATCH
            PRINT 'Backup directory warning: ' + ERROR_MESSAGE();
        END CATCH;

        IF @BackupType = 'FULL'
        BEGIN
            SET @BackupSql =
                N'BACKUP DATABASE SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;
        ELSE IF @BackupType = 'DIFFERENTIAL'
        BEGIN
            SET @BackupSql =
                N'BACKUP DATABASE SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH DIFFERENTIAL, INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;
        ELSE
        BEGIN
            SET @BackupSql =
                N'BACKUP LOG SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;

        EXEC sys.sp_executesql @BackupSql;

        SET @VerifySql =
            N'RESTORE VERIFYONLY FROM DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N''' WITH CHECKSUM;';
        EXEC sys.sp_executesql @VerifySql;

        SET @BackupFinishUtc = SYSUTCDATETIME();

        INSERT audit.BackupEvidence
        (
            BackupStartUtc, BackupFinishUtc, BackupType, BackupFile,
            Encrypted, CompressionUsed, ChecksumUsed, VerifyOnlyPassed,
            Success, ErrorMessage, ExecutedBy, SqlAgentJobName
        )
        VALUES
        (
            @BackupStartUtc, @BackupFinishUtc, @BackupType, @BackupFile,
            1, 1, 1, 1,
            1, NULL, ORIGINAL_LOGIN(), @JobName
        );

        SELECT
            @BackupType AS BackupType,
            @BackupFile AS BackupFile,
            @BackupStartUtc AS BackupStartUtc,
            @BackupFinishUtc AS BackupFinishUtc,
            CAST(1 AS bit) AS Encrypted,
            CAST(1 AS bit) AS VerifyOnlyPassed;
    END TRY
    BEGIN CATCH
        SET @BackupFinishUtc = SYSUTCDATETIME();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        INSERT audit.BackupEvidence
        (
            BackupStartUtc, BackupFinishUtc, BackupType, BackupFile,
            Encrypted, CompressionUsed, ChecksumUsed, VerifyOnlyPassed,
            Success, ErrorMessage, ExecutedBy, SqlAgentJobName
        )
        VALUES
        (
            @BackupStartUtc, @BackupFinishUtc, @BackupType,
            COALESCE(@BackupFile, N'Not created'),
            1, 1, 1, 0,
            0, @ErrorMessage, ORIGINAL_LOGIN(), @JobName
        );
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   2. Export backup certificate and private key for another-instance restore
   ------------------------------------------------------------------------- */
DECLARE @BackupPath nvarchar(4000) =
(
    SELECT ConfigValue FROM admin.Configuration WHERE ConfigKey = N'BackupPath'
);
DECLARE @CertPassword nvarchar(128) =
(
    SELECT ConfigValue FROM admin.Configuration WHERE ConfigKey = N'CertificateExportPassword'
);
DECLARE @CertFile nvarchar(4000) = @BackupPath + N'SmartBankBackupCertificate.cer';
DECLARE @PrivateKeyFile nvarchar(4000) = @BackupPath + N'SmartBankBackupCertificate_PrivateKey.pvk';
DECLARE @CertExists int;
DECLARE @KeyExists int;
DECLARE @FileCheck TABLE (FileExists int, FileIsDirectory int, ParentDirectoryExists int);

INSERT @FileCheck EXEC master.dbo.xp_fileexist @CertFile;
SELECT @CertExists = FileExists FROM @FileCheck;
DELETE FROM @FileCheck;
INSERT @FileCheck EXEC master.dbo.xp_fileexist @PrivateKeyFile;
SELECT @KeyExists = FileExists FROM @FileCheck;

IF COALESCE(@CertExists, 0) = 0 OR COALESCE(@KeyExists, 0) = 0
BEGIN
    DECLARE @ExportSql nvarchar(max) =
        N'USE master;
          BACKUP CERTIFICATE SmartBankBackupCertificate
          TO FILE = N''' + REPLACE(@CertFile, '''', '''''') + N'''
          WITH PRIVATE KEY
          (
              FILE = N''' + REPLACE(@PrivateKeyFile, '''', '''''') + N''',
              ENCRYPTION BY PASSWORD = ''' + REPLACE(@CertPassword, '''', '''''') + N'''
          );';
    EXEC sys.sp_executesql @ExportSql;
END;

SELECT @CertFile AS CertificateFile, @PrivateKeyFile AS PrivateKeyFile;
GO

/* -------------------------------------------------------------------------
   3. Initial full backup establishes the log chain
   ------------------------------------------------------------------------- */
EXEC admin.usp_RunBackup @BackupType = 'FULL', @JobName = N'Manual initial full backup';
EXEC admin.usp_RunBackup @BackupType = 'LOG', @JobName = N'Manual initial log backup';
GO

/* -------------------------------------------------------------------------
   4. SQL Server Agent jobs and schedules
   ------------------------------------------------------------------------- */
USE msdb;
GO
SET NOCOUNT ON;
GO

DECLARE @CurrentOwner sysname = SUSER_SNAME();

IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Full Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Full Backup', @delete_unused_schedule = 1;
IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Differential Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Differential Backup', @delete_unused_schedule = 1;
IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Transaction Log Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Transaction Log Backup', @delete_unused_schedule = 1;

IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Daily Full 0100')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Daily Full 0100';
IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Diff Every 6 Hours')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Diff Every 6 Hours';
IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Log Every 15 Minutes')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Log Every 15 Minutes';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Full Backup',
    @enabled = 1,
    @description = N'Daily AES-256 encrypted full backup with CHECKSUM, COMPRESSION and VERIFYONLY.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Full Backup',
    @step_name = N'Run encrypted full backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''FULL'', @JobName = N''SmartBank - Full Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Daily Full 0100',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @active_start_time = 010000;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Full Backup',
    @schedule_name = N'SmartBank Daily Full 0100';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Full Backup';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Differential Backup',
    @enabled = 1,
    @description = N'AES-256 encrypted differential backup every six hours.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Differential Backup',
    @step_name = N'Run encrypted differential backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''DIFFERENTIAL'', @JobName = N''SmartBank - Differential Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Diff Every 6 Hours',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 8,
    @freq_subday_interval = 6,
    @active_start_time = 070000,
    @active_end_time = 235959;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Differential Backup',
    @schedule_name = N'SmartBank Diff Every 6 Hours';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Differential Backup';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Transaction Log Backup',
    @enabled = 1,
    @description = N'AES-256 encrypted transaction-log backup every 15 minutes to meet the RPO.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Transaction Log Backup',
    @step_name = N'Run encrypted log backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''LOG'', @JobName = N''SmartBank - Transaction Log Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Log Every 15 Minutes',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 4,
    @freq_subday_interval = 15,
    @active_start_time = 000000,
    @active_end_time = 235959;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Transaction Log Backup',
    @schedule_name = N'SmartBank Log Every 15 Minutes';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Transaction Log Backup';
GO

/* -------------------------------------------------------------------------
   5. Three-day readiness/evidence procedure
   ------------------------------------------------------------------------- */
USE SmartBankDB;
GO

CREATE OR ALTER PROCEDURE admin.usp_BackupReadinessReport
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        servicename,
        status_desc,
        startup_type_desc,
        last_startup_time,
        service_account
    FROM sys.dm_server_services
    WHERE servicename LIKE N'SQL Server Agent%'
       OR servicename LIKE N'SQL Server (%';

    SELECT
        j.name AS JobName,
        j.enabled,
        CASE h.run_status
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Cancelled'
            WHEN 4 THEN 'In Progress'
            ELSE 'No history'
        END AS LastOutcome,
        msdb.dbo.agent_datetime(h.run_date, h.run_time) AS LastRunDateTime,
        h.message AS LastMessage
    FROM msdb.dbo.sysjobs AS j
    OUTER APPLY
    (
        SELECT TOP (1) run_status, run_date, run_time, message
        FROM msdb.dbo.sysjobhistory AS h2
        WHERE h2.job_id = j.job_id
          AND h2.step_id = 0
        ORDER BY h2.instance_id DESC
    ) AS h
    WHERE j.name LIKE N'SmartBank - % Backup'
    ORDER BY j.name;

    ;WITH LastThreeDays AS
    (
        SELECT CAST(DATEADD(day, -2, GETDATE()) AS date) AS BackupDate
        UNION ALL SELECT CAST(DATEADD(day, -1, GETDATE()) AS date)
        UNION ALL SELECT CAST(GETDATE() AS date)
    ),
    BackupCounts AS
    (
        SELECT
            CAST(backup_finish_date AS date) AS BackupDate,
            SUM(CASE WHEN type = 'D' THEN 1 ELSE 0 END) AS FullBackups,
            SUM(CASE WHEN type = 'I' THEN 1 ELSE 0 END) AS DifferentialBackups,
            SUM(CASE WHEN type = 'L' THEN 1 ELSE 0 END) AS LogBackups,
            SUM(CASE WHEN key_algorithm = 'AES_256' THEN 1 ELSE 0 END) AS AES256Backups
        FROM msdb.dbo.backupset
        WHERE database_name = N'SmartBankDB'
          AND backup_finish_date >= DATEADD(day, -3, CAST(GETDATE() AS date))
        GROUP BY CAST(backup_finish_date AS date)
    )
    SELECT
        d.BackupDate,
        COALESCE(b.FullBackups, 0) AS FullBackups,
        COALESCE(b.DifferentialBackups, 0) AS DifferentialBackups,
        COALESCE(b.LogBackups, 0) AS LogBackups,
        COALESCE(b.AES256Backups, 0) AS AES256Backups,
        CASE
            WHEN COALESCE(b.FullBackups, 0) >= 1
             AND COALESCE(b.DifferentialBackups, 0) >= 1
             AND COALESCE(b.LogBackups, 0) >= 1
             AND COALESCE(b.AES256Backups, 0) >= 3
            THEN 'PASS'
            ELSE 'NOT READY'
        END AS DailyReadiness
    FROM LastThreeDays AS d
    LEFT JOIN BackupCounts AS b
        ON b.BackupDate = d.BackupDate
    ORDER BY d.BackupDate;

    SELECT TOP (200)
        BackupEvidenceID,
        BackupStartUtc,
        BackupFinishUtc,
        BackupType,
        BackupFile,
        Encrypted,
        VerifyOnlyPassed,
        Success,
        ErrorMessage,
        SqlAgentJobName
    FROM audit.BackupEvidence
    ORDER BY BackupEvidenceID DESC;

    SELECT TOP (200)
        bs.backup_set_id,
        bs.database_name,
        CASE bs.type WHEN 'D' THEN 'FULL' WHEN 'I' THEN 'DIFFERENTIAL' WHEN 'L' THEN 'LOG' END AS BackupType,
        bs.backup_start_date,
        bs.backup_finish_date,
        bs.is_copy_only,
        bs.has_backup_checksums,
        bms.is_compressed,
        bms.is_encrypted,
        bs.key_algorithm,
        bs.encryptor_type,
        CONVERT(decimal(12,2), bs.backup_size / 1048576.0) AS BackupSizeMB,
        CONVERT(decimal(12,2), bs.compressed_backup_size / 1048576.0) AS CompressedBackupSizeMB,
        bmf.physical_device_name
    FROM msdb.dbo.backupset AS bs
    INNER JOIN msdb.dbo.backupmediafamily AS bmf
        ON bmf.media_set_id = bs.media_set_id
    INNER JOIN msdb.dbo.backupmediaset AS bms
        ON bms.media_set_id = bs.media_set_id
    WHERE bs.database_name = N'SmartBankDB'
    ORDER BY bs.backup_finish_date DESC;
END;
GO

EXEC admin.usp_BackupReadinessReport;
GO

PRINT '08 encrypted backup automation completed. Keep SQL Server and SQL Server Agent running for at least three consecutive days before the demo.';
GO
