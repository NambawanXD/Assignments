/*
OPTIONAL DEFENCE-IN-DEPTH FEATURE - Transparent Data Encryption (TDE)

Column-level encryption and AES-256 backup encryption already satisfy the assignment
requirements. Enable this only after you have practised moving the TDE certificate to
the second instance, because a TDE-protected database cannot be restored there
without its certificate/private key in master.
*/
USE master;
GO
SET NOCOUNT ON;
GO

IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name = N'##MS_DatabaseMasterKey##')
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'MasterKey#SmartBank2026!';
GO

IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name = N'SmartBankTDECertificate')
BEGIN
    CREATE CERTIFICATE SmartBankTDECertificate
        WITH SUBJECT = N'SmartBank TDE database encryption certificate',
             EXPIRY_DATE = '20361231';
END;
GO

USE SmartBankDB;
GO
IF NOT EXISTS (SELECT 1 FROM sys.dm_database_encryption_keys WHERE database_id = DB_ID())
BEGIN
    CREATE DATABASE ENCRYPTION KEY
        WITH ALGORITHM = AES_256
        ENCRYPTION BY SERVER CERTIFICATE SmartBankTDECertificate;
END;
GO
ALTER DATABASE SmartBankDB SET ENCRYPTION ON;
GO

SELECT
    DB_NAME(database_id) AS DatabaseName,
    encryption_state,
    encryption_state_desc,
    percent_complete,
    key_algorithm,
    key_length
FROM sys.dm_database_encryption_keys
WHERE database_id = DB_ID(N'SmartBankDB');
GO

PRINT 'Before moving/restoring this database, back up SmartBankTDECertificate and its private key from master.';
GO
