/*
SmartBankDB - Controlled data access and modification procedures.
All procedures validate ORIGINAL_LOGIN(), apply least privilege, use transactions,
and write success/failure evidence to audit.BusinessActionLog.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* -------------------------------------------------------------------------
   1. Internal business-action audit writer
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE audit.usp_WriteBusinessAction
    @ActionCategory   varchar(30),
    @ActionName       nvarchar(128),
    @TargetObject     nvarchar(256) = NULL,
    @Success          bit,
    @ErrorNumber      int = NULL,
    @ErrorMessage     nvarchar(2048) = NULL,
    @KeyValuesJson    nvarchar(max) = NULL,
    @OldValuesJson    nvarchar(max) = NULL,
    @NewValuesJson    nvarchar(max) = NULL,
    @CorrelationID    uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname;
    DECLARE @RoleCode varchar(25);
    DECLARE @ClientAddress varchar(48) = CONVERT(varchar(48), CONNECTIONPROPERTY('client_net_address'));

    SELECT
        @DatabaseUserName = DatabaseUserName,
        @RoleCode = RoleCode
    FROM sec.LoginIdentityMap
    WHERE LoginName = @LoginName;

    INSERT audit.BusinessActionLog
    (
        LoginName, DatabaseUserName, RoleCode, SessionID, HostName,
        ApplicationName, ClientAddress, ActionCategory, ActionName,
        TargetObject, Success, ErrorNumber, ErrorMessage,
        KeyValuesJson, OldValuesJson, NewValuesJson, CorrelationID
    )
    VALUES
    (
        @LoginName,
        COALESCE(@DatabaseUserName, USER_NAME()),
        @RoleCode,
        @@SPID,
        HOST_NAME(),
        APP_NAME(),
        @ClientAddress,
        @ActionCategory,
        @ActionName,
        @TargetObject,
        @Success,
        @ErrorNumber,
        @ErrorMessage,
        @KeyValuesJson,
        @OldValuesJson,
        @NewValuesJson,
        COALESCE(@CorrelationID, NEWID())
    );
END;
GO

/* -------------------------------------------------------------------------
   2. Staff confidentiality and controlled management
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_GetMyStaffRecord
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @StaffID char(6);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @StaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER')
          AND IsActive = 1;

        IF @StaffID IS NULL
            THROW 51001, 'The current login is not mapped to an active staff record.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            s.StaffID,
            s.StaffName,
            s.Position,
            s.Branch,
            s.Phone,
            TRY_CONVERT(decimal(12,2),
                CONVERT(nvarchar(32),
                    DecryptByKey
                    (
                        sp.SalaryCipher,
                        1,
                        CONVERT(varbinary(128), s.StaffID)
                    )
                )
            ) AS Salary,
            sp.LastSalaryReviewDate,
            s.IsActive,
            s.ModifiedAt
        FROM bank.Staff AS s
        INNER JOIN bank.StaffPrivate AS sp
            ON sp.StaffID = s.StaffID
        WHERE s.StaffID = @StaffID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'VIEW_OWN_STAFF_RECORD',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'VIEW_OWN_STAFF_RECORD',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_GetStaffRecords
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @ManagerStaffID char(6);

    BEGIN TRY
        SELECT @ManagerStaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode = 'BANK_MANAGER'
          AND IsActive = 1;

        IF @ManagerStaffID IS NULL
            THROW 51002, 'Only an active Bank Manager may view manager-level staff records.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            s.StaffID,
            s.StaffName,
            s.Position,
            s.Branch,
            s.Phone,
            TRY_CONVERT(decimal(12,2),
                CONVERT(nvarchar(32),
                    DecryptByKey(sp.SalaryCipher, 1, CONVERT(varbinary(128), s.StaffID))
                )
            ) AS Salary,
            sp.LastSalaryReviewDate,
            s.IsActive,
            s.ModifiedAt
        FROM bank.Staff AS s
        INNER JOIN bank.StaffPrivate AS sp
            ON sp.StaffID = s.StaffID
        WHERE s.StaffID = @ManagerStaffID
           OR s.Position = 'Bank Officer'
        ORDER BY s.Position, s.StaffID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'MANAGER_VIEW_STAFF_RECORDS',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'MANAGER_VIEW_STAFF_RECORDS',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Staff_UpdateOwnRecord
    @Branch nvarchar(50) = NULL,
    @Phone varchar(20) = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @StaffID char(6);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @StaffID = StaffID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER')
          AND IsActive = 1;

        IF @StaffID IS NULL
            THROW 51003, 'Only active staff may use staff self-service.', 1;

        IF @Branch IS NULL AND @Phone IS NULL
            THROW 51004, 'Provide at least one value to update.', 1;

        SELECT @OldJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        UPDATE bank.Staff
        SET Branch = COALESCE(@Branch, Branch),
            Phone = COALESCE(@Phone, Phone),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE StaffID = @StaffID;

        SELECT @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'STAFF_UPDATE_OWN_RECORD',
            @TargetObject = N'bank.Staff',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM sec.vw_StaffBasicAccess WHERE StaffID = @StaffID;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'STAFF_UPDATE_OWN_RECORD',
            @TargetObject = N'bank.Staff',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_CreateBankOfficer
    @StaffID char(6),
    @StaffName nvarchar(100),
    @Branch nvarchar(50),
    @Phone varchar(20),
    @Salary decimal(12,2)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_MANAGER' AND IsActive = 1
        )
            THROW 51005, 'Only an active Bank Manager may create a Bank Officer record.', 1;

        IF @Salary <= 0
            THROW 51006, 'Salary must be greater than zero.', 1;

        IF EXISTS (SELECT 1 FROM bank.Staff WHERE StaffID = @StaffID)
            THROW 51007, 'The StaffID already exists.', 1;

        BEGIN TRANSACTION;

        INSERT bank.Staff (StaffID, StaffName, Position, Branch, Phone)
        VALUES (@StaffID, @StaffName, 'Bank Officer', @Branch, @Phone);

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        INSERT bank.StaffPrivate
        (
            StaffID, SalaryCipher, SalaryIntegrityHash, LastSalaryReviewDate,
            ModifiedAt, ModifiedBy
        )
        VALUES
        (
            @StaffID,
            EncryptByKey
            (
                Key_GUID('SmartBankColumnKey'),
                CONVERT(varbinary(128), CONVERT(nvarchar(32), @Salary)),
                1,
                CONVERT(varbinary(128), @StaffID)
            ),
            HASHBYTES
            (
                'SHA2_256',
                CONVERT(nvarchar(20), @StaffID) + N'|' + CONVERT(nvarchar(32), @Salary) + N'|SmartBankSalaryIntegrity'
            ),
            CAST(SYSUTCDATETIME() AS date),
            SYSUTCDATETIME(),
            @LoginName
        );

        CLOSE SYMMETRIC KEY SmartBankColumnKey;
        COMMIT TRANSACTION;

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        SET @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(1 AS bit) AS SalaryEncrypted
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_CREATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_CREATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Manager_UpdateBankOfficer
    @StaffID char(6),
    @StaffName nvarchar(100) = NULL,
    @Branch nvarchar(50) = NULL,
    @Phone varchar(20) = NULL,
    @Salary decimal(12,2) = NULL,
    @IsActive bit = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_MANAGER' AND IsActive = 1
        )
            THROW 51008, 'Only an active Bank Manager may update Bank Officer details.', 1;

        IF NOT EXISTS
        (
            SELECT 1 FROM bank.Staff
            WHERE StaffID = @StaffID AND Position = 'Bank Officer'
        )
            THROW 51009, 'The target StaffID is not a Bank Officer.', 1;

        IF @Salary IS NOT NULL AND @Salary <= 0
            THROW 51010, 'Salary must be greater than zero.', 1;

        SELECT @OldJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(CASE WHEN @Salary IS NULL THEN 0 ELSE 1 END AS bit) AS SalaryChangeRequested
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        BEGIN TRANSACTION;

        UPDATE bank.Staff
        SET StaffName = COALESCE(@StaffName, StaffName),
            Branch = COALESCE(@Branch, Branch),
            Phone = COALESCE(@Phone, Phone),
            IsActive = COALESCE(@IsActive, IsActive),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE StaffID = @StaffID;

        IF @Salary IS NOT NULL
        BEGIN
            OPEN SYMMETRIC KEY SmartBankColumnKey
                DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

            UPDATE bank.StaffPrivate
            SET SalaryCipher = EncryptByKey
                (
                    Key_GUID('SmartBankColumnKey'),
                    CONVERT(varbinary(128), CONVERT(nvarchar(32), @Salary)),
                    1,
                    CONVERT(varbinary(128), @StaffID)
                ),
                SalaryIntegrityHash = HASHBYTES
                (
                    'SHA2_256',
                    CONVERT(nvarchar(20), @StaffID) + N'|' + CONVERT(nvarchar(32), @Salary) + N'|SmartBankSalaryIntegrity'
                ),
                LastSalaryReviewDate = CAST(SYSUTCDATETIME() AS date),
                ModifiedAt = SYSUTCDATETIME(),
                ModifiedBy = @LoginName
            WHERE StaffID = @StaffID;

            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END;

        COMMIT TRANSACTION;

        SELECT @NewJson =
        (
            SELECT StaffID, StaffName, Position, Branch, Phone, IsActive,
                   CAST(CASE WHEN @Salary IS NULL THEN 0 ELSE 1 END AS bit) AS SalaryChanged
            FROM bank.Staff
            WHERE StaffID = @StaffID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_UPDATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @StaffID AS StaffID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'STAFF_MANAGEMENT',
            @ActionName = N'MANAGER_UPDATE_BANK_OFFICER',
            @TargetObject = N'bank.Staff/bank.StaffPrivate',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   3. Customer and account management by Bank Officers
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_Officer_CreateCustomer
    @CustomerID char(6),
    @CustomerName nvarchar(100),
    @Email varchar(254),
    @Phone varchar(20),
    @DateOfBirth date,
    @ICNumber nvarchar(30),
    @Address nvarchar(200)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @Salt uniqueidentifier = NEWID();
    DECLARE @NormalisedIC nvarchar(30);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51101, 'Only an active Bank Officer may create customer records.', 1;

        IF EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = @CustomerID)
            THROW 51102, 'The CustomerID already exists.', 1;

        IF @DateOfBirth >= CAST(SYSUTCDATETIME() AS date)
            THROW 51103, 'Date of birth must be earlier than today.', 1;

        SET @NormalisedIC = UPPER(REPLACE(REPLACE(LTRIM(RTRIM(@ICNumber)), '-', ''), ' ', ''));

        BEGIN TRANSACTION;
        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        INSERT bank.Customer
        (
            CustomerID, CustomerName, Email, Phone, DateOfBirth,
            ICNumberCipher, AddressCipher, HashSalt, ICNumberHash,
            CreatedBy, ModifiedBy
        )
        VALUES
        (
            @CustomerID,
            @CustomerName,
            @Email,
            @Phone,
            @DateOfBirth,
            EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), @ICNumber), 1, CONVERT(varbinary(128), @CustomerID)),
            EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), @Address), 1, CONVERT(varbinary(128), @CustomerID)),
            @Salt,
            HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt) + N'|' + @NormalisedIC),
            @LoginName,
            @LoginName
        );

        CLOSE SYMMETRIC KEY SmartBankColumnKey;
        COMMIT TRANSACTION;

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        SET @NewJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(1 AS bit) AS ICNumberEncrypted,
                   CAST(1 AS bit) AS AddressEncrypted,
                   CAST(1 AS bit) AS ICNumberHashed
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_UpdateCustomer
    @CustomerID char(6),
    @CustomerName nvarchar(100) = NULL,
    @Email varchar(254) = NULL,
    @Phone varchar(20) = NULL,
    @DateOfBirth date = NULL,
    @ICNumber nvarchar(30) = NULL,
    @Address nvarchar(200) = NULL,
    @CustomerStatus varchar(15) = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewSalt uniqueidentifier;
    DECLARE @NormalisedIC nvarchar(30);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51104, 'Only an active Bank Officer may update customer records.', 1;

        IF NOT EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = @CustomerID)
            THROW 51105, 'The CustomerID does not exist.', 1;

        IF @DateOfBirth IS NOT NULL AND @DateOfBirth >= CAST(SYSUTCDATETIME() AS date)
            THROW 51106, 'Date of birth must be earlier than today.', 1;

        SELECT @OldJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(CASE WHEN @ICNumber IS NULL THEN 0 ELSE 1 END AS bit) AS ICNumberChangeRequested,
                   CAST(CASE WHEN @Address IS NULL THEN 0 ELSE 1 END AS bit) AS AddressChangeRequested
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        BEGIN TRANSACTION;

        UPDATE bank.Customer
        SET CustomerName = COALESCE(@CustomerName, CustomerName),
            Email = COALESCE(@Email, Email),
            Phone = COALESCE(@Phone, Phone),
            DateOfBirth = COALESCE(@DateOfBirth, DateOfBirth),
            CustomerStatus = COALESCE(@CustomerStatus, CustomerStatus),
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE CustomerID = @CustomerID;

        IF @ICNumber IS NOT NULL OR @Address IS NOT NULL
        BEGIN
            OPEN SYMMETRIC KEY SmartBankColumnKey
                DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

            IF @ICNumber IS NOT NULL
            BEGIN
                SET @NewSalt = NEWID();
                SET @NormalisedIC = UPPER(REPLACE(REPLACE(LTRIM(RTRIM(@ICNumber)), '-', ''), ' ', ''));

                UPDATE bank.Customer
                SET ICNumberCipher = EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), @ICNumber), 1, CONVERT(varbinary(128), @CustomerID)),
                    HashSalt = @NewSalt,
                    ICNumberHash = HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @NewSalt) + N'|' + @NormalisedIC)
                WHERE CustomerID = @CustomerID;
            END;

            IF @Address IS NOT NULL
            BEGIN
                UPDATE bank.Customer
                SET AddressCipher = EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), @Address), 1, CONVERT(varbinary(128), @CustomerID))
                WHERE CustomerID = @CustomerID;
            END;

            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END;

        COMMIT TRANSACTION;

        SELECT @NewJson =
        (
            SELECT CustomerID, CustomerName, Email, Phone, DateOfBirth, CustomerStatus,
                   CAST(CASE WHEN @ICNumber IS NULL THEN 0 ELSE 1 END AS bit) AS ICNumberChanged,
                   CAST(CASE WHEN @Address IS NULL THEN 0 ELSE 1 END AS bit) AS AddressChanged
            FROM bank.Customer
            WHERE CustomerID = @CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'CUSTOMER_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_CUSTOMER',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_CreateAccount
    @AccountID char(10),
    @CustomerID char(6),
    @AccountType varchar(20)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @KeyJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51107, 'Only an active Bank Officer may create customer accounts.', 1;

        IF NOT EXISTS
        (
            SELECT 1 FROM bank.Customer
            WHERE CustomerID = @CustomerID AND CustomerStatus = 'Active'
        )
            THROW 51108, 'The customer does not exist or is not active.', 1;

        IF EXISTS (SELECT 1 FROM bank.Account WHERE AccountID = @AccountID)
            THROW 51109, 'The AccountID already exists.', 1;

        INSERT bank.Account
        (
            AccountID, CustomerID, AccountType, Balance,
            AccountStatus, CreatedBy, ModifiedBy
        )
        VALUES
        (
            @AccountID, @CustomerID, @AccountType, 0.00,
            'Active', @LoginName, @LoginName
        );

        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @CustomerID AS CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_ACCOUNT',
            @TargetObject = N'bank.Account',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @CustomerID AS CustomerID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_CREATE_ACCOUNT',
            @TargetObject = N'bank.Account',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Officer_UpdateAccountStatus
    @AccountID char(10),
    @NewStatus varchar(15)
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @KeyJson nvarchar(max);
    DECLARE @Balance decimal(15,2);

    BEGIN TRY
        IF NOT EXISTS
        (
            SELECT 1 FROM sec.LoginIdentityMap
            WHERE LoginName = @LoginName AND RoleCode = 'BANK_OFFICER' AND IsActive = 1
        )
            THROW 51110, 'Only an active Bank Officer may change account status.', 1;

        SELECT @Balance = Balance
        FROM bank.Account
        WHERE AccountID = @AccountID;

        IF @Balance IS NULL
            THROW 51111, 'The AccountID does not exist.', 1;

        IF @NewStatus = 'Closed' AND @Balance <> 0
            THROW 51112, 'An account can be closed only when its balance is zero.', 1;

        SELECT @OldJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus, ClosedAt
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        UPDATE bank.Account
        SET AccountStatus = @NewStatus,
            ClosedAt = CASE WHEN @NewStatus = 'Closed' THEN SYSUTCDATETIME() ELSE NULL END,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        SELECT @NewJson =
        (
            SELECT AccountID, CustomerID, AccountType, Balance, AccountStatus, ClosedAt
            FROM bank.Account
            WHERE AccountID = @AccountID
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        SET @KeyJson = (SELECT @AccountID AS AccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_ACCOUNT_STATUS',
            @TargetObject = N'bank.Account',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;
    END TRY
    BEGIN CATCH
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson = (SELECT @AccountID AS AccountID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'ACCOUNT_MANAGEMENT',
            @ActionName = N'OFFICER_UPDATE_ACCOUNT_STATUS',
            @TargetObject = N'bank.Account',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   4. Customer self-service confidentiality
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_GetMyCustomerProfile
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @KeyJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName
          AND RoleCode = 'CUSTOMER'
          AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51201, 'The current login is not mapped to an active customer.', 1;

        OPEN SYMMETRIC KEY SmartBankColumnKey
            DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

        SELECT
            CustomerID,
            CustomerName,
            Email,
            Phone,
            DateOfBirth,
            CONVERT(nvarchar(30),
                DecryptByKey(ICNumberCipher, 1, CONVERT(varbinary(128), CustomerID))
            ) AS ICNumber,
            CONVERT(nvarchar(200),
                DecryptByKey(AddressCipher, 1, CONVERT(varbinary(128), CustomerID))
            ) AS Address,
            CustomerStatus,
            ModifiedAt
        FROM bank.Customer
        WHERE CustomerID = @CustomerID;

        CLOSE SYMMETRIC KEY SmartBankColumnKey;

        SET @KeyJson = (SELECT @CustomerID AS CustomerID FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'CUSTOMER_VIEW_OWN_DECRYPTED_PROFILE',
            @TargetObject = N'bank.Customer',
            @Success = 1,
            @KeyValuesJson = @KeyJson;
    END TRY
    BEGIN CATCH
        BEGIN TRY
            CLOSE SYMMETRIC KEY SmartBankColumnKey;
        END TRY
        BEGIN CATCH
        END CATCH;

        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_ACCESS',
            @ActionName = N'CUSTOMER_VIEW_OWN_DECRYPTED_PROFILE',
            @TargetObject = N'bank.Customer',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   5. Customer-only financial transactions
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE api.usp_Customer_Deposit
    @AccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @BalanceBefore decimal(15,2);
    DECLARE @BalanceAfter decimal(15,2);
    DECLARE @TransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51301, 'Only an active Customer may perform a deposit.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51302, 'Deposit amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT * FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey;
            RETURN;
        END;

        BEGIN TRANSACTION;

        SELECT @BalanceBefore = Balance
        FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccountID = @AccountID
          AND CustomerID = @CustomerID
          AND AccountStatus = 'Active';

        IF @BalanceBefore IS NULL
            THROW 51303, 'The account is not active or is not owned by the current customer.', 1;

        SET @BalanceAfter = @BalanceBefore + @Amount;

        UPDATE bank.Account
        SET Balance = @BalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        INSERT bank.TransactionRecord
        (
            CustomerID, AccountID, Amount, TransactionType, Direction,
            BalanceBefore, BalanceAfter, Remarks, IdempotencyKey,
            InitiatedByLogin
        )
        VALUES
        (
            @CustomerID, @AccountID, @Amount, 'Deposit', 'Credit',
            @BalanceBefore, @BalanceAfter, COALESCE(@Remarks, N'Customer deposit'),
            @IdempotencyKey, @LoginName
        );

        SET @TransID = CONVERT(bigint, SCOPE_IDENTITY());
        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransID AS TransID, @AccountID AS AccountID, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @AccountID AS AccountID, @BalanceBefore AS Balance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @AccountID AS AccountID, @BalanceAfter AS Balance, @Amount AS DepositAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_DEPOSIT',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM bank.TransactionRecord WHERE TransID = @TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @Amount AS AttemptedAmount, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_DEPOSIT',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Customer_Withdraw
    @AccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @CustomerID char(6);
    DECLARE @BalanceBefore decimal(15,2);
    DECLARE @BalanceAfter decimal(15,2);
    DECLARE @TransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @CustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @CustomerID IS NULL
            THROW 51304, 'Only an active Customer may perform a withdrawal.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51305, 'Withdrawal amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT * FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey;
            RETURN;
        END;

        BEGIN TRANSACTION;

        SELECT @BalanceBefore = Balance
        FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
        WHERE AccountID = @AccountID
          AND CustomerID = @CustomerID
          AND AccountStatus = 'Active';

        IF @BalanceBefore IS NULL
            THROW 51306, 'The account is not active or is not owned by the current customer.', 1;
        IF @BalanceBefore < @Amount
            THROW 51307, 'Insufficient funds for the withdrawal.', 1;

        SET @BalanceAfter = @BalanceBefore - @Amount;

        UPDATE bank.Account
        SET Balance = @BalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @AccountID;

        INSERT bank.TransactionRecord
        (
            CustomerID, AccountID, Amount, TransactionType, Direction,
            BalanceBefore, BalanceAfter, Remarks, IdempotencyKey,
            InitiatedByLogin
        )
        VALUES
        (
            @CustomerID, @AccountID, @Amount, 'Withdrawal', 'Debit',
            @BalanceBefore, @BalanceAfter, COALESCE(@Remarks, N'Customer withdrawal'),
            @IdempotencyKey, @LoginName
        );

        SET @TransID = CONVERT(bigint, SCOPE_IDENTITY());
        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransID AS TransID, @AccountID AS AccountID, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @AccountID AS AccountID, @BalanceBefore AS Balance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @AccountID AS AccountID, @BalanceAfter AS Balance, @Amount AS WithdrawalAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_WITHDRAWAL',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson;

        SELECT * FROM bank.TransactionRecord WHERE TransID = @TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @AccountID AS AccountID, @Amount AS AttemptedAmount, @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_WITHDRAWAL',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson;
        THROW;
    END CATCH;
END;
GO

CREATE OR ALTER PROCEDURE api.usp_Customer_Transfer
    @FromAccountID char(10),
    @ToAccountID char(10),
    @Amount decimal(15,2),
    @Remarks nvarchar(250) = NULL,
    @IdempotencyKey uniqueidentifier = NULL
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @SourceCustomerID char(6);
    DECLARE @DestinationCustomerID char(6);
    DECLARE @FromBalanceBefore decimal(15,2);
    DECLARE @ToBalanceBefore decimal(15,2);
    DECLARE @FromBalanceAfter decimal(15,2);
    DECLARE @ToBalanceAfter decimal(15,2);
    DECLARE @TransferGroupID uniqueidentifier = NEWID();
    DECLARE @SourceTransID bigint;
    DECLARE @DestinationTransID bigint;
    DECLARE @KeyJson nvarchar(max);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);

    BEGIN TRY
        SELECT @SourceCustomerID = CustomerID
        FROM sec.LoginIdentityMap
        WHERE LoginName = @LoginName AND RoleCode = 'CUSTOMER' AND IsActive = 1;

        IF @SourceCustomerID IS NULL
            THROW 51308, 'Only an active Customer may perform a transfer.', 1;
        IF @FromAccountID = @ToAccountID
            THROW 51309, 'Source and destination accounts must be different.', 1;
        IF @Amount <= 0 OR @Amount > 1000000
            THROW 51310, 'Transfer amount must be greater than zero and not exceed 1,000,000.', 1;

        SET @IdempotencyKey = COALESCE(@IdempotencyKey, NEWID());

        IF EXISTS (SELECT 1 FROM bank.TransactionRecord WHERE IdempotencyKey = @IdempotencyKey)
        BEGIN
            SELECT *
            FROM bank.TransactionRecord
            WHERE TransferGroupID =
            (
                SELECT TransferGroupID
                FROM bank.TransactionRecord
                WHERE IdempotencyKey = @IdempotencyKey
            )
            ORDER BY TransID;
            RETURN;
        END;

        BEGIN TRANSACTION;

        /* Deterministic lock order reduces transfer deadlocks. */
        IF @FromAccountID < @ToAccountID
        BEGIN
            SELECT @FromBalanceBefore = Balance
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @FromAccountID
              AND CustomerID = @SourceCustomerID
              AND AccountStatus = 'Active';

            SELECT @ToBalanceBefore = Balance, @DestinationCustomerID = CustomerID
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @ToAccountID
              AND AccountStatus = 'Active';
        END
        ELSE
        BEGIN
            SELECT @ToBalanceBefore = Balance, @DestinationCustomerID = CustomerID
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @ToAccountID
              AND AccountStatus = 'Active';

            SELECT @FromBalanceBefore = Balance
            FROM bank.Account WITH (UPDLOCK, HOLDLOCK)
            WHERE AccountID = @FromAccountID
              AND CustomerID = @SourceCustomerID
              AND AccountStatus = 'Active';
        END;

        IF @FromBalanceBefore IS NULL
            THROW 51311, 'The source account is not active or is not owned by the current customer.', 1;
        IF @ToBalanceBefore IS NULL OR @DestinationCustomerID IS NULL
            THROW 51312, 'The destination account does not exist or is not active.', 1;
        IF @FromBalanceBefore < @Amount
            THROW 51313, 'Insufficient funds for the transfer.', 1;

        SET @FromBalanceAfter = @FromBalanceBefore - @Amount;
        SET @ToBalanceAfter = @ToBalanceBefore + @Amount;

        UPDATE bank.Account
        SET Balance = @FromBalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @FromAccountID;

        UPDATE bank.Account
        SET Balance = @ToBalanceAfter,
            ModifiedAt = SYSUTCDATETIME(),
            ModifiedBy = @LoginName
        WHERE AccountID = @ToAccountID;

        INSERT bank.TransactionRecord
        (
            TransferGroupID, CustomerID, AccountID, CounterpartyAccountID,
            Amount, TransactionType, Direction, BalanceBefore, BalanceAfter,
            Remarks, IdempotencyKey, InitiatedByLogin
        )
        VALUES
        (
            @TransferGroupID, @SourceCustomerID, @FromAccountID, @ToAccountID,
            @Amount, 'Transfer', 'Debit', @FromBalanceBefore, @FromBalanceAfter,
            COALESCE(@Remarks, N'Customer transfer - outgoing'), @IdempotencyKey, @LoginName
        );
        SET @SourceTransID = CONVERT(bigint, SCOPE_IDENTITY());

        INSERT bank.TransactionRecord
        (
            TransferGroupID, CustomerID, AccountID, CounterpartyAccountID,
            Amount, TransactionType, Direction, BalanceBefore, BalanceAfter,
            Remarks, IdempotencyKey, InitiatedByLogin
        )
        VALUES
        (
            @TransferGroupID, @DestinationCustomerID, @ToAccountID, @FromAccountID,
            @Amount, 'Transfer', 'Credit', @ToBalanceBefore, @ToBalanceAfter,
            COALESCE(@Remarks, N'Customer transfer - incoming'), NULL, @LoginName
        );
        SET @DestinationTransID = CONVERT(bigint, SCOPE_IDENTITY());

        COMMIT TRANSACTION;

        SET @KeyJson =
        (
            SELECT @TransferGroupID AS TransferGroupID,
                   @SourceTransID AS SourceTransID,
                   @DestinationTransID AS DestinationTransID,
                   @FromAccountID AS FromAccountID,
                   @ToAccountID AS ToAccountID,
                   @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @OldJson =
        (
            SELECT @FromBalanceBefore AS SourceBalance,
                   @ToBalanceBefore AS DestinationBalance
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        SET @NewJson =
        (
            SELECT @FromBalanceAfter AS SourceBalance,
                   @ToBalanceAfter AS DestinationBalance,
                   @Amount AS TransferAmount
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_TRANSFER',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 1,
            @KeyValuesJson = @KeyJson,
            @OldValuesJson = @OldJson,
            @NewValuesJson = @NewJson,
            @CorrelationID = @TransferGroupID;

        SELECT *
        FROM bank.TransactionRecord
        WHERE TransferGroupID = @TransferGroupID
        ORDER BY TransID;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();
        SET @KeyJson =
        (
            SELECT @FromAccountID AS FromAccountID,
                   @ToAccountID AS ToAccountID,
                   @Amount AS AttemptedAmount,
                   @IdempotencyKey AS IdempotencyKey
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'TRANSACTION',
            @ActionName = N'CUSTOMER_TRANSFER',
            @TargetObject = N'bank.Account/bank.TransactionRecord',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage,
            @KeyValuesJson = @KeyJson,
            @CorrelationID = @TransferGroupID;
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   6. Non-production static masking / anonymisation refresh
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE reporting.usp_RefreshCustomerAnalyticsMasked
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SnapshotUtc datetime2(3) = SYSUTCDATETIME();

    BEGIN TRY
        BEGIN TRANSACTION;
        TRUNCATE TABLE reporting.CustomerAnalyticsMasked;

        INSERT reporting.CustomerAnalyticsMasked
        (
            CustomerToken, CustomerAlias, EmailDomain, PhoneMasked,
            AgeBand, AccountCount, TotalBalanceBand, SnapshotUtc
        )
        SELECT
            CONVERT(char(64), HASHBYTES('SHA2_256', CONVERT(nvarchar(36), c.HashSalt) + N'|' + c.CustomerID), 2),
            N'Customer-' + RIGHT(c.CustomerID, 4),
            CASE WHEN CHARINDEX('@', c.Email) > 0 THEN SUBSTRING(c.Email, CHARINDEX('@', c.Email) + 1, 254) END,
            REPLICATE('X', CASE WHEN LEN(c.Phone) > 4 THEN LEN(c.Phone) - 4 ELSE 0 END) + RIGHT(c.Phone, 4),
            CASE
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) < 21 THEN 'Under 21'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 21 AND 30 THEN '21-30'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 31 AND 45 THEN '31-45'
                WHEN DATEDIFF(year, c.DateOfBirth, CAST(@SnapshotUtc AS date)) BETWEEN 46 AND 60 THEN '46-60'
                ELSE '61+'
            END,
            COUNT(a.AccountID),
            CASE
                WHEN COALESCE(SUM(a.Balance), 0) < 5000 THEN 'Below 5,000'
                WHEN COALESCE(SUM(a.Balance), 0) < 20000 THEN '5,000-19,999'
                WHEN COALESCE(SUM(a.Balance), 0) < 100000 THEN '20,000-99,999'
                ELSE '100,000+'
            END,
            @SnapshotUtc
        FROM bank.Customer AS c
        LEFT JOIN bank.Account AS a
            ON a.CustomerID = c.CustomerID
        GROUP BY c.CustomerID, c.HashSalt, c.Email, c.Phone, c.DateOfBirth;

        COMMIT TRANSACTION;

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_PROTECTION',
            @ActionName = N'REFRESH_STATIC_MASKED_ANALYTICS',
            @TargetObject = N'reporting.CustomerAnalyticsMasked',
            @Success = 1;

        SELECT * FROM reporting.CustomerAnalyticsMasked ORDER BY CustomerAlias;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        DECLARE @ErrorNumber int = ERROR_NUMBER();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        EXEC audit.usp_WriteBusinessAction
            @ActionCategory = 'DATA_PROTECTION',
            @ActionName = N'REFRESH_STATIC_MASKED_ANALYTICS',
            @TargetObject = N'reporting.CustomerAnalyticsMasked',
            @Success = 0,
            @ErrorNumber = @ErrorNumber,
            @ErrorMessage = @ErrorMessage;
        THROW;
    END CATCH;
END;
GO

EXEC reporting.usp_RefreshCustomerAnalyticsMasked;
GO

PRINT '05 secure stored procedures completed successfully.';
GO
