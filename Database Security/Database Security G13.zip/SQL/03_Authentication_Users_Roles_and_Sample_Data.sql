/*
SmartBankDB - SQL authentication, database users, roles, identity mapping,
and encrypted sample records.

IMPORTANT: SQL Server must use Mixed Mode authentication for these demo logins.
The passwords are lab credentials only and must be replaced outside the assignment.
*/
USE master;
GO
SET NOCOUNT ON;
GO

IF SUSER_ID(N'SB_DBA01') IS NULL
    CREATE LOGIN SB_DBA01 WITH PASSWORD = 'Dba#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_MANAGER01') IS NULL
    CREATE LOGIN SB_MANAGER01 WITH PASSWORD = 'Mgr#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_OFFICER01') IS NULL
    CREATE LOGIN SB_OFFICER01 WITH PASSWORD = 'Off1#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_OFFICER02') IS NULL
    CREATE LOGIN SB_OFFICER02 WITH PASSWORD = 'Off2#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER01') IS NULL
    CREATE LOGIN SB_CUSTOMER01 WITH PASSWORD = 'Cust1#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER02') IS NULL
    CREATE LOGIN SB_CUSTOMER02 WITH PASSWORD = 'Cust2#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_CUSTOMER03') IS NULL
    CREATE LOGIN SB_CUSTOMER03 WITH PASSWORD = 'Cust3#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
IF SUSER_ID(N'SB_AUDITOR01') IS NULL
    CREATE LOGIN SB_AUDITOR01 WITH PASSWORD = 'Audit#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
GO

/* Idempotent login hardening for existing lab logins. */
IF SUSER_ID(N'SB_DBA01') IS NOT NULL ALTER LOGIN [SB_DBA01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_MANAGER01') IS NOT NULL ALTER LOGIN [SB_MANAGER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_OFFICER01') IS NOT NULL ALTER LOGIN [SB_OFFICER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_OFFICER02') IS NOT NULL ALTER LOGIN [SB_OFFICER02] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER01') IS NOT NULL ALTER LOGIN [SB_CUSTOMER01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER02') IS NOT NULL ALTER LOGIN [SB_CUSTOMER02] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_CUSTOMER03') IS NOT NULL ALTER LOGIN [SB_CUSTOMER03] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;
IF SUSER_ID(N'SB_AUDITOR01') IS NOT NULL ALTER LOGIN [SB_AUDITOR01] WITH DEFAULT_DATABASE = [SmartBankDB], CHECK_POLICY = ON, CHECK_EXPIRATION = OFF;

ALTER AUTHORIZATION ON DATABASE::SmartBankDB TO sa;
GO

USE SmartBankDB;
GO

/* Database roles: permissions are assigned to roles, never directly to business users. */
IF DATABASE_PRINCIPAL_ID(N'role_dba') IS NULL
    CREATE ROLE role_dba AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_bank_manager') IS NULL
    CREATE ROLE role_bank_manager AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_bank_officer') IS NULL
    CREATE ROLE role_bank_officer AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_customer') IS NULL
    CREATE ROLE role_customer AUTHORIZATION dbo;
IF DATABASE_PRINCIPAL_ID(N'role_security_auditor') IS NULL
    CREATE ROLE role_security_auditor AUTHORIZATION dbo;
GO

/* Database users */
IF DATABASE_PRINCIPAL_ID(N'SB_DBA01') IS NULL CREATE USER SB_DBA01 FOR LOGIN SB_DBA01;
IF DATABASE_PRINCIPAL_ID(N'SB_MANAGER01') IS NULL CREATE USER SB_MANAGER01 FOR LOGIN SB_MANAGER01;
IF DATABASE_PRINCIPAL_ID(N'SB_OFFICER01') IS NULL CREATE USER SB_OFFICER01 FOR LOGIN SB_OFFICER01;
IF DATABASE_PRINCIPAL_ID(N'SB_OFFICER02') IS NULL CREATE USER SB_OFFICER02 FOR LOGIN SB_OFFICER02;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER01') IS NULL CREATE USER SB_CUSTOMER01 FOR LOGIN SB_CUSTOMER01;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER02') IS NULL CREATE USER SB_CUSTOMER02 FOR LOGIN SB_CUSTOMER02;
IF DATABASE_PRINCIPAL_ID(N'SB_CUSTOMER03') IS NULL CREATE USER SB_CUSTOMER03 FOR LOGIN SB_CUSTOMER03;
IF DATABASE_PRINCIPAL_ID(N'SB_AUDITOR01') IS NULL CREATE USER SB_AUDITOR01 FOR LOGIN SB_AUDITOR01;
GO

IF IS_ROLEMEMBER(N'role_dba', N'SB_DBA01') = 0
    ALTER ROLE role_dba ADD MEMBER SB_DBA01;
IF IS_ROLEMEMBER(N'role_bank_manager', N'SB_MANAGER01') = 0
    ALTER ROLE role_bank_manager ADD MEMBER SB_MANAGER01;
IF IS_ROLEMEMBER(N'role_bank_officer', N'SB_OFFICER01') = 0
    ALTER ROLE role_bank_officer ADD MEMBER SB_OFFICER01;
IF IS_ROLEMEMBER(N'role_bank_officer', N'SB_OFFICER02') = 0
    ALTER ROLE role_bank_officer ADD MEMBER SB_OFFICER02;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER01') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER01;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER02') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER02;
IF IS_ROLEMEMBER(N'role_customer', N'SB_CUSTOMER03') = 0
    ALTER ROLE role_customer ADD MEMBER SB_CUSTOMER03;
IF IS_ROLEMEMBER(N'role_security_auditor', N'SB_AUDITOR01') = 0
    ALTER ROLE role_security_auditor ADD MEMBER SB_AUDITOR01;
GO

/* -------------------------------------------------------------------------
   Encrypted sample data
   ------------------------------------------------------------------------- */
OPEN SYMMETRIC KEY SmartBankColumnKey
    DECRYPTION BY CERTIFICATE SmartBankColumnCertificate;

IF NOT EXISTS (SELECT 1 FROM bank.Staff WHERE StaffID = 'ST0001')
BEGIN
    INSERT bank.Staff (StaffID, StaffName, Position, Branch, Phone)
    VALUES
    ('ST0001', N'Aiman Rahman', 'DBA', N'Kuala Lumpur HQ', '03-21001001'),
    ('ST0002', N'Siti Nur Aisyah', 'Bank Manager', N'Kuala Lumpur HQ', '03-21001002'),
    ('ST0003', N'Daniel Lim', 'Bank Officer', N'Cheras Branch', '03-21001003'),
    ('ST0004', N'Priya Nair', 'Bank Officer', N'Petaling Jaya Branch', '03-21001004');

    INSERT bank.StaffPrivate (StaffID, SalaryCipher, SalaryIntegrityHash, LastSalaryReviewDate)
    VALUES
    ('ST0001',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'8500.00'), 1, CONVERT(varbinary(128), 'ST0001')),
        HASHBYTES('SHA2_256', N'ST0001|8500.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0002',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'12000.00'), 1, CONVERT(varbinary(128), 'ST0002')),
        HASHBYTES('SHA2_256', N'ST0002|12000.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0003',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'5200.00'), 1, CONVERT(varbinary(128), 'ST0003')),
        HASHBYTES('SHA2_256', N'ST0003|5200.00|SmartBankSalaryIntegrity'), '2026-01-01'),
    ('ST0004',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(128), N'5400.00'), 1, CONVERT(varbinary(128), 'ST0004')),
        HASHBYTES('SHA2_256', N'ST0004|5400.00|SmartBankSalaryIntegrity'), '2026-01-01');
END;

IF NOT EXISTS (SELECT 1 FROM bank.Customer WHERE CustomerID = 'CU0001')
BEGIN
    DECLARE @Salt1 uniqueidentifier = NEWID();
    DECLARE @Salt2 uniqueidentifier = NEWID();
    DECLARE @Salt3 uniqueidentifier = NEWID();

    INSERT bank.Customer
    (
        CustomerID, CustomerName, Email, Phone, DateOfBirth,
        ICNumberCipher, AddressCipher, HashSalt, ICNumberHash
    )
    VALUES
    ('CU0001', N'Nur Izzati Hassan', 'izzati@example.com', '012-3456789', '1998-04-12',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'980412-14-5678'), 1, CONVERT(varbinary(128), 'CU0001')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'12 Jalan Ampang, 50450 Kuala Lumpur'), 1, CONVERT(varbinary(128), 'CU0001')),
        @Salt1,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt1) + N'|980412145678')),
    ('CU0002', N'Jason Wong', 'jason.wong@example.com', '013-7788990', '1995-09-21',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'950921-10-2244'), 1, CONVERT(varbinary(128), 'CU0002')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'88 Jalan Kuchai Lama, 58200 Kuala Lumpur'), 1, CONVERT(varbinary(128), 'CU0002')),
        @Salt2,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt2) + N'|950921102244')),
    ('CU0003', N'Kavitha Raman', 'kavitha.r@example.com', '016-4455667', '2000-02-18',
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(256), N'000218-08-7788'), 1, CONVERT(varbinary(128), 'CU0003')),
        EncryptByKey(Key_GUID('SmartBankColumnKey'), CONVERT(varbinary(512), N'27 Jalan SS2, 47300 Petaling Jaya'), 1, CONVERT(varbinary(128), 'CU0003')),
        @Salt3,
        HASHBYTES('SHA2_256', CONVERT(nvarchar(36), @Salt3) + N'|000218087788'));
END;

CLOSE SYMMETRIC KEY SmartBankColumnKey;
GO

IF NOT EXISTS (SELECT 1 FROM bank.Account WHERE AccountID = 'AC00000001')
BEGIN
    INSERT bank.Account (AccountID, CustomerID, AccountType, Balance, AccountStatus)
    VALUES
    ('AC00000001', 'CU0001', 'Savings', 5000.00, 'Active'),
    ('AC00000002', 'CU0001', 'Current', 1500.00, 'Active'),
    ('AC00000003', 'CU0002', 'Savings', 8000.00, 'Active'),
    ('AC00000004', 'CU0003', 'Savings', 3200.00, 'Active');
END;
GO

IF NOT EXISTS (SELECT 1 FROM bank.TransactionRecord)
BEGIN
    INSERT bank.TransactionRecord
    (
        CustomerID, AccountID, TransDate, Amount, TransactionType,
        Direction, BalanceBefore, BalanceAfter, Remarks, InitiatedByLogin
    )
    VALUES
    ('CU0001', 'AC00000001', DATEADD(day, -10, SYSUTCDATETIME()), 5000.00, 'Deposit', 'Credit', 0.00, 5000.00, N'Opening deposit', 'SB_CUSTOMER01'),
    ('CU0001', 'AC00000002', DATEADD(day, -9, SYSUTCDATETIME()), 1500.00, 'Deposit', 'Credit', 0.00, 1500.00, N'Opening deposit', 'SB_CUSTOMER01'),
    ('CU0002', 'AC00000003', DATEADD(day, -8, SYSUTCDATETIME()), 8000.00, 'Deposit', 'Credit', 0.00, 8000.00, N'Opening deposit', 'SB_CUSTOMER02'),
    ('CU0003', 'AC00000004', DATEADD(day, -7, SYSUTCDATETIME()), 3200.00, 'Deposit', 'Credit', 0.00, 3200.00, N'Opening deposit', 'SB_CUSTOMER03');
END;
GO

/* Login/user-to-business-identity mapping used by RLS and procedures. */
MERGE sec.LoginIdentityMap AS target
USING
(
    SELECT N'SB_DBA01' AS DatabaseUserName, N'SB_DBA01' AS LoginName, 'DBA' AS RoleCode, 'ST0001' AS StaffID, CAST(NULL AS char(6)) AS CustomerID
    UNION ALL SELECT N'SB_MANAGER01', N'SB_MANAGER01', 'BANK_MANAGER', 'ST0002', NULL
    UNION ALL SELECT N'SB_OFFICER01', N'SB_OFFICER01', 'BANK_OFFICER', 'ST0003', NULL
    UNION ALL SELECT N'SB_OFFICER02', N'SB_OFFICER02', 'BANK_OFFICER', 'ST0004', NULL
    UNION ALL SELECT N'SB_CUSTOMER01', N'SB_CUSTOMER01', 'CUSTOMER', NULL, 'CU0001'
    UNION ALL SELECT N'SB_CUSTOMER02', N'SB_CUSTOMER02', 'CUSTOMER', NULL, 'CU0002'
    UNION ALL SELECT N'SB_CUSTOMER03', N'SB_CUSTOMER03', 'CUSTOMER', NULL, 'CU0003'
    UNION ALL SELECT N'SB_AUDITOR01', N'SB_AUDITOR01', 'SECURITY_AUDITOR', NULL, NULL
) AS source
ON target.DatabaseUserName = source.DatabaseUserName
WHEN MATCHED THEN
    UPDATE SET LoginName = source.LoginName,
               RoleCode = source.RoleCode,
               StaffID = source.StaffID,
               CustomerID = source.CustomerID,
               IsActive = 1
WHEN NOT MATCHED THEN
    INSERT (DatabaseUserName, LoginName, RoleCode, StaffID, CustomerID)
    VALUES (source.DatabaseUserName, source.LoginName, source.RoleCode, source.StaffID, source.CustomerID);
GO

SELECT
    p.name AS DatabaseUser,
    r.name AS DatabaseRole,
    m.RoleCode,
    m.StaffID,
    m.CustomerID,
    m.IsActive
FROM sys.database_principals AS p
LEFT JOIN sys.database_role_members AS drm
    ON drm.member_principal_id = p.principal_id
LEFT JOIN sys.database_principals AS r
    ON r.principal_id = drm.role_principal_id
LEFT JOIN sec.LoginIdentityMap AS m
    ON m.DatabaseUserName = p.name
WHERE p.name LIKE N'SB[_]%'
ORDER BY p.name;
GO

PRINT '03 authentication, roles, users, mappings, and sample data completed successfully.';
GO
