/*
SmartBankDB - Post-installation validation and demo readiness report.
Run as sysadmin after scripts 01-08 or SmartBankDB_Install_AllInOne.sql.
This script does not fabricate operational evidence; it reports the current server state.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

PRINT '1. Database configuration';
SELECT
    name AS DatabaseName,
    state_desc,
    recovery_model_desc,
    page_verify_option_desc,
    is_read_committed_snapshot_on,
    is_trustworthy_on
FROM sys.databases
WHERE name = N'SmartBankDB';
GO

PRINT '2. Required schemas and security objects';
DECLARE @ObjectChecks TABLE
(
    CheckArea nvarchar(80) NOT NULL,
    ObjectName nvarchar(256) NOT NULL,
    IsPresent bit NOT NULL
);

INSERT @ObjectChecks (CheckArea, ObjectName, IsPresent)
VALUES
(N'Schema', N'bank', IIF(SCHEMA_ID(N'bank') IS NOT NULL, 1, 0)),
(N'Schema', N'sec', IIF(SCHEMA_ID(N'sec') IS NOT NULL, 1, 0)),
(N'Schema', N'api', IIF(SCHEMA_ID(N'api') IS NOT NULL, 1, 0)),
(N'Schema', N'audit', IIF(SCHEMA_ID(N'audit') IS NOT NULL, 1, 0)),
(N'Table', N'bank.Staff', IIF(OBJECT_ID(N'bank.Staff', N'U') IS NOT NULL, 1, 0)),
(N'Table', N'bank.StaffPrivate', IIF(OBJECT_ID(N'bank.StaffPrivate', N'U') IS NOT NULL, 1, 0)),
(N'Table', N'bank.Customer', IIF(OBJECT_ID(N'bank.Customer', N'U') IS NOT NULL, 1, 0)),
(N'Table', N'bank.Account', IIF(OBJECT_ID(N'bank.Account', N'U') IS NOT NULL, 1, 0)),
(N'Table', N'bank.TransactionRecord', IIF(OBJECT_ID(N'bank.TransactionRecord', N'U') IS NOT NULL, 1, 0)),
(N'Procedure', N'api.usp_GetMyStaffRecord', IIF(OBJECT_ID(N'api.usp_GetMyStaffRecord', N'P') IS NOT NULL, 1, 0)),
(N'Procedure', N'api.usp_GetMyCustomerProfile', IIF(OBJECT_ID(N'api.usp_GetMyCustomerProfile', N'P') IS NOT NULL, 1, 0)),
(N'Procedure', N'api.usp_Customer_Deposit', IIF(OBJECT_ID(N'api.usp_Customer_Deposit', N'P') IS NOT NULL, 1, 0)),
(N'Procedure', N'api.usp_Customer_Withdraw', IIF(OBJECT_ID(N'api.usp_Customer_Withdraw', N'P') IS NOT NULL, 1, 0)),
(N'Procedure', N'api.usp_Customer_Transfer', IIF(OBJECT_ID(N'api.usp_Customer_Transfer', N'P') IS NOT NULL, 1, 0)),
(N'Audit table', N'audit.BusinessActionLog', IIF(OBJECT_ID(N'audit.BusinessActionLog', N'U') IS NOT NULL, 1, 0)),
(N'Audit table', N'audit.DMLChangeLog', IIF(OBJECT_ID(N'audit.DMLChangeLog', N'U') IS NOT NULL, 1, 0)),
(N'Audit table', N'audit.DDLSecurityChangeLog', IIF(OBJECT_ID(N'audit.DDLSecurityChangeLog', N'U') IS NOT NULL, 1, 0));

SELECT CheckArea, ObjectName, IIF(IsPresent = 1, N'PASS', N'MISSING') AS Result
FROM @ObjectChecks
ORDER BY CheckArea, ObjectName;

IF EXISTS (SELECT 1 FROM @ObjectChecks WHERE IsPresent = 0)
    PRINT 'ATTENTION: One or more required objects are missing.';
ELSE
    PRINT 'PASS: Required schemas, tables, procedures, and audit tables are present.';
GO

PRINT '3. Authentication, users, and role membership';
SELECT
    sp.name AS LoginName,
    sp.type_desc,
    sp.is_disabled,
    LOGINPROPERTY(sp.name, 'IsPolicyChecked') AS PasswordPolicyChecked,
    LOGINPROPERTY(sp.name, 'IsExpired') AS PasswordExpired,
    sp.default_database_name
FROM master.sys.server_principals AS sp
WHERE sp.name LIKE N'SB[_]%'
ORDER BY sp.name;

SELECT *
FROM sec.vw_RoleUserMapping
ORDER BY RoleName, UserName;
GO

PRINT '4. Explicit RBAC permissions and authorization matrix';
SELECT *
FROM sec.vw_ExplicitRolePermissions
ORDER BY RoleName, PermissionState, SecurableName, PermissionName;

SELECT *
FROM sec.AuthorizationMatrix
ORDER BY RoleName, MatrixID;
GO

PRINT '5. Row-Level Security policies';
SELECT
    policy.name AS SecurityPolicy,
    policy.is_enabled,
    predicate.predicate_type_desc,
    OBJECT_SCHEMA_NAME(predicate.target_object_id) AS TargetSchema,
    OBJECT_NAME(predicate.target_object_id) AS TargetTable,
    predicate.predicate_definition
FROM sys.security_policies AS policy
INNER JOIN sys.security_predicates AS predicate
    ON predicate.object_id = policy.object_id
ORDER BY policy.name, predicate.predicate_type_desc;
GO

PRINT '6. Dynamic masking and data classification';
SELECT
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS ColumnName,
    masking_function
FROM sys.masked_columns
WHERE is_masked = 1
ORDER BY SchemaName, TableName, ColumnName;

SELECT
    s.name AS SchemaName,
    t.name AS TableName,
    c.name AS ColumnName,
    sc.information_type AS InformationType,
    sc.label AS SensitivityLabel,
    sc.rank_desc AS SensitivityRank
FROM sys.sensitivity_classifications AS sc
INNER JOIN sys.tables AS t
    ON t.object_id = sc.major_id
INNER JOIN sys.schemas AS s
    ON s.schema_id = t.schema_id
INNER JOIN sys.columns AS c
    ON c.object_id = sc.major_id
   AND c.column_id = sc.minor_id
ORDER BY s.name, t.name, c.column_id;
GO

PRINT '7. Encryption hierarchy and ciphertext storage';
SELECT name, key_length, algorithm_desc
FROM sys.symmetric_keys
WHERE name IN (N'##MS_DatabaseMasterKey##', N'SmartBankColumnKey');

SELECT name, subject, expiry_date
FROM sys.certificates
WHERE name = N'SmartBankColumnCertificate';

SELECT
    COUNT_BIG(*) AS CustomerRows,
    SUM(CASE WHEN ICNumberCipher IS NOT NULL AND AddressCipher IS NOT NULL THEN 1 ELSE 0 END) AS EncryptedCustomerRows,
    SUM(CASE WHEN ICNumberHash IS NOT NULL AND HashSalt IS NOT NULL THEN 1 ELSE 0 END) AS HashedCustomerRows
FROM bank.Customer;

SELECT
    COUNT_BIG(*) AS StaffPrivateRows,
    SUM(CASE WHEN SalaryCipher IS NOT NULL THEN 1 ELSE 0 END) AS EncryptedSalaryRows
FROM bank.StaffPrivate;
GO

PRINT '8. Audit status';
SELECT name, is_state_enabled, on_failure_desc, queue_delay
FROM sys.server_audits
WHERE name = N'SmartBank_ServerAudit';

SELECT name, is_state_enabled
FROM sys.database_audit_specifications
WHERE name = N'SmartBank_DatabaseAuditSpec';

SELECT name, is_disabled
FROM sys.triggers
WHERE parent_class_desc = N'DATABASE'
   OR name LIKE N'trg[_]%Audit'
ORDER BY name;
GO

PRINT '9. SQL Server Agent and scheduled backup jobs';
SELECT
    servicename,
    status_desc,
    startup_type_desc,
    last_startup_time,
    service_account
FROM sys.dm_server_services
WHERE servicename LIKE N'SQL Server Agent%'
   OR servicename LIKE N'SQL Server (%';

SELECT
    j.name AS JobName,
    j.enabled,
    s.name AS ScheduleName,
    s.enabled AS ScheduleEnabled,
    s.freq_type,
    s.freq_subday_type,
    s.freq_subday_interval,
    s.active_start_time
FROM msdb.dbo.sysjobs AS j
LEFT JOIN msdb.dbo.sysjobschedules AS js
    ON js.job_id = j.job_id
LEFT JOIN msdb.dbo.sysschedules AS s
    ON s.schedule_id = js.schedule_id
WHERE j.name LIKE N'SmartBank - % Backup'
ORDER BY j.name;
GO

PRINT '10. Current backup and verification evidence';
IF OBJECT_ID(N'admin.usp_BackupReadinessReport', N'P') IS NULL
BEGIN
    PRINT 'MISSING: admin.usp_BackupReadinessReport';
END
ELSE
BEGIN
    EXEC(N'EXEC admin.usp_BackupReadinessReport;');
END;
GO

PRINT '11. Constraint and database consistency checks';
DBCC CHECKCONSTRAINTS WITH ALL_CONSTRAINTS;
DBCC CHECKDB (N'SmartBankDB') WITH NO_INFOMSGS;
GO

PRINT 'Post-installation validation completed. Resolve every MISSING, disabled, failed, or NOT READY result before the demonstration.';
GO
