/*
SmartBankDB - Point-in-time restore (PITR) and efficient row recovery demo

Purpose
1. Record a recovery point immediately before the lecturer's deletion.
2. Take a tail/current log backup after the deletion.
3. Restore the latest valid full + optional differential + log chain to
   SmartBankDB_PITR with STOPAT.
4. Copy the missing row(s) back to the active database when required.

Run as sysadmin. The SmartBankBackupCertificate must remain in master because all
backups are encrypted. SQL Server Agent backups must already be running.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   PHASE A - RUN THIS IMMEDIATELY BEFORE THE LECTURER DELETES RECORDS
   ------------------------------------------------------------------------- */
DECLARE @RecoveryPoint datetime2(3) = SYSDATETIME();

IF OBJECT_ID(N'demo.PITRRecoveryPoint', N'U') IS NULL
BEGIN
    CREATE TABLE demo.PITRRecoveryPoint
    (
        RecoveryPointID int IDENTITY(1,1) PRIMARY KEY,
        RecordedAt datetime2(3) NOT NULL,
        RecordedBy sysname NOT NULL,
        Purpose nvarchar(300) NOT NULL
    );
END;

INSERT demo.PITRRecoveryPoint (RecordedAt, RecordedBy, Purpose)
VALUES (@RecoveryPoint, ORIGINAL_LOGIN(), N'Point immediately before lecturer deletion for PITR demonstration.');

SELECT TOP (1)
    RecoveryPointID,
    RecordedAt AS UseThisSTOPATValue,
    RecordedBy,
    Purpose
FROM demo.PITRRecoveryPoint
ORDER BY RecoveryPointID DESC;

PRINT 'COPY the UseThisSTOPATValue shown above. Let the lecturer delete one or two records.';
GO

/* -------------------------------------------------------------------------
   PHASE B - AFTER THE DELETION, TAKE AN IMMEDIATE ENCRYPTED LOG BACKUP
   ------------------------------------------------------------------------- */
EXEC admin.usp_RunBackup
    @BackupType = 'LOG',
    @JobName = N'Manual post-deletion PITR log backup';
GO

/* -------------------------------------------------------------------------
   PHASE C - EDIT @TargetTime USING THE VALUE CAPTURED IN PHASE A, THEN RUN
   The script automatically selects the latest full backup before @TargetTime,
   the latest compatible differential (if any), and the required log backups.
   ------------------------------------------------------------------------- */
USE master;
GO
SET NOCOUNT ON;
GO

/* ============================== EDIT THIS ============================== */
DECLARE @TargetTime datetime = '2026-07-17T16:00:00.000'; -- paste Phase A value
DECLARE @SourceDatabase sysname = N'SmartBankDB';
DECLARE @RestoreDatabase sysname = N'SmartBankDB_PITR';
DECLARE @ExecuteRestore bit = 1; -- set 0 to preview commands only
DECLARE @DatabaseMasterKeyPassword nvarchar(128) = N'DbMasterKey#SmartBank2026!';
/* ===================================================================== */

IF @TargetTime >= GETDATE()
    THROW 51701, 'Target time must be in the past and before the accidental deletion.', 1;

IF NOT EXISTS (SELECT 1 FROM master.sys.certificates WHERE name = N'SmartBankBackupCertificate')
    THROW 51702, 'SmartBankBackupCertificate is missing from master; encrypted backups cannot be restored.', 1;

DECLARE @FullMediaSetID int;
DECLARE @FullPosition int;
DECLARE @FullFile nvarchar(4000);
DECLARE @FullFinish datetime;
DECLARE @FullCheckpointLSN numeric(25,0);
DECLARE @FullDatabaseBackupLSN numeric(25,0);

SELECT TOP (1)
    @FullMediaSetID = bs.media_set_id,
    @FullPosition = bs.position,
    @FullFile = bmf.physical_device_name,
    @FullFinish = bs.backup_finish_date,
    @FullCheckpointLSN = bs.checkpoint_lsn,
    @FullDatabaseBackupLSN = bs.database_backup_lsn
FROM msdb.dbo.backupset AS bs
JOIN msdb.dbo.backupmediafamily AS bmf
  ON bmf.media_set_id = bs.media_set_id
WHERE bs.database_name = @SourceDatabase
  AND bs.type = 'D'
  AND bs.is_copy_only = 0
  AND bs.backup_finish_date <= @TargetTime
ORDER BY bs.backup_finish_date DESC;

IF @FullFile IS NULL
    THROW 51703, 'No full database backup completed before the requested target time.', 1;

DECLARE @DiffFile nvarchar(4000) = NULL;
DECLARE @DiffPosition int = NULL;
DECLARE @DiffFinish datetime = NULL;

SELECT TOP (1)
    @DiffFile = bmf.physical_device_name,
    @DiffPosition = bs.position,
    @DiffFinish = bs.backup_finish_date
FROM msdb.dbo.backupset AS bs
JOIN msdb.dbo.backupmediafamily AS bmf
  ON bmf.media_set_id = bs.media_set_id
WHERE bs.database_name = @SourceDatabase
  AND bs.type = 'I'
  AND bs.backup_finish_date <= @TargetTime
  AND bs.database_backup_lsn = @FullCheckpointLSN
ORDER BY bs.backup_finish_date DESC;

DECLARE @RestoreStart datetime = COALESCE(@DiffFinish, @FullFinish);

/* Required logs: identify the first log backup whose finish time is at/after
   the target. A log backup can START after the target yet still contain the target
   log records, so backup_start_date must not be used as the coverage test. */
DECLARE @CoveringLogFinish datetime;
SELECT @CoveringLogFinish = MIN(bs.backup_finish_date)
FROM msdb.dbo.backupset AS bs
WHERE bs.database_name = @SourceDatabase
  AND bs.type = 'L'
  AND bs.is_copy_only = 0
  AND bs.backup_finish_date >= @TargetTime
  AND bs.backup_finish_date > @RestoreStart;

IF @CoveringLogFinish IS NULL
    THROW 51704, 'The log chain does not yet cover the target. Run the immediate post-deletion log backup and retry.', 1;

DECLARE @LogChain TABLE
(
    SequenceNo int IDENTITY(1,1) PRIMARY KEY,
    BackupFile nvarchar(4000) NOT NULL,
    Position int NOT NULL,
    BackupStart datetime NOT NULL,
    BackupFinish datetime NOT NULL,
    FirstLSN numeric(25,0) NULL,
    LastLSN numeric(25,0) NULL
);

INSERT @LogChain (BackupFile, Position, BackupStart, BackupFinish, FirstLSN, LastLSN)
SELECT
    bmf.physical_device_name,
    bs.position,
    bs.backup_start_date,
    bs.backup_finish_date,
    bs.first_lsn,
    bs.last_lsn
FROM msdb.dbo.backupset AS bs
JOIN msdb.dbo.backupmediafamily AS bmf
  ON bmf.media_set_id = bs.media_set_id
WHERE bs.database_name = @SourceDatabase
  AND bs.type = 'L'
  AND bs.is_copy_only = 0
  AND bs.backup_finish_date > @RestoreStart
  AND bs.backup_finish_date <= @CoveringLogFinish
ORDER BY bs.first_lsn, bs.backup_start_date;

IF NOT EXISTS (SELECT 1 FROM @LogChain WHERE BackupFinish >= @TargetTime)
    THROW 51705, 'Log backup metadata was found, but the selected chain does not include a backup covering the target.', 1;

/* Detect obvious LSN gaps before attempting RESTORE. */
IF EXISTS
(
    SELECT 1
    FROM
    (
        SELECT
            SequenceNo,
            FirstLSN,
            LastLSN,
            LAG(LastLSN) OVER (ORDER BY SequenceNo) AS PreviousLastLSN
        FROM @LogChain
    ) AS ChainCheck
    WHERE PreviousLastLSN IS NOT NULL
      AND FirstLSN > PreviousLastLSN
)
    THROW 51706, 'A gap was detected in the selected transaction-log backup chain.', 1;

/* Display the exact restore chain as evidence. */
SELECT N'FULL' AS BackupType, @FullFile AS BackupFile, @FullPosition AS Position,
       @FullFinish AS BackupFinish, CAST(NULL AS numeric(25,0)) AS FirstLSN,
       CAST(NULL AS numeric(25,0)) AS LastLSN
UNION ALL
SELECT N'DIFFERENTIAL', @DiffFile, @DiffPosition, @DiffFinish, NULL, NULL
WHERE @DiffFile IS NOT NULL
UNION ALL
SELECT N'LOG', BackupFile, Position, BackupFinish, FirstLSN, LastLSN
FROM @LogChain;

/* Show logical files for evidence. The installation script creates stable logical
   names SmartBankDB and SmartBankDB_log. */
DECLARE @FileListSql nvarchar(max) =
    N'RESTORE FILELISTONLY FROM DISK = N''' + REPLACE(@FullFile, '''', '''''') + N''' WITH FILE = ' + CONVERT(nvarchar(12), @FullPosition) + N';';
EXEC sys.sp_executesql @FileListSql;

DECLARE @DataLogicalName sysname = N'SmartBankDB';
DECLARE @LogLogicalName sysname = N'SmartBankDB_log';
DECLARE @DefaultDataPath nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultDataPath'));
DECLARE @DefaultLogPath nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultLogPath'));
IF @DefaultDataPath IS NULL
BEGIN
    SELECT TOP (1) @DefaultDataPath = LEFT(physical_name, LEN(physical_name) - CHARINDEX(N'\', REVERSE(physical_name)) + 1)
    FROM master.sys.master_files WHERE database_id = 1 AND file_id = 1;
END;
IF @DefaultLogPath IS NULL SET @DefaultLogPath = @DefaultDataPath;
IF RIGHT(@DefaultDataPath, 1) <> N'\' SET @DefaultDataPath += N'\';
IF RIGHT(@DefaultLogPath, 1) <> N'\' SET @DefaultLogPath += N'\';

DECLARE @DataFile nvarchar(4000) = @DefaultDataPath + @RestoreDatabase + N'.mdf';
DECLARE @LogFile nvarchar(4000) = @DefaultLogPath + @RestoreDatabase + N'_log.ldf';
DECLARE @Commands TABLE (CommandOrder int IDENTITY(1,1), RestoreCommand nvarchar(max));

INSERT @Commands (RestoreCommand)
VALUES
(
    N'RESTORE DATABASE ' + QUOTENAME(@RestoreDatabase) +
    N' FROM DISK = N''' + REPLACE(@FullFile, '''', '''''') +
    N''' WITH FILE = ' + CONVERT(nvarchar(12), @FullPosition) +
    N', MOVE N''' + REPLACE(@DataLogicalName, '''', '''''') + N''' TO N''' + REPLACE(@DataFile, '''', '''''') +
    N''', MOVE N''' + REPLACE(@LogLogicalName, '''', '''''') + N''' TO N''' + REPLACE(@LogFile, '''', '''''') +
    N''', NORECOVERY, CHECKSUM, REPLACE, STATS = 5;'
);

IF @DiffFile IS NOT NULL
BEGIN
    INSERT @Commands (RestoreCommand)
    VALUES
    (
        N'RESTORE DATABASE ' + QUOTENAME(@RestoreDatabase) +
        N' FROM DISK = N''' + REPLACE(@DiffFile, '''', '''''') +
        N''' WITH FILE = ' + CONVERT(nvarchar(12), @DiffPosition) +
        N', NORECOVERY, CHECKSUM, STATS = 5;'
    );
END;

DECLARE @Seq int = 1;
DECLARE @MaxSeq int = (SELECT MAX(SequenceNo) FROM @LogChain);
DECLARE @LogBackupFile nvarchar(4000);
DECLARE @LogPosition int;
DECLARE @LogFinish datetime;

WHILE @Seq <= @MaxSeq
BEGIN
    SELECT @LogBackupFile = BackupFile, @LogPosition = Position, @LogFinish = BackupFinish
    FROM @LogChain WHERE SequenceNo = @Seq;

    INSERT @Commands (RestoreCommand)
    VALUES
    (
        N'RESTORE LOG ' + QUOTENAME(@RestoreDatabase) +
        N' FROM DISK = N''' + REPLACE(@LogBackupFile, '''', '''''') +
        N''' WITH FILE = ' + CONVERT(nvarchar(12), @LogPosition) +
        CASE WHEN @LogFinish >= @TargetTime
             THEN N', STOPAT = N''' + CONVERT(nvarchar(30), @TargetTime, 126) + N''', RECOVERY, CHECKSUM, STATS = 5;'
             ELSE N', NORECOVERY, CHECKSUM, STATS = 5;'
        END
    );

    IF @LogFinish >= @TargetTime BREAK;
    SET @Seq += 1;
END;

SELECT CommandOrder, RestoreCommand FROM @Commands ORDER BY CommandOrder;

IF @ExecuteRestore = 1
BEGIN
    IF DB_ID(@RestoreDatabase) IS NOT NULL
    BEGIN
        DECLARE @DropSql nvarchar(max) =
            N'ALTER DATABASE ' + QUOTENAME(@RestoreDatabase) + N' SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
              DROP DATABASE ' + QUOTENAME(@RestoreDatabase) + N';';
        EXEC sys.sp_executesql @DropSql;
    END;

    DECLARE @Command nvarchar(max);
    DECLARE RestoreCursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT RestoreCommand FROM @Commands ORDER BY CommandOrder;
    OPEN RestoreCursor;
    FETCH NEXT FROM RestoreCursor INTO @Command;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT @Command;
        EXEC sys.sp_executesql @Command;
        FETCH NEXT FROM RestoreCursor INTO @Command;
    END;
    CLOSE RestoreCursor;
    DEALLOCATE RestoreCursor;

    DECLARE @BindKeySql nvarchar(max) =
        N'USE ' + QUOTENAME(@RestoreDatabase) + N';
          OPEN MASTER KEY DECRYPTION BY PASSWORD = N''' + REPLACE(@DatabaseMasterKeyPassword, '''', '''''') + N''';
          IF NOT EXISTS
          (
              SELECT 1
              FROM sys.key_encryptions
              WHERE key_id = (SELECT symmetric_key_id FROM sys.symmetric_keys WHERE name = N''##MS_DatabaseMasterKey##'')
                AND crypt_type_desc = N''ENCRYPTION BY SERVICE MASTER KEY''
          )
              ALTER MASTER KEY ADD ENCRYPTION BY SERVICE MASTER KEY;
          CLOSE MASTER KEY;';
    EXEC sys.sp_executesql @BindKeySql;

    DECLARE @VerifySql nvarchar(max) =
        N'USE ' + QUOTENAME(@RestoreDatabase) + N';
          SELECT DB_NAME() AS RestoredDatabase,
                 (SELECT COUNT_BIG(*) FROM bank.Staff) AS StaffRows,
                 (SELECT COUNT_BIG(*) FROM bank.Customer) AS CustomerRows,
                 (SELECT COUNT_BIG(*) FROM bank.Account) AS AccountRows,
                 (SELECT COUNT_BIG(*) FROM bank.TransactionRecord) AS TransactionRows;
          DBCC CHECKDB (' + QUOTENAME(@RestoreDatabase, '''') + N') WITH NO_INFOMSGS;';
    EXEC sys.sp_executesql @VerifySql;
END;

PRINT 'PITR copy is ready. Compare the deleted row in SmartBankDB_PITR with the active SmartBankDB.';
PRINT 'Use the targeted recovery templates in Demo_12_Point_In_Time_Restore_and_Row_Recovery.sql.';
GO
