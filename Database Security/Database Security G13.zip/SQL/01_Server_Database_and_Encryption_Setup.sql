/*
SmartBankDB - Server, database, folders, and encryption setup
Run as a sysadmin in SSMS.
Tested design target: SQL Server 2019/2022/2025 Developer or Standard Edition.
*/
USE master;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Backup-encryption certificate in master
   ------------------------------------------------------------------------- */
IF NOT EXISTS
(
    SELECT 1
    FROM sys.symmetric_keys
    WHERE name = N'##MS_DatabaseMasterKey##'
)
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'MasterKey#SmartBank2026!';
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.certificates
    WHERE name = N'SmartBankBackupCertificate'
)
BEGIN
    CREATE CERTIFICATE SmartBankBackupCertificate
        WITH SUBJECT = N'SmartBank AES-256 backup encryption certificate',
             EXPIRY_DATE = '20361231';
END;
GO

/* -------------------------------------------------------------------------
   2. Create database with integrity and recovery settings
   ------------------------------------------------------------------------- */
IF DB_ID(N'SmartBankDB') IS NULL
BEGIN
    CREATE DATABASE SmartBankDB;
END;
GO

ALTER DATABASE SmartBankDB SET RECOVERY FULL;
ALTER DATABASE SmartBankDB SET PAGE_VERIFY CHECKSUM;
ALTER DATABASE SmartBankDB SET AUTO_CLOSE OFF;
ALTER DATABASE SmartBankDB SET AUTO_SHRINK OFF;
ALTER DATABASE SmartBankDB SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
ALTER DATABASE SmartBankDB SET TRUSTWORTHY OFF;
GO

USE SmartBankDB;
GO

/* -------------------------------------------------------------------------
   3. Organisational schemas
   ------------------------------------------------------------------------- */
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'bank')
    EXEC(N'CREATE SCHEMA bank AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'sec')
    EXEC(N'CREATE SCHEMA sec AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'api')
    EXEC(N'CREATE SCHEMA api AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'audit')
    EXEC(N'CREATE SCHEMA audit AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'admin')
    EXEC(N'CREATE SCHEMA admin AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'reporting')
    EXEC(N'CREATE SCHEMA reporting AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'history')
    EXEC(N'CREATE SCHEMA history AUTHORIZATION dbo;');
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'demo')
    EXEC(N'CREATE SCHEMA demo AUTHORIZATION dbo;');
GO

/* -------------------------------------------------------------------------
   4. Configuration table and SQL Server-accessible folders
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'admin.Configuration', N'U') IS NULL
BEGIN
    CREATE TABLE admin.Configuration
    (
        ConfigKey       sysname          NOT NULL CONSTRAINT PK_Configuration PRIMARY KEY,
        ConfigValue     nvarchar(4000)   NOT NULL,
        Description     nvarchar(500)    NULL,
        ModifiedAt      datetime2(3)     NOT NULL CONSTRAINT DF_Configuration_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname          NOT NULL CONSTRAINT DF_Configuration_ModifiedBy DEFAULT ORIGINAL_LOGIN()
    );
END;
GO

DECLARE @DefaultBackupPath nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultBackupPath'));
DECLARE @DefaultLogPath    nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultLogPath'));

IF @DefaultBackupPath IS NULL OR LTRIM(RTRIM(@DefaultBackupPath)) = N''
BEGIN
    SELECT TOP (1) @DefaultBackupPath = LEFT(physical_name, LEN(physical_name) - CHARINDEX(N'\', REVERSE(physical_name)) + 1)
    FROM master.sys.master_files
    WHERE database_id = 1 AND file_id = 1;
END;

IF @DefaultLogPath IS NULL OR LTRIM(RTRIM(@DefaultLogPath)) = N''
BEGIN
    SET @DefaultLogPath = @DefaultBackupPath;
END;

IF RIGHT(@DefaultBackupPath, 1) <> N'\' SET @DefaultBackupPath += N'\';
IF RIGHT(@DefaultLogPath, 1) <> N'\' SET @DefaultLogPath += N'\';

DECLARE @SmartBankBackupPath nvarchar(4000) = @DefaultBackupPath + N'SmartBankDB\';
DECLARE @SmartBankAuditPath  nvarchar(4000) = @DefaultLogPath + N'SmartBankAudit\';

BEGIN TRY
    EXEC master.dbo.xp_create_subdir @SmartBankBackupPath;
    EXEC master.dbo.xp_create_subdir @SmartBankAuditPath;
END TRY
BEGIN CATCH
    PRINT 'Folder creation warning: ' + ERROR_MESSAGE();
    PRINT 'Create the folders manually and grant the SQL Server service account Modify permission.';
END CATCH;

MERGE admin.Configuration AS target
USING
(
    SELECT N'BackupPath' AS ConfigKey, @SmartBankBackupPath AS ConfigValue,
           N'Folder for encrypted full, differential, and transaction-log backups.' AS Description
    UNION ALL
    SELECT N'AuditPath', @SmartBankAuditPath,
           N'Folder for SQL Server Audit .sqlaudit files.'
    UNION ALL
    SELECT N'RPO_Minutes', N'15',
           N'Maximum acceptable data loss. Supported by 15-minute transaction-log backups.'
    UNION ALL
    SELECT N'RTO_Minutes', N'60',
           N'Target recovery time for restoring service in the lab environment.'
    UNION ALL
    SELECT N'DatabaseMasterKeyPassword', N'DbMasterKey#SmartBank2026!',
           N'Lab-only password needed after restoring the database to another instance. Store securely in production.'
    UNION ALL
    SELECT N'CertificateExportPassword', N'BackupCert#SmartBank2026!',
           N'Lab-only password protecting the exported backup-certificate private key.'
) AS source
ON target.ConfigKey = source.ConfigKey
WHEN MATCHED THEN
    UPDATE SET ConfigValue = source.ConfigValue,
               Description = source.Description,
               ModifiedAt = SYSUTCDATETIME(),
               ModifiedBy = ORIGINAL_LOGIN()
WHEN NOT MATCHED THEN
    INSERT (ConfigKey, ConfigValue, Description)
    VALUES (source.ConfigKey, source.ConfigValue, source.Description);
GO

/* -------------------------------------------------------------------------
   5. Column-level encryption hierarchy inside SmartBankDB
   ------------------------------------------------------------------------- */
IF NOT EXISTS
(
    SELECT 1
    FROM sys.symmetric_keys
    WHERE name = N'##MS_DatabaseMasterKey##'
)
BEGIN
    CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'DbMasterKey#SmartBank2026!';
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.certificates WHERE name = N'SmartBankColumnCertificate')
BEGIN
    CREATE CERTIFICATE SmartBankColumnCertificate
        WITH SUBJECT = N'SmartBank column-level encryption certificate',
             EXPIRY_DATE = '20361231';
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name = N'SmartBankColumnKey')
BEGIN
    CREATE SYMMETRIC KEY SmartBankColumnKey
        WITH ALGORITHM = AES_256
        ENCRYPTION BY CERTIFICATE SmartBankColumnCertificate;
END;
GO

SELECT
    DB_NAME() AS DatabaseName,
    recovery_model_desc,
    page_verify_option_desc,
    is_read_committed_snapshot_on,
    is_trustworthy_on
FROM sys.databases
WHERE name = N'SmartBankDB';

SELECT ConfigKey, ConfigValue, Description
FROM admin.Configuration
ORDER BY ConfigKey;
GO

PRINT '01 setup completed successfully.';
GO
