/*
SmartBankDB - Improved relational model, constraints, data dictionary,
data classification, temporal history, masking-ready columns, and audit tables.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

/* -------------------------------------------------------------------------
   1. Core banking tables
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'bank.Staff', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Staff
    (
        StaffID         char(6)         NOT NULL CONSTRAINT PK_Staff PRIMARY KEY,
        StaffName       nvarchar(100)   NOT NULL,
        Position        varchar(20)     NOT NULL,
        Branch          nvarchar(50)    NOT NULL,
        Phone           varchar(20)     NOT NULL,
        IsActive        bit             NOT NULL CONSTRAINT DF_Staff_IsActive DEFAULT (1),
        CreatedAt       datetime2(3)    NOT NULL CONSTRAINT DF_Staff_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy       sysname         NOT NULL CONSTRAINT DF_Staff_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt      datetime2(3)    NOT NULL CONSTRAINT DF_Staff_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname         NOT NULL CONSTRAINT DF_Staff_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        RowVer          rowversion      NOT NULL,
        CONSTRAINT CK_Staff_ID CHECK (StaffID LIKE 'ST[0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Staff_Position CHECK (Position IN ('DBA', 'Bank Manager', 'Bank Officer')),
        CONSTRAINT CK_Staff_Phone CHECK (LEN(Phone) BETWEEN 8 AND 20)
    );
END;
GO

IF OBJECT_ID(N'bank.StaffPrivate', N'U') IS NULL
BEGIN
    CREATE TABLE bank.StaffPrivate
    (
        StaffID                 char(6)         NOT NULL CONSTRAINT PK_StaffPrivate PRIMARY KEY,
        SalaryCipher            varbinary(256)  NOT NULL,
        SalaryIntegrityHash     varbinary(32)   NOT NULL,
        LastSalaryReviewDate    date            NULL,
        ModifiedAt              datetime2(3)    NOT NULL CONSTRAINT DF_StaffPrivate_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy              sysname         NOT NULL CONSTRAINT DF_StaffPrivate_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        RowVer                  rowversion      NOT NULL,
        CONSTRAINT FK_StaffPrivate_Staff FOREIGN KEY (StaffID) REFERENCES bank.Staff(StaffID)
    );
END;
GO

IF OBJECT_ID(N'bank.Customer', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Customer
    (
        CustomerID       char(6)         NOT NULL CONSTRAINT PK_Customer PRIMARY KEY,
        CustomerName     nvarchar(100)   NOT NULL,
        Email            varchar(254)    MASKED WITH (FUNCTION = 'email()') NOT NULL,
        Phone            varchar(20)     MASKED WITH (FUNCTION = 'partial(0,"XXX-XXX-",4)') NOT NULL,
        DateOfBirth      date            MASKED WITH (FUNCTION = 'default()') NOT NULL,
        ICNumberCipher   varbinary(256)  NOT NULL,
        AddressCipher    varbinary(512)  NOT NULL,
        HashSalt         uniqueidentifier NOT NULL CONSTRAINT DF_Customer_HashSalt DEFAULT NEWID(),
        ICNumberHash     varbinary(32)   NOT NULL,
        CustomerStatus   varchar(15)     NOT NULL CONSTRAINT DF_Customer_Status DEFAULT ('Active'),
        CreatedAt        datetime2(3)    NOT NULL CONSTRAINT DF_Customer_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy        sysname         NOT NULL CONSTRAINT DF_Customer_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt       datetime2(3)    NOT NULL CONSTRAINT DF_Customer_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy       sysname         NOT NULL CONSTRAINT DF_Customer_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        ValidFrom        datetime2(3) GENERATED ALWAYS AS ROW START HIDDEN NOT NULL CONSTRAINT DF_Customer_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo          datetime2(3) GENERATED ALWAYS AS ROW END HIDDEN NOT NULL CONSTRAINT DF_Customer_ValidTo DEFAULT CONVERT(datetime2(3), '9999-12-31 23:59:59.999'),
        PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
        RowVer           rowversion      NOT NULL,
        CONSTRAINT CK_Customer_ID CHECK (CustomerID LIKE 'CU[0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Customer_Email CHECK (Email LIKE '%_@_%._%'),
        CONSTRAINT CK_Customer_Phone CHECK (LEN(Phone) BETWEEN 8 AND 20),
        CONSTRAINT CK_Customer_Status CHECK (CustomerStatus IN ('Active', 'Suspended', 'Closed'))
    )
    WITH
    (
        SYSTEM_VERSIONING = ON
        (
            HISTORY_TABLE = history.CustomerHistory,
            DATA_CONSISTENCY_CHECK = ON
        )
    );
END;
GO

IF OBJECT_ID(N'bank.Account', N'U') IS NULL
BEGIN
    CREATE TABLE bank.Account
    (
        AccountID       char(10)        NOT NULL CONSTRAINT PK_Account PRIMARY KEY,
        CustomerID      char(6)         NOT NULL,
        AccountType     varchar(20)     NOT NULL,
        Balance         decimal(15,2)   NOT NULL CONSTRAINT DF_Account_Balance DEFAULT (0),
        AccountStatus   varchar(15)     NOT NULL CONSTRAINT DF_Account_Status DEFAULT ('Active'),
        OpenedAt        datetime2(3)    NOT NULL CONSTRAINT DF_Account_OpenedAt DEFAULT SYSUTCDATETIME(),
        ClosedAt        datetime2(3)    NULL,
        CreatedBy       sysname         NOT NULL CONSTRAINT DF_Account_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        ModifiedAt      datetime2(3)    NOT NULL CONSTRAINT DF_Account_ModifiedAt DEFAULT SYSUTCDATETIME(),
        ModifiedBy      sysname         NOT NULL CONSTRAINT DF_Account_ModifiedBy DEFAULT ORIGINAL_LOGIN(),
        ValidFrom       datetime2(3) GENERATED ALWAYS AS ROW START HIDDEN NOT NULL CONSTRAINT DF_Account_ValidFrom DEFAULT SYSUTCDATETIME(),
        ValidTo         datetime2(3) GENERATED ALWAYS AS ROW END HIDDEN NOT NULL CONSTRAINT DF_Account_ValidTo DEFAULT CONVERT(datetime2(3), '9999-12-31 23:59:59.999'),
        PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo),
        RowVer          rowversion      NOT NULL,
        CONSTRAINT FK_Account_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT CK_Account_ID CHECK (AccountID LIKE 'AC[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
        CONSTRAINT CK_Account_Type CHECK (AccountType IN ('Savings', 'Current', 'Fixed Deposit')),
        CONSTRAINT CK_Account_Balance CHECK (Balance >= 0),
        CONSTRAINT CK_Account_Status CHECK (AccountStatus IN ('Active', 'Frozen', 'Closed')),
        CONSTRAINT CK_Account_ClosedAt CHECK
        (
            (AccountStatus <> 'Closed' AND ClosedAt IS NULL)
            OR
            (AccountStatus = 'Closed' AND ClosedAt IS NOT NULL)
        )
    )
    WITH
    (
        SYSTEM_VERSIONING = ON
        (
            HISTORY_TABLE = history.AccountHistory,
            DATA_CONSISTENCY_CHECK = ON
        )
    );
END;
GO

IF OBJECT_ID(N'bank.TransactionRecord', N'U') IS NULL
BEGIN
    CREATE TABLE bank.TransactionRecord
    (
        TransID                bigint           IDENTITY(1,1) NOT NULL CONSTRAINT PK_TransactionRecord PRIMARY KEY,
        TransactionReference   uniqueidentifier NOT NULL CONSTRAINT DF_Transaction_Reference DEFAULT NEWSEQUENTIALID(),
        TransferGroupID        uniqueidentifier NULL,
        CustomerID             char(6)          NOT NULL,
        AccountID              char(10)         NOT NULL,
        CounterpartyAccountID  char(10)         NULL,
        TransDate              datetime2(3)     NOT NULL CONSTRAINT DF_Transaction_Date DEFAULT SYSUTCDATETIME(),
        Amount                 decimal(15,2)    NOT NULL,
        TransactionType        varchar(12)      NOT NULL,
        Direction              varchar(6)       NOT NULL,
        BalanceBefore          decimal(15,2)    NOT NULL,
        BalanceAfter           decimal(15,2)    NOT NULL,
        Remarks                nvarchar(250)    NULL,
        IdempotencyKey         uniqueidentifier NULL,
        InitiatedByLogin       sysname          NOT NULL CONSTRAINT DF_Transaction_Login DEFAULT ORIGINAL_LOGIN(),
        SourceApplication      nvarchar(128)    NOT NULL CONSTRAINT DF_Transaction_App DEFAULT APP_NAME(),
        CONSTRAINT UQ_Transaction_Reference UNIQUE (TransactionReference),
        CONSTRAINT FK_Transaction_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT FK_Transaction_Account FOREIGN KEY (AccountID) REFERENCES bank.Account(AccountID),
        CONSTRAINT FK_Transaction_Counterparty FOREIGN KEY (CounterpartyAccountID) REFERENCES bank.Account(AccountID),
        CONSTRAINT CK_Transaction_Amount CHECK (Amount > 0),
        CONSTRAINT CK_Transaction_Type CHECK (TransactionType IN ('Deposit', 'Withdrawal', 'Transfer')),
        CONSTRAINT CK_Transaction_Direction CHECK (Direction IN ('Credit', 'Debit')),
        CONSTRAINT CK_Transaction_Balance CHECK (BalanceBefore >= 0 AND BalanceAfter >= 0),
        CONSTRAINT CK_Transaction_Semantics CHECK
        (
            (TransactionType = 'Deposit' AND Direction = 'Credit' AND CounterpartyAccountID IS NULL)
            OR
            (TransactionType = 'Withdrawal' AND Direction = 'Debit' AND CounterpartyAccountID IS NULL)
            OR
            (TransactionType = 'Transfer' AND CounterpartyAccountID IS NOT NULL)
        )
    );

    CREATE UNIQUE INDEX UX_Transaction_IdempotencyKey
        ON bank.TransactionRecord(IdempotencyKey)
        WHERE IdempotencyKey IS NOT NULL;

    CREATE INDEX IX_Transaction_Customer_Date
        ON bank.TransactionRecord(CustomerID, TransDate DESC);

    CREATE INDEX IX_Transaction_Account_Date
        ON bank.TransactionRecord(AccountID, TransDate DESC);
END;
GO

/* -------------------------------------------------------------------------
   2. Security identity map
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.LoginIdentityMap', N'U') IS NULL
BEGIN
    CREATE TABLE sec.LoginIdentityMap
    (
        DatabaseUserName   sysname       NOT NULL CONSTRAINT PK_LoginIdentityMap PRIMARY KEY,
        LoginName          sysname       NOT NULL CONSTRAINT UQ_LoginIdentityMap_Login UNIQUE,
        RoleCode           varchar(25)   NOT NULL,
        StaffID            char(6)       NULL,
        CustomerID         char(6)       NULL,
        IsActive           bit           NOT NULL CONSTRAINT DF_LoginIdentityMap_IsActive DEFAULT (1),
        CreatedAt          datetime2(3)  NOT NULL CONSTRAINT DF_LoginIdentityMap_CreatedAt DEFAULT SYSUTCDATETIME(),
        CreatedBy          sysname       NOT NULL CONSTRAINT DF_LoginIdentityMap_CreatedBy DEFAULT ORIGINAL_LOGIN(),
        CONSTRAINT FK_LoginIdentityMap_Staff FOREIGN KEY (StaffID) REFERENCES bank.Staff(StaffID),
        CONSTRAINT FK_LoginIdentityMap_Customer FOREIGN KEY (CustomerID) REFERENCES bank.Customer(CustomerID),
        CONSTRAINT CK_LoginIdentityMap_Role CHECK
        (
            RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER', 'CUSTOMER', 'SECURITY_AUDITOR')
        ),
        CONSTRAINT CK_LoginIdentityMap_Association CHECK
        (
            (RoleCode IN ('DBA', 'BANK_MANAGER', 'BANK_OFFICER') AND StaffID IS NOT NULL AND CustomerID IS NULL)
            OR
            (RoleCode = 'CUSTOMER' AND CustomerID IS NOT NULL AND StaffID IS NULL)
            OR
            (RoleCode = 'SECURITY_AUDITOR' AND StaffID IS NULL AND CustomerID IS NULL)
        )
    );
END;
GO

/* -------------------------------------------------------------------------
   3. Auditing and operational evidence tables
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'audit.BusinessActionLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.BusinessActionLog
    (
        AuditID             bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BusinessActionLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_BusinessActionLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL,
        DatabaseUserName    sysname NOT NULL,
        RoleCode            varchar(25) NULL,
        SessionID           int NOT NULL,
        HostName            nvarchar(128) NULL,
        ApplicationName     nvarchar(128) NULL,
        ClientAddress       varchar(48) NULL,
        ActionCategory      varchar(30) NOT NULL,
        ActionName          nvarchar(128) NOT NULL,
        TargetObject        nvarchar(256) NULL,
        Success             bit NOT NULL,
        ErrorNumber         int NULL,
        ErrorMessage        nvarchar(2048) NULL,
        KeyValuesJson       nvarchar(max) NULL,
        OldValuesJson       nvarchar(max) NULL,
        NewValuesJson       nvarchar(max) NULL,
        CorrelationID       uniqueidentifier NOT NULL CONSTRAINT DF_BusinessActionLog_Correlation DEFAULT NEWID(),
        CONSTRAINT CK_BusinessActionLog_KeyJson CHECK (KeyValuesJson IS NULL OR ISJSON(KeyValuesJson) = 1),
        CONSTRAINT CK_BusinessActionLog_OldJson CHECK (OldValuesJson IS NULL OR ISJSON(OldValuesJson) = 1),
        CONSTRAINT CK_BusinessActionLog_NewJson CHECK (NewValuesJson IS NULL OR ISJSON(NewValuesJson) = 1)
    );

    CREATE INDEX IX_BusinessActionLog_Time ON audit.BusinessActionLog(EventTimeUtc DESC);
    CREATE INDEX IX_BusinessActionLog_Login ON audit.BusinessActionLog(LoginName, EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.DMLChangeLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.DMLChangeLog
    (
        ChangeAuditID       bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DMLChangeLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_DMLChangeLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL CONSTRAINT DF_DMLChangeLog_Login DEFAULT ORIGINAL_LOGIN(),
        DatabaseUserName    sysname NOT NULL CONSTRAINT DF_DMLChangeLog_User DEFAULT USER_NAME(),
        SessionID           int NOT NULL CONSTRAINT DF_DMLChangeLog_Session DEFAULT @@SPID,
        SchemaName          sysname NOT NULL,
        TableName           sysname NOT NULL,
        DMLAction           varchar(10) NOT NULL,
        RowCountAffected    int NOT NULL,
        OldRowsJson         nvarchar(max) NULL,
        NewRowsJson         nvarchar(max) NULL,
        HostName            nvarchar(128) NULL CONSTRAINT DF_DMLChangeLog_Host DEFAULT HOST_NAME(),
        ApplicationName     nvarchar(128) NULL CONSTRAINT DF_DMLChangeLog_App DEFAULT APP_NAME(),
        CONSTRAINT CK_DMLChangeLog_Action CHECK (DMLAction IN ('INSERT', 'UPDATE', 'DELETE')),
        CONSTRAINT CK_DMLChangeLog_OldJson CHECK (OldRowsJson IS NULL OR ISJSON(OldRowsJson) = 1),
        CONSTRAINT CK_DMLChangeLog_NewJson CHECK (NewRowsJson IS NULL OR ISJSON(NewRowsJson) = 1)
    );

    CREATE INDEX IX_DMLChangeLog_Time ON audit.DMLChangeLog(EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.DDLSecurityChangeLog', N'U') IS NULL
BEGIN
    CREATE TABLE audit.DDLSecurityChangeLog
    (
        DDLAuditID          bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_DDLSecurityChangeLog PRIMARY KEY,
        EventTimeUtc        datetime2(3) NOT NULL CONSTRAINT DF_DDLSecurityChangeLog_Time DEFAULT SYSUTCDATETIME(),
        LoginName           sysname NOT NULL,
        DatabaseUserName    sysname NOT NULL,
        EventType           sysname NOT NULL,
        ObjectType          sysname NULL,
        SchemaName          sysname NULL,
        ObjectName          sysname NULL,
        TSQLCommand         nvarchar(max) NULL,
        EventDataXml        xml NOT NULL,
        HostName            nvarchar(128) NULL,
        ApplicationName     nvarchar(128) NULL
    );

    CREATE INDEX IX_DDLSecurityChangeLog_Time ON audit.DDLSecurityChangeLog(EventTimeUtc DESC);
    CREATE INDEX IX_DDLSecurityChangeLog_Event ON audit.DDLSecurityChangeLog(EventType, EventTimeUtc DESC);
END;
GO

IF OBJECT_ID(N'audit.BackupEvidence', N'U') IS NULL
BEGIN
    CREATE TABLE audit.BackupEvidence
    (
        BackupEvidenceID    bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_BackupEvidence PRIMARY KEY,
        BackupStartUtc      datetime2(3) NOT NULL,
        BackupFinishUtc     datetime2(3) NOT NULL,
        BackupType          varchar(12) NOT NULL,
        BackupFile          nvarchar(4000) NOT NULL,
        Encrypted           bit NOT NULL,
        CompressionUsed     bit NOT NULL,
        ChecksumUsed        bit NOT NULL,
        VerifyOnlyPassed    bit NOT NULL,
        Success             bit NOT NULL,
        ErrorMessage        nvarchar(2048) NULL,
        ExecutedBy          sysname NOT NULL,
        SqlAgentJobName     sysname NULL,
        CONSTRAINT CK_BackupEvidence_Type CHECK (BackupType IN ('FULL', 'DIFFERENTIAL', 'LOG'))
    );

    CREATE INDEX IX_BackupEvidence_Time ON audit.BackupEvidence(BackupFinishUtc DESC);
END;
GO

/* -------------------------------------------------------------------------
   4. Static-masked analytics table
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'reporting.CustomerAnalyticsMasked', N'U') IS NULL
BEGIN
    CREATE TABLE reporting.CustomerAnalyticsMasked
    (
        CustomerToken      char(64)       NOT NULL CONSTRAINT PK_CustomerAnalyticsMasked PRIMARY KEY,
        CustomerAlias      nvarchar(40)   NOT NULL,
        EmailDomain        nvarchar(128)  NULL,
        PhoneMasked        varchar(20)    NOT NULL,
        AgeBand            varchar(15)    NOT NULL,
        AccountCount       int            NOT NULL,
        TotalBalanceBand   varchar(20)    NOT NULL,
        SnapshotUtc        datetime2(3)   NOT NULL
    );
END;
GO

/* -------------------------------------------------------------------------
   5. Queryable data dictionary
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'sec.DataDictionary', N'U') IS NULL
BEGIN
    CREATE TABLE sec.DataDictionary
    (
        DictionaryID       int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DataDictionary PRIMARY KEY,
        SchemaName         sysname NOT NULL,
        TableName          sysname NOT NULL,
        ColumnName         sysname NOT NULL,
        DataType           nvarchar(100) NOT NULL,
        AllowsNull         bit NOT NULL,
        Classification     varchar(20) NOT NULL,
        InformationType    nvarchar(100) NOT NULL,
        BusinessPurpose    nvarchar(500) NOT NULL,
        ProtectionControl  nvarchar(500) NOT NULL,
        CONSTRAINT UQ_DataDictionary UNIQUE (SchemaName, TableName, ColumnName),
        CONSTRAINT CK_DataDictionary_Class CHECK (Classification IN ('Public', 'Internal', 'Confidential', 'Private'))
    );
END;
GO

TRUNCATE TABLE sec.DataDictionary;

INSERT sec.DataDictionary
(
    SchemaName, TableName, ColumnName, DataType, AllowsNull,
    Classification, InformationType, BusinessPurpose, ProtectionControl
)
VALUES
(N'bank', N'Staff', N'StaffID', N'char(6)', 0, 'Internal', N'Employee identifier', N'Uniquely identifies staff.', N'Primary key; RBAC; not exposed publicly.'),
(N'bank', N'Staff', N'StaffName', N'nvarchar(100)', 0, 'Public', N'Name', N'Identifies bank staff.', N'Exposed only with Phone through the public staff-directory view.'),
(N'bank', N'Staff', N'Position', N'varchar(20)', 0, 'Internal', N'Job role', N'Drives staff responsibilities.', N'CHECK constraint and restricted staff views/procedures.'),
(N'bank', N'Staff', N'Branch', N'nvarchar(50)', 0, 'Internal', N'Organisational unit', N'Identifies work location.', N'RBAC and self-service procedure.'),
(N'bank', N'Staff', N'Phone', N'varchar(20)', 0, 'Public', N'Contact number', N'Allows authenticated users to contact staff.', N'Public directory view; direct table access denied.'),
(N'bank', N'StaffPrivate', N'SalaryCipher', N'varbinary(256)', 0, 'Private', N'Financial information', N'Stores staff salary.', N'AES-256 column-level encryption with authenticated ciphertext; decrypted only inside authorised stored procedures.'),
(N'bank', N'Customer', N'CustomerID', N'char(6)', 0, 'Internal', N'Customer identifier', N'Links customer records and accounts.', N'Primary key and row-level security mapping.'),
(N'bank', N'Customer', N'CustomerName', N'nvarchar(100)', 0, 'Internal', N'Name', N'Customer servicing.', N'Views, RBAC, and no direct table access.'),
(N'bank', N'Customer', N'Email', N'varchar(254)', 0, 'Confidential', N'Contact information', N'Customer communication.', N'Dynamic Data Masking; UNMASK only for Bank Officers; customers receive own value through a secure procedure.'),
(N'bank', N'Customer', N'Phone', N'varchar(20)', 0, 'Confidential', N'Contact information', N'Customer verification and communication.', N'Dynamic Data Masking; UNMASK only for Bank Officers.'),
(N'bank', N'Customer', N'DateOfBirth', N'date', 0, 'Confidential', N'Personal information', N'Identity verification.', N'Dynamic Data Masking and secure customer-profile procedure.'),
(N'bank', N'Customer', N'ICNumberCipher', N'varbinary(256)', 0, 'Private', N'National identifier', N'Identity verification and regulatory compliance.', N'AES-256 column-level encryption with per-record authenticator.'),
(N'bank', N'Customer', N'AddressCipher', N'varbinary(512)', 0, 'Private', N'Address', N'Customer correspondence and KYC.', N'AES-256 column-level encryption with per-record authenticator.'),
(N'bank', N'Customer', N'ICNumberHash', N'varbinary(32)', 0, 'Private', N'Hashed identifier', N'One-way integrity and duplicate-check support.', N'SHA2-256 salted hash; table access denied.'),
(N'bank', N'Account', N'AccountID', N'char(10)', 0, 'Confidential', N'Financial account identifier', N'Identifies a customer account.', N'RLS, views, foreign keys, and direct DML denial.'),
(N'bank', N'Account', N'CustomerID', N'char(6)', 0, 'Confidential', N'Ownership link', N'Associates account with a customer.', N'Foreign key and RLS predicate.'),
(N'bank', N'Account', N'Balance', N'decimal(15,2)', 0, 'Private', N'Financial balance', N'Current available balance.', N'RLS; transaction procedures; CHECK constraint; encrypted backups.'),
(N'bank', N'TransactionRecord', N'TransID', N'bigint', 0, 'Internal', N'Transaction identifier', N'Immutable transaction identifier.', N'Identity primary key; append-only access model.'),
(N'bank', N'TransactionRecord', N'Amount', N'decimal(15,2)', 0, 'Private', N'Financial transaction', N'Value transferred.', N'RLS; CHECK constraint; secure stored procedures; encrypted backups.'),
(N'bank', N'TransactionRecord', N'TransactionType', N'varchar(12)', 0, 'Confidential', N'Transaction category', N'Deposit, withdrawal, or transfer.', N'CHECK constraint limiting valid values.'),
(N'audit', N'BusinessActionLog', N'ErrorMessage', N'nvarchar(2048)', 1, 'Confidential', N'Security audit evidence', N'Explains valid and invalid attempted operations.', N'Read-only auditor access; encrypted backups; append-only permissions.'),
(N'audit', N'DMLChangeLog', N'OldRowsJson', N'nvarchar(max)', 1, 'Private', N'Change history', N'Captures before-images of changed records.', N'Restricted auditor access and encrypted backups.'),
(N'audit', N'DDLSecurityChangeLog', N'TSQLCommand', N'nvarchar(max)', 1, 'Confidential', N'DDL and permission audit', N'Captures database definition and permission changes.', N'DDL trigger plus SQL Server Audit; auditor-only access.');
GO

/* -------------------------------------------------------------------------
   6. SQL Server sensitivity classifications
   ------------------------------------------------------------------------- */
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.StaffPrivate.SalaryCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Customer.ICNumberCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'National ID', RANK = CRITICAL);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Customer.AddressCipher
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Address', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.Account.Balance
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO
BEGIN TRY
    ADD SENSITIVITY CLASSIFICATION TO bank.TransactionRecord.Amount
    WITH (LABEL = 'Private', INFORMATION_TYPE = 'Financial', RANK = HIGH);
END TRY BEGIN CATCH IF ERROR_NUMBER() NOT IN (33270, 33271) PRINT ERROR_MESSAGE(); END CATCH;
GO

SELECT SchemaName, TableName, ColumnName, Classification, ProtectionControl
FROM sec.DataDictionary
ORDER BY SchemaName, TableName, DictionaryID;
GO

PRINT '02 secure data model and classification completed successfully.';
GO
