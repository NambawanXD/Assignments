/*
SmartBankDB - Defence-in-depth auditing
1. SQL Server Audit: login, logout, DML, DDL, and permission changes.
2. DML triggers: before/after JSON for successful changes.
3. Database DDL trigger: command text and EVENTDATA for DDL/security changes.
4. BusinessActionLog: successful and failed business operations.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Audit matrix stored inside the database
   ------------------------------------------------------------------------- */
IF OBJECT_ID(N'audit.AuditMatrix', N'U') IS NULL
BEGIN
    CREATE TABLE audit.AuditMatrix
    (
        AuditMatrixID      int IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditMatrix PRIMARY KEY,
        AuditArea          nvarchar(80) NOT NULL,
        EventsCaptured     nvarchar(500) NOT NULL,
        ObjectsCovered     nvarchar(500) NOT NULL,
        Mechanism          nvarchar(300) NOT NULL,
        LogLocation        nvarchar(500) NOT NULL,
        ReviewResponsibility nvarchar(200) NOT NULL,
        RetentionGuideline nvarchar(200) NOT NULL
    );
END;
GO

TRUNCATE TABLE audit.AuditMatrix;
INSERT audit.AuditMatrix
(
    AuditArea, EventsCaptured, ObjectsCovered, Mechanism,
    LogLocation, ReviewResponsibility, RetentionGuideline
)
VALUES
(N'Login and logout', N'Successful login, failed login, and logout events.', N'All SQL Server logins, especially SB_* demo users.', N'SQL Server Audit server action groups.', N'SmartBankAudit folder configured in admin.Configuration.', N'Security Auditor / DBA oversight.', N'Minimum 90 days for the assignment demonstration.'),
(N'Data access', N'SELECT and stored-procedure execution, including success or failure.', N'bank schema and api schema.', N'SQL Server Database Audit Specification.', N'.sqlaudit files.', N'Security Auditor.', N'Minimum 90 days.'),
(N'Valid DML', N'INSERT, UPDATE, DELETE with before/after images.', N'bank.Staff, StaffPrivate, Customer, Account, TransactionRecord.', N'AFTER DML triggers plus SQL Server Audit.', N'audit.DMLChangeLog and .sqlaudit files.', N'Security Auditor and investigation team.', N'Minimum 1 year for financial-change evidence.'),
(N'Invalid business action', N'Invalid amount, insufficient balance, wrong ownership, invalid role, and other rejected procedure calls.', N'api stored procedures.', N'TRY/CATCH logging to audit.BusinessActionLog.', N'audit.BusinessActionLog.', N'Security Auditor.', N'Minimum 1 year.'),
(N'Invalid direct DML', N'Permission denied or RLS-blocked INSERT, UPDATE, DELETE.', N'bank schema.', N'SQL Server Audit records succeeded = 0.', N'.sqlaudit files.', N'Security Auditor.', N'Minimum 1 year.'),
(N'DDL', N'CREATE, ALTER, DROP, and other database-level definition events.', N'Database, schemas, tables, views, procedures, functions, triggers, keys, and certificates.', N'Database DDL trigger plus SQL Server Audit action groups.', N'audit.DDLSecurityChangeLog and .sqlaudit files.', N'Security Auditor / DBA oversight.', N'Minimum 1 year.'),
(N'Permission changes', N'GRANT, DENY, REVOKE, CREATE/ALTER/DROP USER or ROLE, and role membership changes.', N'Server logins, database users, roles, and securables.', N'DDL trigger plus server/database audit permission action groups.', N'audit.DDLSecurityChangeLog and .sqlaudit files.', N'Security Auditor.', N'Minimum 1 year.'),
(N'Backup operations', N'Full, differential, and log backup status, verification status, and failures.', N'SmartBankDB backup jobs.', N'Backup procedure evidence table plus msdb backup/job history.', N'audit.BackupEvidence, msdb, and backup files.', N'DBA and Security Auditor.', N'Keep enough generations to satisfy RPO and restore testing.');
GO

/* -------------------------------------------------------------------------
   2. Successful DML change triggers
   Trigger schema matches the target-table schema, preventing Msg 2103.
   ------------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER bank.trg_Staff_DMLAudit
ON bank.Staff
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Staff', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_StaffPrivate_DMLAudit
ON bank.StaffPrivate
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'StaffPrivate', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_Customer_DMLAudit
ON bank.Customer
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Customer', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_Account_DMLAudit
ON bank.Account
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'Account', @Action, @Rows, @OldJson, @NewJson);
END;
GO

CREATE OR ALTER TRIGGER bank.trg_TransactionRecord_DMLAudit
ON bank.TransactionRecord
WITH EXECUTE AS OWNER
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF ROWCOUNT_BIG() = 0 RETURN;

    DECLARE @Action varchar(10);
    DECLARE @OldJson nvarchar(max);
    DECLARE @NewJson nvarchar(max);
    DECLARE @Rows int;
    DECLARE @LoginName sysname = ORIGINAL_LOGIN();
    DECLARE @DatabaseUserName sysname =
        COALESCE
        (
            (SELECT DatabaseUserName FROM sec.LoginIdentityMap WHERE LoginName = ORIGINAL_LOGIN()),
            USER_NAME()
        );

    SET @Action = CASE
        WHEN EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted) THEN 'UPDATE'
        WHEN EXISTS (SELECT 1 FROM inserted) THEN 'INSERT'
        ELSE 'DELETE'
    END;
    SET @OldJson = CASE WHEN EXISTS (SELECT 1 FROM deleted) THEN (SELECT * FROM deleted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @NewJson = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT * FROM inserted FOR JSON PATH, INCLUDE_NULL_VALUES) END;
    SET @Rows = CASE WHEN EXISTS (SELECT 1 FROM inserted) THEN (SELECT COUNT(*) FROM inserted) ELSE (SELECT COUNT(*) FROM deleted) END;

    INSERT audit.DMLChangeLog
    (
        LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson
    )
    VALUES (@LoginName, @DatabaseUserName, N'bank', N'TransactionRecord', @Action, @Rows, @OldJson, @NewJson);
END;
GO

/* -------------------------------------------------------------------------
   3. Database-level DDL and permission-change trigger
   A DDL trigger has no schema prefix, preventing Msg 1094.
   ------------------------------------------------------------------------- */
CREATE OR ALTER TRIGGER trg_DatabaseDDLAndPermissionAudit
ON DATABASE
WITH EXECUTE AS 'dbo'
FOR DDL_DATABASE_LEVEL_EVENTS
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @EventData xml = EVENTDATA();

    INSERT audit.DDLSecurityChangeLog
    (
        LoginName, DatabaseUserName, EventType, ObjectType,
        SchemaName, ObjectName, TSQLCommand, EventDataXml,
        HostName, ApplicationName
    )
    VALUES
    (
        ORIGINAL_LOGIN(),
        COALESCE(@EventData.value('(/EVENT_INSTANCE/UserName)[1]', 'sysname'), USER_NAME()),
        @EventData.value('(/EVENT_INSTANCE/EventType)[1]', 'sysname'),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/ObjectType)[1]', 'sysname'), N''),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/SchemaName)[1]', 'sysname'), N''),
        NULLIF(@EventData.value('(/EVENT_INSTANCE/ObjectName)[1]', 'sysname'), N''),
        @EventData.value('(/EVENT_INSTANCE/TSQLCommand/CommandText)[1]', 'nvarchar(max)'),
        @EventData,
        HOST_NAME(),
        APP_NAME()
    );
END;
GO

/* -------------------------------------------------------------------------
   4. SQL Server Audit target and server audit specification
   ------------------------------------------------------------------------- */
USE master;
GO

IF EXISTS (SELECT 1 FROM sys.server_audit_specifications WHERE name = N'SmartBank_ServerAuditSpec')
BEGIN
    ALTER SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec WITH (STATE = OFF);
    DROP SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec;
END;
GO

IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = N'SmartBank_ServerAudit')
BEGIN
    ALTER SERVER AUDIT SmartBank_ServerAudit WITH (STATE = OFF);
    DROP SERVER AUDIT SmartBank_ServerAudit;
END;
GO

DECLARE @AuditPath nvarchar(4000) =
(
    SELECT ConfigValue
    FROM SmartBankDB.admin.Configuration
    WHERE ConfigKey = N'AuditPath'
);

IF @AuditPath IS NULL
    THROW 51401, 'AuditPath is missing from SmartBankDB.admin.Configuration.', 1;

BEGIN TRY
    EXEC master.dbo.xp_create_subdir @AuditPath;
END TRY
BEGIN CATCH
    PRINT 'Audit directory warning: ' + ERROR_MESSAGE();
END CATCH;

DECLARE @CreateAuditSql nvarchar(max) =
    N'CREATE SERVER AUDIT SmartBank_ServerAudit
      TO FILE
      (
          FILEPATH = N''' + REPLACE(@AuditPath, '''', '''''') + N''',
          MAXSIZE = 512 MB,
          MAX_ROLLOVER_FILES = 50,
          RESERVE_DISK_SPACE = OFF
      )
      WITH
      (
          QUEUE_DELAY = 1000,
          ON_FAILURE = CONTINUE
      );';
EXEC sys.sp_executesql @CreateAuditSql;
GO

CREATE SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec
FOR SERVER AUDIT SmartBank_ServerAudit
    ADD (SUCCESSFUL_LOGIN_GROUP),
    ADD (FAILED_LOGIN_GROUP),
    ADD (LOGOUT_GROUP),
    ADD (SERVER_PRINCIPAL_CHANGE_GROUP),
    ADD (SERVER_ROLE_MEMBER_CHANGE_GROUP),
    ADD (SERVER_OBJECT_PERMISSION_CHANGE_GROUP),
    ADD (AUDIT_CHANGE_GROUP)
WITH (STATE = ON);
GO

ALTER SERVER AUDIT SmartBank_ServerAudit WITH (STATE = ON);
GO

/* -------------------------------------------------------------------------
   5. Database audit specification
   ------------------------------------------------------------------------- */
USE SmartBankDB;
GO

IF EXISTS (SELECT 1 FROM sys.database_audit_specifications WHERE name = N'SmartBank_DatabaseAuditSpec')
BEGIN
    ALTER DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec WITH (STATE = OFF);
    DROP DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec;
END;
GO

CREATE DATABASE AUDIT SPECIFICATION SmartBank_DatabaseAuditSpec
FOR SERVER AUDIT SmartBank_ServerAudit
    ADD (SELECT ON SCHEMA::bank BY public),
    ADD (INSERT, UPDATE, DELETE ON SCHEMA::bank BY public),
    ADD (EXECUTE ON SCHEMA::api BY public),
    ADD (DATABASE_OBJECT_CHANGE_GROUP),
    ADD (SCHEMA_OBJECT_CHANGE_GROUP),
    ADD (DATABASE_PRINCIPAL_CHANGE_GROUP),
    ADD (DATABASE_ROLE_MEMBER_CHANGE_GROUP),
    ADD (DATABASE_OBJECT_PERMISSION_CHANGE_GROUP),
    ADD (SCHEMA_OBJECT_PERMISSION_CHANGE_GROUP)
WITH (STATE = ON);
GO

/* -------------------------------------------------------------------------
   6. Audit reporting views and procedure
   ------------------------------------------------------------------------- */
CREATE OR ALTER VIEW audit.vw_RecentBusinessActions
AS
    SELECT
        AuditID, EventTimeUtc, LoginName, DatabaseUserName, RoleCode,
        ActionCategory, ActionName, TargetObject, Success,
        ErrorNumber, ErrorMessage, KeyValuesJson, HostName, ApplicationName
    FROM audit.BusinessActionLog;
GO

CREATE OR ALTER VIEW audit.vw_RecentDMLChanges
AS
    SELECT
        ChangeAuditID, EventTimeUtc, LoginName, DatabaseUserName,
        SchemaName, TableName, DMLAction, RowCountAffected,
        OldRowsJson, NewRowsJson, HostName, ApplicationName
    FROM audit.DMLChangeLog;
GO

CREATE OR ALTER VIEW audit.vw_RecentDDLAndPermissionChanges
AS
    SELECT
        DDLAuditID, EventTimeUtc, LoginName, DatabaseUserName,
        EventType, ObjectType, SchemaName, ObjectName,
        TSQLCommand, HostName, ApplicationName
    FROM audit.DDLSecurityChangeLog;
GO

CREATE OR ALTER PROCEDURE audit.usp_ReadSqlServerAudit
    @TopRows int = 500,
    @LoginName sysname = NULL,
    @DatabaseName sysname = N'SmartBankDB'
WITH EXECUTE AS CALLER
AS
BEGIN
    SET NOCOUNT ON;

    IF IS_SRVROLEMEMBER('sysadmin') <> 1
       AND USER_NAME() <> N'SB_AUDITOR01'
        THROW 51402, 'Only a sysadmin or the designated Security Auditor may read consolidated audit output.', 1;

    DECLARE @AuditPath nvarchar(4000) =
    (
        SELECT ConfigValue
        FROM admin.Configuration
        WHERE ConfigKey = N'AuditPath'
    );

    DECLARE @Pattern nvarchar(4000) = @AuditPath + N'*.sqlaudit';

    SELECT TOP (@TopRows)
        event_time,
        sequence_number,
        action_id,
        succeeded,
        permission_bitmask,
        is_column_permission,
        session_id,
        server_principal_name,
        session_server_principal_name,
        database_principal_name,
        target_server_principal_name,
        target_database_principal_name,
        database_name,
        schema_name,
        object_name,
        statement,
        additional_information,
        application_name,
        client_ip
    FROM sys.fn_get_audit_file(@Pattern, DEFAULT, DEFAULT)
    WHERE (@LoginName IS NULL OR session_server_principal_name = @LoginName OR server_principal_name = @LoginName)
      AND (@DatabaseName IS NULL OR database_name = @DatabaseName OR database_name IS NULL)
    ORDER BY event_time DESC, sequence_number DESC;
END;
GO

SELECT
    s.name AS audit_specification_name,
    s.is_state_enabled,
    d.audit_action_name,
    d.class_desc,
    d.audited_result
FROM sys.database_audit_specifications AS s
INNER JOIN sys.database_audit_specification_details AS d
    ON d.database_specification_id = s.database_specification_id
ORDER BY s.name, d.audit_action_name;
GO

PRINT '06 auditing infrastructure completed successfully.';
GO
