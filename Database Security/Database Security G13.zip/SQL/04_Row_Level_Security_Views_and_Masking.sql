/*
SmartBankDB - Row-Level Security, secure views, and masking demonstration.
RLS protects Account and TransactionRecord even if a direct SELECT is granted accidentally.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. RLS predicate functions
   ------------------------------------------------------------------------- */
CREATE OR ALTER FUNCTION sec.fn_AccountAccessPredicate
(
    @CustomerID char(6)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS AccessAllowed
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.RoleCode IN ('BANK_MANAGER', 'BANK_OFFICER')
                  OR (m.RoleCode = 'CUSTOMER' AND m.CustomerID = @CustomerID)
              )
        )
);
GO

CREATE OR ALTER FUNCTION sec.fn_TransactionAccessPredicate
(
    @CustomerID char(6)
)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS AccessAllowed
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.RoleCode IN ('BANK_MANAGER', 'BANK_OFFICER')
                  OR (m.RoleCode = 'CUSTOMER' AND m.CustomerID = @CustomerID)
              )
        )
);
GO

/* -------------------------------------------------------------------------
   2. Security policies: filter reads and block unauthorized writes
   ------------------------------------------------------------------------- */
IF EXISTS (SELECT 1 FROM sys.security_policies WHERE name = N'AccountAccessPolicy')
    DROP SECURITY POLICY sec.AccountAccessPolicy;
GO

CREATE SECURITY POLICY sec.AccountAccessPolicy
ADD FILTER PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account,
ADD BLOCK PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account AFTER INSERT,
ADD BLOCK PREDICATE sec.fn_AccountAccessPredicate(CustomerID) ON bank.Account AFTER UPDATE
WITH (STATE = ON, SCHEMABINDING = ON);
GO

IF EXISTS (SELECT 1 FROM sys.security_policies WHERE name = N'TransactionAccessPolicy')
    DROP SECURITY POLICY sec.TransactionAccessPolicy;
GO

CREATE SECURITY POLICY sec.TransactionAccessPolicy
ADD FILTER PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord,
ADD BLOCK PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord AFTER INSERT,
ADD BLOCK PREDICATE sec.fn_TransactionAccessPredicate(CustomerID) ON bank.TransactionRecord AFTER UPDATE
WITH (STATE = ON, SCHEMABINDING = ON);
GO

/* -------------------------------------------------------------------------
   3. Views
   ------------------------------------------------------------------------- */
CREATE OR ALTER VIEW sec.vw_PublicStaffDirectory
AS
    SELECT StaffName, Phone
    FROM bank.Staff
    WHERE IsActive = 1;
GO

CREATE OR ALTER VIEW sec.vw_StaffBasicAccess
AS
    SELECT
        s.StaffID,
        s.StaffName,
        s.Position,
        s.Branch,
        s.Phone,
        s.IsActive,
        s.ModifiedAt,
        s.ModifiedBy
    FROM bank.Staff AS s
    WHERE
        USER_NAME() = N'dbo'
        OR EXISTS
        (
            SELECT 1
            FROM sec.LoginIdentityMap AS m
            WHERE m.DatabaseUserName = USER_NAME()
              AND m.IsActive = 1
              AND
              (
                  m.StaffID = s.StaffID
                  OR (m.RoleCode = 'BANK_MANAGER' AND s.Position = 'Bank Officer')
              )
        );
GO

CREATE OR ALTER VIEW sec.vw_AccountAccess
AS
    SELECT
        AccountID,
        CustomerID,
        AccountType,
        Balance,
        AccountStatus,
        OpenedAt,
        ClosedAt,
        ModifiedAt
    FROM bank.Account;
GO

CREATE OR ALTER VIEW sec.vw_TransactionAccess
AS
    SELECT
        TransID,
        TransactionReference,
        TransferGroupID,
        CustomerID,
        AccountID,
        CounterpartyAccountID,
        TransDate,
        Amount,
        TransactionType,
        Direction,
        BalanceBefore,
        BalanceAfter,
        Remarks,
        InitiatedByLogin
    FROM bank.TransactionRecord;
GO

/* DDM is preserved through this view. Manager sees masked contact values.
   Bank Officer receives UNMASK later because the role requires customer servicing. */
CREATE OR ALTER VIEW sec.vw_CustomerContact
AS
    SELECT
        CustomerID,
        CustomerName,
        Email,
        Phone,
        DateOfBirth,
        CustomerStatus,
        ModifiedAt
    FROM bank.Customer;
GO

CREATE OR ALTER VIEW reporting.vw_BranchAccountSummary
AS
    SELECT
        s.Branch,
        a.AccountType,
        COUNT_BIG(*) AS NumberOfAccounts,
        SUM(a.Balance) AS TotalBalance,
        AVG(a.Balance) AS AverageBalance
    FROM bank.Account AS a
    CROSS JOIN
    (
        SELECT TOP (1) Branch
        FROM bank.Staff
        WHERE Position = 'Bank Manager' AND IsActive = 1
        ORDER BY StaffID
    ) AS s
    GROUP BY s.Branch, a.AccountType;
GO

CREATE OR ALTER VIEW sec.vw_RoleUserMapping
AS
    SELECT
        roles.name AS RoleName,
        members.name AS UserName,
        map.RoleCode,
        map.StaffID,
        map.CustomerID,
        map.IsActive
    FROM sys.database_role_members AS drm
    INNER JOIN sys.database_principals AS roles
        ON roles.principal_id = drm.role_principal_id
    INNER JOIN sys.database_principals AS members
        ON members.principal_id = drm.member_principal_id
    LEFT JOIN sec.LoginIdentityMap AS map
        ON map.DatabaseUserName = members.name
    WHERE roles.name LIKE N'role[_]%';
GO

CREATE OR ALTER VIEW sec.vw_ExplicitRolePermissions
AS
    SELECT
        principal.name AS RoleName,
        permission.state_desc AS PermissionState,
        permission.permission_name AS PermissionName,
        permission.class_desc AS PermissionClass,
        CASE permission.class
            WHEN 0 THEN DB_NAME()
            WHEN 1 THEN QUOTENAME(OBJECT_SCHEMA_NAME(permission.major_id)) + N'.' + QUOTENAME(OBJECT_NAME(permission.major_id))
            WHEN 3 THEN QUOTENAME(SCHEMA_NAME(permission.major_id))
            ELSE CONVERT(nvarchar(128), permission.major_id)
        END AS SecurableName
    FROM sys.database_permissions AS permission
    INNER JOIN sys.database_principals AS principal
        ON principal.principal_id = permission.grantee_principal_id
    WHERE principal.name LIKE N'role[_]%';
GO

/* -------------------------------------------------------------------------
   4. Demonstration of RLS metadata and DDM metadata
   ------------------------------------------------------------------------- */
SELECT
    policy.name AS SecurityPolicy,
    predicate.predicate_type_desc,
    OBJECT_SCHEMA_NAME(predicate.target_object_id) AS TargetSchema,
    OBJECT_NAME(predicate.target_object_id) AS TargetTable,
    predicate.predicate_definition
FROM sys.security_policies AS policy
INNER JOIN sys.security_predicates AS predicate
    ON predicate.object_id = policy.object_id
ORDER BY policy.name, predicate.predicate_type_desc;

SELECT
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS ColumnName,
    masking_function
FROM sys.masked_columns
WHERE is_masked = 1
ORDER BY SchemaName, TableName, ColumnName;
GO

PRINT '04 RLS, views, and masking objects completed successfully.';
GO
