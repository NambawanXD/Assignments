/*
SmartBankDB targeted repair for the two compatibility errors reported after
SmartBankDB_Install_AllInOne.sql.

Run this once in SSMS using the same Windows/sysadmin connection.
No reset or database rebuild is required.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

PRINT '1. Verifying the database audit specification with corrected catalog joins.';

SELECT
    s.name AS audit_specification_name,
    s.is_state_enabled,
    d.audit_action_name,
    d.class_desc,
    d.audited_result
FROM sys.database_audit_specifications AS s
INNER JOIN sys.database_audit_specification_details AS d
    ON d.database_specification_id = s.database_specification_id
ORDER BY s.name, d.audit_action_name;
GO

PRINT '2. Recreating admin.usp_BackupReadinessReport with corrected backup metadata joins.';
GO

CREATE OR ALTER PROCEDURE admin.usp_BackupReadinessReport
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        servicename,
        status_desc,
        startup_type_desc,
        last_startup_time,
        service_account
    FROM sys.dm_server_services
    WHERE servicename LIKE N'SQL Server Agent%'
       OR servicename LIKE N'SQL Server (%';

    SELECT
        j.name AS JobName,
        j.enabled,
        CASE h.run_status
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Cancelled'
            WHEN 4 THEN 'In Progress'
            ELSE 'No history'
        END AS LastOutcome,
        msdb.dbo.agent_datetime(h.run_date, h.run_time) AS LastRunDateTime,
        h.message AS LastMessage
    FROM msdb.dbo.sysjobs AS j
    OUTER APPLY
    (
        SELECT TOP (1) run_status, run_date, run_time, message
        FROM msdb.dbo.sysjobhistory AS h2
        WHERE h2.job_id = j.job_id
          AND h2.step_id = 0
        ORDER BY h2.instance_id DESC
    ) AS h
    WHERE j.name LIKE N'SmartBank - % Backup'
    ORDER BY j.name;

    ;WITH LastThreeDays AS
    (
        SELECT CAST(DATEADD(day, -2, GETDATE()) AS date) AS BackupDate
        UNION ALL SELECT CAST(DATEADD(day, -1, GETDATE()) AS date)
        UNION ALL SELECT CAST(GETDATE() AS date)
    ),
    BackupCounts AS
    (
        SELECT
            CAST(backup_finish_date AS date) AS BackupDate,
            SUM(CASE WHEN type = 'D' THEN 1 ELSE 0 END) AS FullBackups,
            SUM(CASE WHEN type = 'I' THEN 1 ELSE 0 END) AS DifferentialBackups,
            SUM(CASE WHEN type = 'L' THEN 1 ELSE 0 END) AS LogBackups,
            SUM(CASE WHEN key_algorithm = 'AES_256' THEN 1 ELSE 0 END) AS AES256Backups
        FROM msdb.dbo.backupset
        WHERE database_name = N'SmartBankDB'
          AND backup_finish_date >= DATEADD(day, -3, CAST(GETDATE() AS date))
        GROUP BY CAST(backup_finish_date AS date)
    )
    SELECT
        d.BackupDate,
        COALESCE(b.FullBackups, 0) AS FullBackups,
        COALESCE(b.DifferentialBackups, 0) AS DifferentialBackups,
        COALESCE(b.LogBackups, 0) AS LogBackups,
        COALESCE(b.AES256Backups, 0) AS AES256Backups,
        CASE
            WHEN COALESCE(b.FullBackups, 0) >= 1
             AND COALESCE(b.DifferentialBackups, 0) >= 1
             AND COALESCE(b.LogBackups, 0) >= 1
             AND COALESCE(b.AES256Backups, 0) >= 3
            THEN 'PASS'
            ELSE 'NOT READY'
        END AS DailyReadiness
    FROM LastThreeDays AS d
    LEFT JOIN BackupCounts AS b
        ON b.BackupDate = d.BackupDate
    ORDER BY d.BackupDate;

    SELECT TOP (200)
        BackupEvidenceID,
        BackupStartUtc,
        BackupFinishUtc,
        BackupType,
        BackupFile,
        Encrypted,
        VerifyOnlyPassed,
        Success,
        ErrorMessage,
        SqlAgentJobName
    FROM audit.BackupEvidence
    ORDER BY BackupEvidenceID DESC;

    SELECT TOP (200)
        bs.backup_set_id,
        bs.database_name,
        CASE bs.type
            WHEN 'D' THEN 'FULL'
            WHEN 'I' THEN 'DIFFERENTIAL'
            WHEN 'L' THEN 'LOG'
            ELSE bs.type
        END AS BackupType,
        bs.backup_start_date,
        bs.backup_finish_date,
        bs.is_copy_only,
        bs.has_backup_checksums,
        bms.is_compressed,
        bms.is_encrypted,
        bs.key_algorithm,
        bs.encryptor_type,
        CONVERT(decimal(12,2), bs.backup_size / 1048576.0) AS BackupSizeMB,
        CONVERT(decimal(12,2), bs.compressed_backup_size / 1048576.0) AS CompressedBackupSizeMB,
        bmf.physical_device_name
    FROM msdb.dbo.backupset AS bs
    INNER JOIN msdb.dbo.backupmediafamily AS bmf
        ON bmf.media_set_id = bs.media_set_id
    INNER JOIN msdb.dbo.backupmediaset AS bms
        ON bms.media_set_id = bs.media_set_id
    WHERE bs.database_name = N'SmartBankDB'
    ORDER BY bs.backup_finish_date DESC;
END;
GO

PRINT '3. Running the repaired readiness report.';
EXEC admin.usp_BackupReadinessReport;
GO

PRINT '4. Confirming the repaired stored procedure exists.';
SELECT
    SCHEMA_NAME(schema_id) AS SchemaName,
    name AS ProcedureName,
    create_date,
    modify_date
FROM sys.procedures
WHERE object_id = OBJECT_ID(N'admin.usp_BackupReadinessReport');
GO

PRINT 'SmartBankDB repair completed successfully.';
GO
