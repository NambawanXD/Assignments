/*
SmartBankDB - Encrypted backup strategy and SQL Server Agent automation
RPO: 15 minutes. RTO target: 60 minutes in the lab.
Schedules:
- Full: daily 01:00
- Differential: every 6 hours from 07:00
- Transaction log: every 15 minutes

Requires SQL Server Developer/Standard and SQL Server Agent running.
*/
USE SmartBankDB;
GO
SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1. Backup procedure with AES-256, compression, checksum and VERIFYONLY
   ------------------------------------------------------------------------- */
CREATE OR ALTER PROCEDURE admin.usp_RunBackup
    @BackupType varchar(12),
    @JobName sysname = NULL
WITH EXECUTE AS CALLER
AS
BEGIN
    SET NOCOUNT ON;

    IF IS_SRVROLEMEMBER('sysadmin') <> 1
        THROW 51501, 'Only a sysadmin or a sysadmin-owned SQL Agent job may run database backups.', 1;

    SET @BackupType = UPPER(LTRIM(RTRIM(@BackupType)));
    IF @BackupType NOT IN ('FULL', 'DIFFERENTIAL', 'LOG')
        THROW 51502, 'BackupType must be FULL, DIFFERENTIAL, or LOG.', 1;

    DECLARE @BackupPath nvarchar(4000) =
    (
        SELECT ConfigValue
        FROM admin.Configuration
        WHERE ConfigKey = N'BackupPath'
    );
    DECLARE @Timestamp char(15) =
        CONVERT(char(8), GETDATE(), 112) + N'_' + REPLACE(CONVERT(char(8), GETDATE(), 108), ':', '');
    DECLARE @Extension varchar(4) = CASE WHEN @BackupType = 'LOG' THEN '.trn' ELSE '.bak' END;
    DECLARE @BackupFile nvarchar(4000) =
        @BackupPath + N'SmartBankDB_' + @BackupType + N'_' + @Timestamp + @Extension;
    DECLARE @BackupStartUtc datetime2(3) = SYSUTCDATETIME();
    DECLARE @BackupFinishUtc datetime2(3);
    DECLARE @BackupSql nvarchar(max);
    DECLARE @VerifySql nvarchar(max);

    BEGIN TRY
        IF @BackupPath IS NULL
            THROW 51503, 'BackupPath is missing from admin.Configuration.', 1;

        BEGIN TRY
            EXEC master.dbo.xp_create_subdir @BackupPath;
        END TRY
        BEGIN CATCH
            PRINT 'Backup directory warning: ' + ERROR_MESSAGE();
        END CATCH;

        IF @BackupType = 'FULL'
        BEGIN
            SET @BackupSql =
                N'BACKUP DATABASE SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;
        ELSE IF @BackupType = 'DIFFERENTIAL'
        BEGIN
            SET @BackupSql =
                N'BACKUP DATABASE SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH DIFFERENTIAL, INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;
        ELSE
        BEGIN
            SET @BackupSql =
                N'BACKUP LOG SmartBankDB TO DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N'''
                  WITH INIT, COMPRESSION, CHECKSUM,
                       ENCRYPTION (ALGORITHM = AES_256, SERVER CERTIFICATE = SmartBankBackupCertificate),
                       STATS = 5;';
        END;

        EXEC sys.sp_executesql @BackupSql;

        SET @VerifySql =
            N'RESTORE VERIFYONLY FROM DISK = N''' + REPLACE(@BackupFile, '''', '''''') + N''' WITH CHECKSUM;';
        EXEC sys.sp_executesql @VerifySql;

        SET @BackupFinishUtc = SYSUTCDATETIME();

        INSERT audit.BackupEvidence
        (
            BackupStartUtc, BackupFinishUtc, BackupType, BackupFile,
            Encrypted, CompressionUsed, ChecksumUsed, VerifyOnlyPassed,
            Success, ErrorMessage, ExecutedBy, SqlAgentJobName
        )
        VALUES
        (
            @BackupStartUtc, @BackupFinishUtc, @BackupType, @BackupFile,
            1, 1, 1, 1,
            1, NULL, ORIGINAL_LOGIN(), @JobName
        );

        SELECT
            @BackupType AS BackupType,
            @BackupFile AS BackupFile,
            @BackupStartUtc AS BackupStartUtc,
            @BackupFinishUtc AS BackupFinishUtc,
            CAST(1 AS bit) AS Encrypted,
            CAST(1 AS bit) AS VerifyOnlyPassed;
    END TRY
    BEGIN CATCH
        SET @BackupFinishUtc = SYSUTCDATETIME();
        DECLARE @ErrorMessage nvarchar(2048) = ERROR_MESSAGE();

        INSERT audit.BackupEvidence
        (
            BackupStartUtc, BackupFinishUtc, BackupType, BackupFile,
            Encrypted, CompressionUsed, ChecksumUsed, VerifyOnlyPassed,
            Success, ErrorMessage, ExecutedBy, SqlAgentJobName
        )
        VALUES
        (
            @BackupStartUtc, @BackupFinishUtc, @BackupType,
            COALESCE(@BackupFile, N'Not created'),
            1, 1, 1, 0,
            0, @ErrorMessage, ORIGINAL_LOGIN(), @JobName
        );
        THROW;
    END CATCH;
END;
GO

/* -------------------------------------------------------------------------
   2. Export backup certificate and private key for another-instance restore
   ------------------------------------------------------------------------- */
DECLARE @BackupPath nvarchar(4000) =
(
    SELECT ConfigValue FROM admin.Configuration WHERE ConfigKey = N'BackupPath'
);
DECLARE @CertPassword nvarchar(128) =
(
    SELECT ConfigValue FROM admin.Configuration WHERE ConfigKey = N'CertificateExportPassword'
);
DECLARE @CertFile nvarchar(4000) = @BackupPath + N'SmartBankBackupCertificate.cer';
DECLARE @PrivateKeyFile nvarchar(4000) = @BackupPath + N'SmartBankBackupCertificate_PrivateKey.pvk';
DECLARE @CertExists int;
DECLARE @KeyExists int;
DECLARE @FileCheck TABLE (FileExists int, FileIsDirectory int, ParentDirectoryExists int);

INSERT @FileCheck EXEC master.dbo.xp_fileexist @CertFile;
SELECT @CertExists = FileExists FROM @FileCheck;
DELETE FROM @FileCheck;
INSERT @FileCheck EXEC master.dbo.xp_fileexist @PrivateKeyFile;
SELECT @KeyExists = FileExists FROM @FileCheck;

IF COALESCE(@CertExists, 0) = 0 OR COALESCE(@KeyExists, 0) = 0
BEGIN
    DECLARE @ExportSql nvarchar(max) =
        N'USE master;
          BACKUP CERTIFICATE SmartBankBackupCertificate
          TO FILE = N''' + REPLACE(@CertFile, '''', '''''') + N'''
          WITH PRIVATE KEY
          (
              FILE = N''' + REPLACE(@PrivateKeyFile, '''', '''''') + N''',
              ENCRYPTION BY PASSWORD = ''' + REPLACE(@CertPassword, '''', '''''') + N'''
          );';
    EXEC sys.sp_executesql @ExportSql;
END;

SELECT @CertFile AS CertificateFile, @PrivateKeyFile AS PrivateKeyFile;
GO

/* -------------------------------------------------------------------------
   3. Initial full backup establishes the log chain
   ------------------------------------------------------------------------- */
EXEC admin.usp_RunBackup @BackupType = 'FULL', @JobName = N'Manual initial full backup';
EXEC admin.usp_RunBackup @BackupType = 'LOG', @JobName = N'Manual initial log backup';
GO

/* -------------------------------------------------------------------------
   4. SQL Server Agent jobs and schedules
   ------------------------------------------------------------------------- */
USE msdb;
GO
SET NOCOUNT ON;
GO

DECLARE @CurrentOwner sysname = SUSER_SNAME();

IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Full Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Full Backup', @delete_unused_schedule = 1;
IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Differential Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Differential Backup', @delete_unused_schedule = 1;
IF EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = N'SmartBank - Transaction Log Backup')
    EXEC dbo.sp_delete_job @job_name = N'SmartBank - Transaction Log Backup', @delete_unused_schedule = 1;

IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Daily Full 0100')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Daily Full 0100';
IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Diff Every 6 Hours')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Diff Every 6 Hours';
IF EXISTS (SELECT 1 FROM dbo.sysschedules WHERE name = N'SmartBank Log Every 15 Minutes')
    EXEC dbo.sp_delete_schedule @schedule_name = N'SmartBank Log Every 15 Minutes';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Full Backup',
    @enabled = 1,
    @description = N'Daily AES-256 encrypted full backup with CHECKSUM, COMPRESSION and VERIFYONLY.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Full Backup',
    @step_name = N'Run encrypted full backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''FULL'', @JobName = N''SmartBank - Full Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Daily Full 0100',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @active_start_time = 010000;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Full Backup',
    @schedule_name = N'SmartBank Daily Full 0100';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Full Backup';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Differential Backup',
    @enabled = 1,
    @description = N'AES-256 encrypted differential backup every six hours.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Differential Backup',
    @step_name = N'Run encrypted differential backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''DIFFERENTIAL'', @JobName = N''SmartBank - Differential Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Diff Every 6 Hours',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 8,
    @freq_subday_interval = 6,
    @active_start_time = 070000,
    @active_end_time = 235959;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Differential Backup',
    @schedule_name = N'SmartBank Diff Every 6 Hours';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Differential Backup';

EXEC dbo.sp_add_job
    @job_name = N'SmartBank - Transaction Log Backup',
    @enabled = 1,
    @description = N'AES-256 encrypted transaction-log backup every 15 minutes to meet the RPO.',
    @owner_login_name = @CurrentOwner;
EXEC dbo.sp_add_jobstep
    @job_name = N'SmartBank - Transaction Log Backup',
    @step_name = N'Run encrypted log backup',
    @subsystem = N'TSQL',
    @database_name = N'SmartBankDB',
    @command = N'EXEC admin.usp_RunBackup @BackupType = ''LOG'', @JobName = N''SmartBank - Transaction Log Backup'';',
    @on_success_action = 1,
    @on_fail_action = 2;
EXEC dbo.sp_add_schedule
    @schedule_name = N'SmartBank Log Every 15 Minutes',
    @enabled = 1,
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 4,
    @freq_subday_interval = 15,
    @active_start_time = 000000,
    @active_end_time = 235959;
EXEC dbo.sp_attach_schedule
    @job_name = N'SmartBank - Transaction Log Backup',
    @schedule_name = N'SmartBank Log Every 15 Minutes';
EXEC dbo.sp_add_jobserver @job_name = N'SmartBank - Transaction Log Backup';
GO

/* -------------------------------------------------------------------------
   5. Three-day readiness/evidence procedure
   ------------------------------------------------------------------------- */
USE SmartBankDB;
GO

CREATE OR ALTER PROCEDURE admin.usp_BackupReadinessReport
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        servicename,
        status_desc,
        startup_type_desc,
        last_startup_time,
        service_account
    FROM sys.dm_server_services
    WHERE servicename LIKE N'SQL Server Agent%'
       OR servicename LIKE N'SQL Server (%';

    SELECT
        j.name AS JobName,
        j.enabled,
        CASE h.run_status
            WHEN 0 THEN 'Failed'
            WHEN 1 THEN 'Succeeded'
            WHEN 2 THEN 'Retry'
            WHEN 3 THEN 'Cancelled'
            WHEN 4 THEN 'In Progress'
            ELSE 'No history'
        END AS LastOutcome,
        msdb.dbo.agent_datetime(h.run_date, h.run_time) AS LastRunDateTime,
        h.message AS LastMessage
    FROM msdb.dbo.sysjobs AS j
    OUTER APPLY
    (
        SELECT TOP (1) run_status, run_date, run_time, message
        FROM msdb.dbo.sysjobhistory AS h2
        WHERE h2.job_id = j.job_id
          AND h2.step_id = 0
        ORDER BY h2.instance_id DESC
    ) AS h
    WHERE j.name LIKE N'SmartBank - % Backup'
    ORDER BY j.name;

    ;WITH LastThreeDays AS
    (
        SELECT CAST(DATEADD(day, -2, GETDATE()) AS date) AS BackupDate
        UNION ALL SELECT CAST(DATEADD(day, -1, GETDATE()) AS date)
        UNION ALL SELECT CAST(GETDATE() AS date)
    ),
    BackupCounts AS
    (
        SELECT
            CAST(backup_finish_date AS date) AS BackupDate,
            SUM(CASE WHEN type = 'D' THEN 1 ELSE 0 END) AS FullBackups,
            SUM(CASE WHEN type = 'I' THEN 1 ELSE 0 END) AS DifferentialBackups,
            SUM(CASE WHEN type = 'L' THEN 1 ELSE 0 END) AS LogBackups,
            SUM(CASE WHEN key_algorithm = 'AES_256' THEN 1 ELSE 0 END) AS AES256Backups
        FROM msdb.dbo.backupset
        WHERE database_name = N'SmartBankDB'
          AND backup_finish_date >= DATEADD(day, -3, CAST(GETDATE() AS date))
        GROUP BY CAST(backup_finish_date AS date)
    )
    SELECT
        d.BackupDate,
        COALESCE(b.FullBackups, 0) AS FullBackups,
        COALESCE(b.DifferentialBackups, 0) AS DifferentialBackups,
        COALESCE(b.LogBackups, 0) AS LogBackups,
        COALESCE(b.AES256Backups, 0) AS AES256Backups,
        CASE
            WHEN COALESCE(b.FullBackups, 0) >= 1
             AND COALESCE(b.DifferentialBackups, 0) >= 1
             AND COALESCE(b.LogBackups, 0) >= 1
             AND COALESCE(b.AES256Backups, 0) >= 3
            THEN 'PASS'
            ELSE 'NOT READY'
        END AS DailyReadiness
    FROM LastThreeDays AS d
    LEFT JOIN BackupCounts AS b
        ON b.BackupDate = d.BackupDate
    ORDER BY d.BackupDate;

    SELECT TOP (200)
        BackupEvidenceID,
        BackupStartUtc,
        BackupFinishUtc,
        BackupType,
        BackupFile,
        Encrypted,
        VerifyOnlyPassed,
        Success,
        ErrorMessage,
        SqlAgentJobName
    FROM audit.BackupEvidence
    ORDER BY BackupEvidenceID DESC;

    SELECT TOP (200)
        bs.backup_set_id,
        bs.database_name,
        CASE bs.type WHEN 'D' THEN 'FULL' WHEN 'I' THEN 'DIFFERENTIAL' WHEN 'L' THEN 'LOG' END AS BackupType,
        bs.backup_start_date,
        bs.backup_finish_date,
        bs.is_copy_only,
        bs.has_backup_checksums,
        bms.is_compressed,
        bms.is_encrypted,
        bs.key_algorithm,
        bs.encryptor_type,
        CONVERT(decimal(12,2), bs.backup_size / 1048576.0) AS BackupSizeMB,
        CONVERT(decimal(12,2), bs.compressed_backup_size / 1048576.0) AS CompressedBackupSizeMB,
        bmf.physical_device_name
    FROM msdb.dbo.backupset AS bs
    INNER JOIN msdb.dbo.backupmediafamily AS bmf
        ON bmf.media_set_id = bs.media_set_id
    INNER JOIN msdb.dbo.backupmediaset AS bms
        ON bms.media_set_id = bs.media_set_id
    WHERE bs.database_name = N'SmartBankDB'
    ORDER BY bs.backup_finish_date DESC;
END;
GO

EXEC admin.usp_BackupReadinessReport;
GO

PRINT '08 encrypted backup automation completed. Keep SQL Server and SQL Server Agent running for at least three consecutive days before the demo.';
GO
