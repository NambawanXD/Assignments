/*
SmartBankDB - Optional destructive reset
Run this script only when you want a clean reinstall.
Requires sysadmin privileges.
*/
USE master;
GO

SET NOCOUNT ON;
GO

DECLARE @JobName sysname;
DECLARE job_cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT name
FROM msdb.dbo.sysjobs
WHERE name IN
(
    N'SmartBank - Full Backup',
    N'SmartBank - Differential Backup',
    N'SmartBank - Transaction Log Backup'
);

OPEN job_cursor;
FETCH NEXT FROM job_cursor INTO @JobName;
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC msdb.dbo.sp_delete_job @job_name = @JobName, @delete_unused_schedule = 1;
    FETCH NEXT FROM job_cursor INTO @JobName;
END;
CLOSE job_cursor;
DEALLOCATE job_cursor;
GO

IF EXISTS (SELECT 1 FROM sys.server_audit_specifications WHERE name = N'SmartBank_ServerAuditSpec')
BEGIN
    ALTER SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec WITH (STATE = OFF);
    DROP SERVER AUDIT SPECIFICATION SmartBank_ServerAuditSpec;
END;
GO

IF EXISTS (SELECT 1 FROM sys.server_audits WHERE name = N'SmartBank_ServerAudit')
BEGIN
    ALTER SERVER AUDIT SmartBank_ServerAudit WITH (STATE = OFF);
    DROP SERVER AUDIT SmartBank_ServerAudit;
END;
GO

IF DB_ID(N'SmartBankDB_PITR') IS NOT NULL
BEGIN
    ALTER DATABASE SmartBankDB_PITR SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE SmartBankDB_PITR;
END;
GO

IF DB_ID(N'SmartBankDB_Restored') IS NOT NULL
BEGIN
    ALTER DATABASE SmartBankDB_Restored SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE SmartBankDB_Restored;
END;
GO

IF DB_ID(N'SmartBankDB') IS NOT NULL
BEGIN
    ALTER DATABASE SmartBankDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE SmartBankDB;
END;
GO

DECLARE @LoginName sysname;
DECLARE login_cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT name
FROM sys.server_principals
WHERE name IN
(
    N'SB_DBA01',
    N'SB_MANAGER01',
    N'SB_OFFICER01',
    N'SB_OFFICER02',
    N'SB_CUSTOMER01',
    N'SB_CUSTOMER02',
    N'SB_CUSTOMER03',
    N'SB_AUDITOR01'
);

OPEN login_cursor;
FETCH NEXT FROM login_cursor INTO @LoginName;
WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC (N'DROP LOGIN ' + QUOTENAME(@LoginName) + N';');
    FETCH NEXT FROM login_cursor INTO @LoginName;
END;
CLOSE login_cursor;
DEALLOCATE login_cursor;
GO

PRINT 'SmartBank demo environment reset completed.';
GO
