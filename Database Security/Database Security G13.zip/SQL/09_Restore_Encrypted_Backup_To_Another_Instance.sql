/*
SmartBankDB - Restore an AES-256 encrypted backup on another SQL Server instance

SOURCE INSTANCE REQUIREMENTS
- Run 08_Encrypted_Backup_Automation_and_Readiness.sql first.
- Copy these three files to a folder readable by the DESTINATION SQL Server service:
    1. A SmartBankDB_FULL_*.bak file
    2. SmartBankBackupCertificate.cer
    3. SmartBankBackupCertificate_PrivateKey.pvk

DESTINATION INSTANCE REQUIREMENTS
- Run this script as sysadmin on the second SQL Server instance.
- Change @TransferFolder and @FullBackupFile before executing.
- The script restores as SmartBankDB_Restored so the active database is untouched.
*/
USE master;
GO
SET NOCOUNT ON;
GO

/* ========================== EDIT THESE VALUES ========================== */
DECLARE @TransferFolder nvarchar(4000) = N'C:\SmartBankTransfer\';
DECLARE @FullBackupFile nvarchar(4000) = N'C:\SmartBankTransfer\SmartBankDB_FULL_YYYYMMDD_HHMMSS.bak';
DECLARE @RestoreDatabase sysname = N'SmartBankDB_Restored';
DECLARE @BackupCertificatePassword nvarchar(128) = N'BackupCert#SmartBank2026!';
DECLARE @DatabaseMasterKeyPassword nvarchar(128) = N'DbMasterKey#SmartBank2026!';
/* ===================================================================== */

IF RIGHT(@TransferFolder, 1) <> N'\' SET @TransferFolder += N'\';

DECLARE @CertificateFile nvarchar(4000) = @TransferFolder + N'SmartBankBackupCertificate.cer';
DECLARE @PrivateKeyFile nvarchar(4000) = @TransferFolder + N'SmartBankBackupCertificate_PrivateKey.pvk';
DECLARE @FileCheck TABLE (FileExists int, FileIsDirectory int, ParentDirectoryExists int);
DECLARE @Exists int;

INSERT @FileCheck EXEC master.dbo.xp_fileexist @FullBackupFile;
SELECT @Exists = FileExists FROM @FileCheck;
IF COALESCE(@Exists, 0) = 0
    THROW 51601, 'The encrypted full backup file does not exist or is not readable by the SQL Server service account.', 1;

DELETE FROM @FileCheck;
INSERT @FileCheck EXEC master.dbo.xp_fileexist @CertificateFile;
SELECT @Exists = FileExists FROM @FileCheck;
IF COALESCE(@Exists, 0) = 0
    THROW 51602, 'The backup certificate file does not exist or is not readable.', 1;

DELETE FROM @FileCheck;
INSERT @FileCheck EXEC master.dbo.xp_fileexist @PrivateKeyFile;
SELECT @Exists = FileExists FROM @FileCheck;
IF COALESCE(@Exists, 0) = 0
    THROW 51603, 'The backup certificate private-key file does not exist or is not readable.', 1;

/* The destination master database must have a database master key. */
IF NOT EXISTS (SELECT 1 FROM master.sys.symmetric_keys WHERE name = N'##MS_DatabaseMasterKey##')
BEGIN
    DECLARE @CreateMasterKeySql nvarchar(max) =
        N'CREATE MASTER KEY ENCRYPTION BY PASSWORD = N''MasterKey#SmartBankDestination2026!'';';
    EXEC sys.sp_executesql @CreateMasterKeySql;
END;

/* Import the certificate used to encrypt the backup. */
IF NOT EXISTS (SELECT 1 FROM master.sys.certificates WHERE name = N'SmartBankBackupCertificate')
BEGIN
    DECLARE @CreateCertificateSql nvarchar(max) =
        N'CREATE CERTIFICATE SmartBankBackupCertificate
          FROM FILE = N''' + REPLACE(@CertificateFile, '''', '''''') + N'''
          WITH PRIVATE KEY
          (
              FILE = N''' + REPLACE(@PrivateKeyFile, '''', '''''') + N''',
              DECRYPTION BY PASSWORD = N''' + REPLACE(@BackupCertificatePassword, '''', '''''') + N'''
          );';
    EXEC sys.sp_executesql @CreateCertificateSql;
END;

/* Inspect the encrypted backup before restore. */
DECLARE @HeaderSql nvarchar(max) =
    N'RESTORE HEADERONLY FROM DISK = N''' + REPLACE(@FullBackupFile, '''', '''''') + N''';';
EXEC sys.sp_executesql @HeaderSql;

/* Show logical files for evidence. The database is created by this pack, so its
   stable logical names are SmartBankDB and SmartBankDB_log. */
DECLARE @FileListSql nvarchar(max) =
    N'RESTORE FILELISTONLY FROM DISK = N''' + REPLACE(@FullBackupFile, '''', '''''') + N''';';
EXEC sys.sp_executesql @FileListSql;

DECLARE @DataLogicalName sysname = N'SmartBankDB';
DECLARE @LogLogicalName sysname  = N'SmartBankDB_log';
DECLARE @DefaultDataPath nvarchar(4000) = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultDataPath'));
DECLARE @DefaultLogPath nvarchar(4000)  = CONVERT(nvarchar(4000), SERVERPROPERTY('InstanceDefaultLogPath'));

IF @DefaultDataPath IS NULL
BEGIN
    SELECT TOP (1) @DefaultDataPath = LEFT(physical_name, LEN(physical_name) - CHARINDEX(N'\', REVERSE(physical_name)) + 1)
    FROM master.sys.master_files WHERE database_id = 1 AND file_id = 1;
END;
IF @DefaultLogPath IS NULL SET @DefaultLogPath = @DefaultDataPath;
IF RIGHT(@DefaultDataPath, 1) <> N'\' SET @DefaultDataPath += N'\';
IF RIGHT(@DefaultLogPath, 1) <> N'\' SET @DefaultLogPath += N'\';

IF DB_ID(@RestoreDatabase) IS NOT NULL
BEGIN
    DECLARE @DropSql nvarchar(max) =
        N'ALTER DATABASE ' + QUOTENAME(@RestoreDatabase) + N' SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
          DROP DATABASE ' + QUOTENAME(@RestoreDatabase) + N';';
    EXEC sys.sp_executesql @DropSql;
END;

DECLARE @DataFile nvarchar(4000) = @DefaultDataPath + @RestoreDatabase + N'.mdf';
DECLARE @LogFile nvarchar(4000)  = @DefaultLogPath + @RestoreDatabase + N'_log.ldf';
DECLARE @RestoreSql nvarchar(max) =
    N'RESTORE DATABASE ' + QUOTENAME(@RestoreDatabase) + N'
      FROM DISK = N''' + REPLACE(@FullBackupFile, '''', '''''') + N'''
      WITH MOVE N''' + REPLACE(@DataLogicalName, '''', '''''') + N''' TO N''' + REPLACE(@DataFile, '''', '''''') + N''',
           MOVE N''' + REPLACE(@LogLogicalName, '''', '''''') + N''' TO N''' + REPLACE(@LogFile, '''', '''''') + N''',
           RECOVERY, CHECKSUM, STATS = 5;';
EXEC sys.sp_executesql @RestoreSql;

/*
The database master key was copied with the restored database. Add encryption by
this destination instance's Service Master Key so authorised procedures can open
the column key automatically after migration.
*/
DECLARE @OpenAndBindMasterKeySql nvarchar(max) =
    N'USE ' + QUOTENAME(@RestoreDatabase) + N';
      OPEN MASTER KEY DECRYPTION BY PASSWORD = N''' + REPLACE(@DatabaseMasterKeyPassword, '''', '''''') + N''';
      ALTER MASTER KEY ADD ENCRYPTION BY SERVICE MASTER KEY;
      CLOSE MASTER KEY;';
EXEC sys.sp_executesql @OpenAndBindMasterKeySql;

/* Create/remap one demo login on the destination to prove normal user access. */
IF SUSER_ID(N'SB_CUSTOMER01') IS NULL
BEGIN
    CREATE LOGIN SB_CUSTOMER01
        WITH PASSWORD = 'Cust1#SmartBank2026!',
             CHECK_POLICY = ON,
             CHECK_EXPIRATION = OFF,
             DEFAULT_DATABASE = master;
END;

DECLARE @RemapSql nvarchar(max) =
    N'USE ' + QUOTENAME(@RestoreDatabase) + N';
      IF USER_ID(N''SB_CUSTOMER01'') IS NOT NULL
          ALTER USER SB_CUSTOMER01 WITH LOGIN = SB_CUSTOMER01;
      SELECT DB_NAME() AS RestoredDatabase,
             COUNT_BIG(*) AS CustomerRows
      FROM bank.Customer;
      DBCC CHECKDB (' + QUOTENAME(@RestoreDatabase, '''') + N') WITH NO_INFOMSGS;
      SELECT name, state_desc, recovery_model_desc, page_verify_option_desc
      FROM sys.databases WHERE name = N''' + REPLACE(@RestoreDatabase, '''', '''''') + N''';';
EXEC sys.sp_executesql @RemapSql;

PRINT 'Encrypted backup restore completed. Open a NEW SSMS connection using SB_CUSTOMER01 and run:';
PRINT 'USE ' + @RestoreDatabase + '; EXEC api.usp_GetMyCustomerProfile;';
PRINT 'This proves the restored database is readable and authorised column-level decryption still works.';
GO
