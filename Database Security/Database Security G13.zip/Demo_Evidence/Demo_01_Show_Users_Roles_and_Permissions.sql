/* Run as sysadmin. This is the first permissions screen for the lecturer. */
USE SmartBankDB;
GO

PRINT 'A. SQL logins and policy settings';
SELECT
    sp.name AS LoginName,
    sp.type_desc AS LoginType,
    sp.is_disabled,
    sl.is_policy_checked,
    sl.is_expiration_checked,
    sp.default_database_name,
    LOGINPROPERTY(sp.name, 'PasswordLastSetTime') AS PasswordLastSetTime
FROM sys.server_principals AS sp
LEFT JOIN sys.sql_logins AS sl
    ON sl.principal_id = sp.principal_id
WHERE sp.name LIKE N'SB[_]%'
ORDER BY sp.name;
GO

PRINT 'B. Database users and role membership';
SELECT *
FROM sec.vw_RoleUserMapping
ORDER BY RoleName, UserName;
GO

PRINT 'C. Explicit role permissions - GRANT and DENY';
SELECT *
FROM sec.vw_ExplicitRolePermissions
ORDER BY RoleName, PermissionState, SecurableName, PermissionName;
GO

PRINT 'D. Designed authorization matrix';
SELECT *
FROM sec.AuthorizationMatrix
ORDER BY RoleName, MatrixID;
GO

PRINT 'E. RLS policy and predicate definitions';
SELECT
    policy.name AS SecurityPolicy,
    policy.is_enabled,
    predicate.predicate_type_desc,
    OBJECT_SCHEMA_NAME(predicate.target_object_id) AS TargetSchema,
    OBJECT_NAME(predicate.target_object_id) AS TargetTable,
    predicate.predicate_definition
FROM sys.security_policies AS policy
INNER JOIN sys.security_predicates AS predicate
    ON predicate.object_id = policy.object_id
ORDER BY policy.name, predicate.predicate_type_desc;
GO

PRINT 'F. Dynamic masking configuration';
SELECT
    OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
    OBJECT_NAME(object_id) AS TableName,
    name AS ColumnName,
    masking_function
FROM sys.masked_columns
WHERE is_masked = 1;
GO

PRINT 'G. Data classifications';
SELECT
    OBJECT_SCHEMA_NAME(sc.major_id) AS SchemaName,
    OBJECT_NAME(sc.major_id) AS TableName,
    COL_NAME(sc.major_id, sc.minor_id) AS ColumnName,
    sc.label,
    sc.information_type,
    sc.rank_desc
FROM sys.sensitivity_classifications AS sc
ORDER BY SchemaName, TableName, ColumnName;
GO
