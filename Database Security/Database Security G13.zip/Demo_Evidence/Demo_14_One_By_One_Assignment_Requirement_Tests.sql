/*
MASTER DEMO INDEX - RUN EACH USER-SPECIFIC section in a separate connection
using the named SQL login. This file lists the expected proof one requirement
at a time; the detailed scripts Demo_02 through Demo_06 contain the commands.
*/

/* Requirement C1: Every user is authenticated. Run as sysadmin. */
USE master;
SELECT name, type_desc, is_disabled
FROM sys.server_principals
WHERE name LIKE N'SB[_]%'
ORDER BY name;
GO

/* Requirement C2: Every authenticated user can see staff name/contact.
   Run this in each SB_* business-user connection. */
/* USE SmartBankDB; SELECT * FROM sec.vw_PublicStaffDirectory; */

/* Requirement C3: Manager sees own + officers, all accounts and transactions.
   Run as SB_MANAGER01. */
/*
USE SmartBankDB;
SELECT * FROM sec.vw_StaffBasicAccess;
SELECT * FROM sec.vw_AccountAccess;
SELECT * FROM sec.vw_TransactionAccess;
*/

/* Requirement C4: Officer sees only own staff record + all accounts/transactions.
   Run as SB_OFFICER01. */
/*
USE SmartBankDB;
SELECT * FROM sec.vw_StaffBasicAccess;
SELECT * FROM sec.vw_AccountAccess;
SELECT * FROM sec.vw_TransactionAccess;
*/

/* Requirement C5: DBA sees only own staff record and cannot read customer data.
   Run as SB_DBA01. */
/*
USE SmartBankDB;
SELECT * FROM sec.vw_StaffBasicAccess;
BEGIN TRY SELECT * FROM sec.vw_AccountAccess; END TRY
BEGIN CATCH SELECT ERROR_MESSAGE() AS ExpectedDenial; END CATCH;
*/

/* Requirement C6: Customer sees only own accounts/transactions with decrypted profile.
   Run separately as SB_CUSTOMER01 and SB_CUSTOMER02. */
/*
USE SmartBankDB;
EXEC api.usp_GetMyCustomerProfile;
SELECT * FROM sec.vw_AccountAccess;
SELECT * FROM sec.vw_TransactionAccess;
*/

/* Integrity I1: DBA can manage tables but cannot manipulate data - Demo_02. */
/* Integrity I2: Manager manages staff - Demo_03. */
/* Integrity I3: Officer manages customer/account records - Demo_04. */
/* Integrity I4: staff self-update except salary - execute api.usp_Staff_UpdateOwnRecord.
   No salary parameter exists, and direct StaffPrivate UPDATE is denied. */
/* Integrity I5: only customers perform deposit/withdraw/transfer - Demo_05. */
/* Integrity I6: valid and invalid actions are audited - Demo_08 and Demo_11. */

/* Availability: Demo_10 (3-day jobs), Demo_13 (encrypted restore), Demo_12 (PITR). */
