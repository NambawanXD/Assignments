/* Connect a NEW SSMS window using SQL Authentication:
   Login: SB_OFFICER01
   Password: Off1#SmartBank2026!
*/
USE SmartBankDB;
GO

SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser;
SELECT * FROM sec.vw_PublicStaffDirectory;
SELECT * FROM sec.vw_StaffBasicAccess;
EXEC api.usp_GetMyStaffRecord;
SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT * FROM sec.vw_TransactionAccess ORDER BY TransID;

PRINT 'DDM proof: Bank Officer has UNMASK for operational customer servicing.';
SELECT * FROM sec.vw_CustomerContact ORDER BY CustomerID;

PRINT 'Create an additional test customer and zero-balance account if absent.';
IF NOT EXISTS (SELECT 1 FROM sec.vw_CustomerContact WHERE CustomerID = 'CU0099')
BEGIN
    EXEC api.usp_Officer_CreateCustomer
        @CustomerID = 'CU0099',
        @CustomerName = N'Demo Customer',
        @Email = 'demo.customer@example.com',
        @Phone = '019-0000099',
        @DateOfBirth = '1999-09-09',
        @ICNumber = N'990909-10-9999',
        @Address = N'Demo Address, Kuala Lumpur';
END;

IF NOT EXISTS (SELECT 1 FROM sec.vw_AccountAccess WHERE AccountID = 'AC00000099')
BEGIN
    EXEC api.usp_Officer_CreateAccount
        @AccountID = 'AC00000099',
        @CustomerID = 'CU0099',
        @AccountType = 'Savings';
END;

SELECT * FROM sec.vw_AccountAccess WHERE AccountID = 'AC00000099';

PRINT 'Expected failure: Officer cannot directly change account balance.';
BEGIN TRY
    UPDATE bank.Account SET Balance = 999999 WHERE AccountID = 'AC00000099';
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;
GO
