/* Run as a Windows-authenticated sysadmin for technical evidence.
   This script intentionally reads protected base tables and refreshes the static masked copy. */
USE SmartBankDB;
GO

IF IS_SRVROLEMEMBER(N'sysadmin') <> 1
    THROW 52090, 'Demo 07 must be run from a Windows/sysadmin connection. Do not grant business roles direct SELECT just to run this evidence script.', 1;
GO

PRINT 'A. Ciphertext is stored, not salary/IC/address plaintext.';
SELECT StaffID, SalaryCipher, DATALENGTH(SalaryCipher) AS CipherBytes
FROM bank.StaffPrivate;
SELECT CustomerID, ICNumberCipher, AddressCipher, ICNumberHash, HashSalt
FROM bank.Customer;

PRINT 'B. Hashes are fixed-length and not reversible.';
SELECT CustomerID, DATALENGTH(ICNumberHash) AS SHA256Bytes, CONVERT(varchar(64), ICNumberHash, 2) AS ICNumberHashHex
FROM bank.Customer;

PRINT 'C. Static masked and anonymised analytical copy.';
EXEC reporting.usp_RefreshCustomerAnalyticsMasked;
SELECT * FROM reporting.CustomerAnalyticsMasked ORDER BY CustomerAlias;

PRINT 'D. Dynamic masking metadata.';
SELECT OBJECT_SCHEMA_NAME(object_id) AS SchemaName,
       OBJECT_NAME(object_id) AS TableName,
       name AS ColumnName,
       masking_function
FROM sys.masked_columns
WHERE is_masked = 1;
GO
