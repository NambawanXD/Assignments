/* Run as sysadmin, or custom tables may be read as SB_AUDITOR01. */
USE SmartBankDB;
GO

PRINT 'A. Valid and invalid business actions';
SELECT TOP (200) *
FROM audit.vw_RecentBusinessActions
ORDER BY EventTimeUtc DESC, AuditID DESC;

PRINT 'B. Successful DML with old/new JSON';
SELECT TOP (200) *
FROM audit.vw_RecentDMLChanges
ORDER BY EventTimeUtc DESC, ChangeAuditID DESC;

PRINT 'C. DDL and permission changes';
SELECT TOP (200) *
FROM audit.vw_RecentDDLAndPermissionChanges
ORDER BY EventTimeUtc DESC, DDLAuditID DESC;

PRINT 'D. Login, logout, failed login, SELECT, denied DML and permission changes from SQL Server Audit';
EXEC audit.usp_ReadSqlServerAudit @TopRows = 1000, @LoginName = NULL, @DatabaseName = NULL;
GO
