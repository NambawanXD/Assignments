# Remaining / Optional Evidence Screenshots

Most required evidence is already present in the user's Database.zip. Add the following only if the final report still shows a placeholder:

1. **Final post-installation validation** - run `SQL/12_Post_Installation_Validation.sql` as Windows/sysadmin and capture the final results/messages showing no red runtime errors.
2. **Post-PITR audit evidence** - after recovering the deleted transaction, run the DML audit query filtered to that `TransID` and capture both the `DELETE` and recovery `INSERT` rows in the same screenshot.
3. **Optional restored DBCC CHECKDB evidence** - on `SMARTBANKRESTORE`, run `DBCC CHECKDB (N'SmartBankDB_Restored') WITH NO_INFOMSGS;` and capture the completion message if your lecturer wants explicit integrity proof.

Do not fabricate timestamps or backup history. Use actual server-generated evidence.
