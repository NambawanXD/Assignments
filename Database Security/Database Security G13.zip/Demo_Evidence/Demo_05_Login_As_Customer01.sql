/* Connect a NEW SSMS window using SQL Authentication:
   Login: SB_CUSTOMER01
   Password: Cust1#SmartBank2026!
*/
USE SmartBankDB;
GO

SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser;
SELECT * FROM sec.vw_PublicStaffDirectory;

PRINT 'Encrypted values decrypt automatically inside the authorised procedure.';
EXEC api.usp_GetMyCustomerProfile;

PRINT 'RLS proof: Customer 1 receives only CU0001 accounts and transactions.';
SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT * FROM sec.vw_TransactionAccess ORDER BY TransID;

PRINT 'RLS negative proof: another customer account is not returned.';
SELECT * FROM sec.vw_AccountAccess WHERE AccountID = 'AC00000003';

PRINT 'Valid customer-only transactions.';
EXEC api.usp_Customer_Deposit
    @AccountID = 'AC00000001',
    @Amount = 50.00,
    @Remarks = N'Demo deposit',
    @IdempotencyKey = NULL;

EXEC api.usp_Customer_Withdraw
    @AccountID = 'AC00000001',
    @Amount = 10.00,
    @Remarks = N'Demo withdrawal',
    @IdempotencyKey = NULL;

EXEC api.usp_Customer_Transfer
    @FromAccountID = 'AC00000001',
    @ToAccountID = 'AC00000003',
    @Amount = 5.00,
    @Remarks = N'Demo transfer',
    @IdempotencyKey = NULL;

SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT TOP (20) * FROM sec.vw_TransactionAccess ORDER BY TransID DESC;

PRINT 'Expected business failure and audit: insufficient funds.';
BEGIN TRY
    EXEC api.usp_Customer_Withdraw
        @AccountID = 'AC00000001',
        @Amount = 999999.00,
        @Remarks = N'Invalid demo withdrawal',
        @IdempotencyKey = NULL;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;

PRINT 'Expected permission failure and SQL Server Audit evidence: direct UPDATE.';
BEGIN TRY
    UPDATE bank.Account SET Balance = 1 WHERE AccountID = 'AC00000001';
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;
GO
