/*
SECOND-INSTANCE ENCRYPTED BACKUP RESTORE CHECKLIST

1. On the source instance, choose a recent FULL .bak shown by Demo_10.
2. Copy it together with:
   - SmartBankBackupCertificate.cer
   - SmartBankBackupCertificate_PrivateKey.pvk
3. Put all three in C:\SmartBankTransfer\ on the destination computer/instance.
4. Ensure the destination SQL Server service account can read that folder.
5. On the destination instance, edit and run:
   SQL\09_Restore_Encrypted_Backup_To_Another_Instance.sql
6. Connect as SB_CUSTOMER01 to the destination instance and run the proof below.
*/

USE SmartBankDB_Restored;
GO
SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser, DB_NAME() AS DatabaseName;
EXEC api.usp_GetMyCustomerProfile;
SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT TOP (20) * FROM sec.vw_TransactionAccess ORDER BY TransID DESC;
GO

/* Run this part as destination sysadmin for integrity evidence. */
/*
DBCC CHECKDB (SmartBankDB_Restored) WITH NO_INFOMSGS;
SELECT name, state_desc, recovery_model_desc, page_verify_option_desc
FROM sys.databases WHERE name = N'SmartBankDB_Restored';
*/
