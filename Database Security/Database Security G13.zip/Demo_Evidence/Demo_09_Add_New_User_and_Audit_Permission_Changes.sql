/*
Run the staff-record creation first while connected as SB_MANAGER01:

EXEC SmartBankDB.api.usp_Manager_CreateBankOfficer
    @StaffID = 'ST0005',
    @StaffName = N'New Demo Officer',
    @Branch = N'Klang Valley Demo Branch',
    @Phone = '03-21001005',
    @Salary = 5000.00;

Then run the remainder below as sysadmin. It demonstrates adding a login/user,
role membership, an explicit permission change, and audit capture.
*/
USE master;
GO
IF SUSER_ID(N'SB_OFFICER03') IS NULL
    CREATE LOGIN SB_OFFICER03
    WITH PASSWORD = 'Off3#SmartBank2026!', CHECK_POLICY = ON, CHECK_EXPIRATION = OFF, DEFAULT_DATABASE = SmartBankDB;
GO

USE SmartBankDB;
GO
IF DATABASE_PRINCIPAL_ID(N'SB_OFFICER03') IS NULL
    CREATE USER SB_OFFICER03 FOR LOGIN SB_OFFICER03;
GO

ALTER ROLE role_bank_officer ADD MEMBER SB_OFFICER03;
GO

IF EXISTS (SELECT 1 FROM bank.Staff WHERE StaffID = 'ST0005')
BEGIN
    MERGE sec.LoginIdentityMap AS target
    USING
    (
        SELECT N'SB_OFFICER03' AS DatabaseUserName,
               N'SB_OFFICER03' AS LoginName,
               'BANK_OFFICER' AS RoleCode,
               'ST0005' AS StaffID,
               CAST(NULL AS char(6)) AS CustomerID
    ) AS source
    ON target.DatabaseUserName = source.DatabaseUserName
    WHEN MATCHED THEN
        UPDATE SET LoginName = source.LoginName, RoleCode = source.RoleCode,
                   StaffID = source.StaffID, CustomerID = NULL, IsActive = 1
    WHEN NOT MATCHED THEN
        INSERT (DatabaseUserName, LoginName, RoleCode, StaffID, CustomerID)
        VALUES (source.DatabaseUserName, source.LoginName, source.RoleCode, source.StaffID, source.CustomerID);
END;
GO

/* Temporary permission change for demonstration, followed by REVOKE. */
GRANT SELECT ON OBJECT::reporting.CustomerAnalyticsMasked TO role_bank_officer;
REVOKE SELECT ON OBJECT::reporting.CustomerAnalyticsMasked FROM role_bank_officer;
GO

SELECT * FROM sec.vw_RoleUserMapping WHERE UserName = N'SB_OFFICER03';
SELECT TOP (100) *
FROM audit.vw_RecentDDLAndPermissionChanges
WHERE TSQLCommand LIKE N'%SB_OFFICER03%'
   OR TSQLCommand LIKE N'%CustomerAnalyticsMasked%'
ORDER BY EventTimeUtc DESC;

EXEC audit.usp_ReadSqlServerAudit @TopRows = 300, @LoginName = NULL, @DatabaseName = NULL;
GO
