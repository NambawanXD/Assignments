/* Run as sysadmin after SQL Server Agent has run for three consecutive days. */
USE SmartBankDB;
GO
EXEC admin.usp_BackupReadinessReport;
GO

/* Focused three-day evidence from msdb. */
SELECT
    CAST(bs.backup_finish_date AS date) AS BackupDate,
    CASE bs.type WHEN 'D' THEN 'FULL' WHEN 'I' THEN 'DIFFERENTIAL' WHEN 'L' THEN 'LOG' END AS BackupType,
    COUNT(*) AS SuccessfulBackupCount,
    MIN(bs.backup_finish_date) AS FirstBackup,
    MAX(bs.backup_finish_date) AS LastBackup,
    MIN(bs.key_algorithm) AS EncryptionAlgorithm,
    MIN(CONVERT(int, bs.has_backup_checksums)) AS AllUseChecksums,
    MIN(CONVERT(int, bs.is_compressed)) AS AllCompressed
FROM msdb.dbo.backupset AS bs
WHERE bs.database_name = N'SmartBankDB'
  AND bs.backup_finish_date >= DATEADD(day, -3, CAST(GETDATE() AS date))
GROUP BY CAST(bs.backup_finish_date AS date), bs.type
ORDER BY BackupDate, BackupType;
GO
