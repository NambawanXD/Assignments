/*
LOGIN / LOGOUT / FAILED LOGIN DEMONSTRATION

Because login and logout occur at server connection level, do these steps before
running the query section:

1. Connect a new SSMS window using SB_CUSTOMER01 and the correct password.
2. Run: SELECT ORIGINAL_LOGIN(), USER_NAME(), SYSDATETIME();
3. Disconnect that Object Explorer/query connection to create LOGOUT evidence.
4. Attempt one connection using SB_CUSTOMER01 with an intentionally wrong password.
5. Reconnect as sysadmin and run the query below.
*/
USE SmartBankDB;
GO

SELECT
    event_time,
    action_id,
    succeeded,
    server_principal_name,
    session_server_principal_name,
    database_name,
    statement,
    application_name,
    client_ip
FROM sys.fn_get_audit_file
(
    (SELECT ConfigValue + N'*.sqlaudit'
     FROM admin.Configuration
     WHERE ConfigKey = N'AuditPath'),
    DEFAULT,
    DEFAULT
)
WHERE action_id IN ('LGIS', 'LGIF', 'LGO')
   OR server_principal_name LIKE N'SB[_]%'
   OR session_server_principal_name LIKE N'SB[_]%'
ORDER BY event_time DESC;
GO
