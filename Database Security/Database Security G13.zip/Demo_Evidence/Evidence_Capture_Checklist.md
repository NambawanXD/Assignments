# SmartBankDB Demo Evidence Checklist

Use dated screenshots or exported query results. Do not edit or fabricate timestamps.

## Before the demo

- [ ] SQL Server Agent is running.
- [ ] Three consecutive calendar dates have successful full, differential, and log backup evidence.
- [ ] Backup files exist and the SQL Server service can read them.
- [ ] Backup certificate `.cer` and private-key `.pvk` files are secured and copied for restore testing.
- [ ] An encrypted full backup was restored successfully on a second instance.
- [ ] `DBCC CHECKDB` passed on the restored copy.
- [ ] PITR was rehearsed using a non-production test deletion.
- [ ] Every demo login can connect.
- [ ] Audit output includes successful login, failed login, logout, DML, DDL, and permission changes.

## Screenshot/result sequence

1. Server name, SQL Server version, and Agent running state.
2. Login list and password-policy flags.
3. Database users and role membership.
4. Explicit GRANT/DENY permissions.
5. Authorization matrix.
6. RLS policies and predicates.
7. Dynamic masking metadata and data classifications.
8. DBA proof.
9. Manager proof.
10. Officer proof.
11. Customer 1 proof and automatic decryption.
12. Customer 2 proof showing different RLS rows.
13. Static masking, hashing, and anonymisation proof.
14. Business-action and DML change audit.
15. SQL Server Audit login/logout/failed login evidence.
16. Added user and permission change audit.
17. Three-day Agent job history and `msdb` backup history.
18. Encrypted second-instance restore and decrypted access.
19. Pre-deletion time, deletion, immediate log backup, PITR restore, comparison, and row recovery.
20. Final audit records for the deletion and recovery.

## Demo discipline

- Open separate SSMS connections for actual users.
- Run queries one at a time and explain the expected outcome before execution.
- Keep failed tests inside TRY/CATCH where provided so the demo continues.
- Never show certificate/private-key files or passwords to the audience longer than necessary.
- Keep the active database and restored copies clearly named.
