/*
POINT-IN-TIME RESTORE DEMO RUNBOOK

A. Immediately BEFORE deletion, run Phase A of:
   SQL\10_Point_In_Time_Restore_and_Row_Recovery.sql
B. Let the lecturer delete one or two rows from the active SmartBankDB.
C. Run Phase B to take an immediate encrypted log backup.
D. Paste the captured pre-deletion time into Phase C and restore SmartBankDB_PITR.
E. Use the comparisons and targeted recovery templates below.
*/

/* 1. Compare counts in active and PITR databases. */
SELECT N'ACTIVE' AS CopyName,
       (SELECT COUNT_BIG(*) FROM SmartBankDB.bank.Staff) AS StaffRows,
       (SELECT COUNT_BIG(*) FROM SmartBankDB.bank.Customer) AS CustomerRows,
       (SELECT COUNT_BIG(*) FROM SmartBankDB.bank.Account) AS AccountRows,
       (SELECT COUNT_BIG(*) FROM SmartBankDB.bank.TransactionRecord) AS TransactionRows
UNION ALL
SELECT N'PITR',
       (SELECT COUNT_BIG(*) FROM SmartBankDB_PITR.bank.Staff),
       (SELECT COUNT_BIG(*) FROM SmartBankDB_PITR.bank.Customer),
       (SELECT COUNT_BIG(*) FROM SmartBankDB_PITR.bank.Account),
       (SELECT COUNT_BIG(*) FROM SmartBankDB_PITR.bank.TransactionRecord);
GO

/* 2. Example: identify a deleted ACCOUNT row. Change the ID as required. */
DECLARE @DeletedAccountID varchar(10) = 'AC00000001';
SELECT N'ACTIVE' AS CopyName, *
FROM SmartBankDB.bank.Account WHERE AccountID = @DeletedAccountID;
SELECT N'PITR' AS CopyName, *
FROM SmartBankDB_PITR.bank.Account WHERE AccountID = @DeletedAccountID;
GO

/*
3. Recommended live demo: ask the lecturer to delete one or two rows from
bank.TransactionRecord. It is a leaf table, so recovery does not conflict with
foreign keys. Change the TransID values below after checking the PITR copy.
*/
/*
USE SmartBankDB;
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;
SET IDENTITY_INSERT bank.TransactionRecord ON;

INSERT bank.TransactionRecord
(
    TransID, TransactionReference, TransferGroupID, CustomerID, AccountID,
    CounterpartyAccountID, TransDate, Amount, TransactionType, Direction,
    BalanceBefore, BalanceAfter, Remarks, IdempotencyKey,
    InitiatedByLogin, SourceApplication
)
SELECT
    p.TransID, p.TransactionReference, p.TransferGroupID, p.CustomerID, p.AccountID,
    p.CounterpartyAccountID, p.TransDate, p.Amount, p.TransactionType, p.Direction,
    p.BalanceBefore, p.BalanceAfter, p.Remarks, p.IdempotencyKey,
    p.InitiatedByLogin, p.SourceApplication
FROM SmartBankDB_PITR.bank.TransactionRecord AS p
WHERE p.TransID IN (1, 2)
  AND NOT EXISTS
      (SELECT 1 FROM SmartBankDB.bank.TransactionRecord AS t WHERE t.TransID = p.TransID);

SET IDENTITY_INSERT bank.TransactionRecord OFF;
SELECT * FROM bank.TransactionRecord WHERE TransID IN (1, 2);
COMMIT TRANSACTION;
GO
*/

/*
4. ACCOUNT recovery template. This works when the customer parent still exists.
Generated temporal-period and rowversion columns are intentionally omitted.
*/
/*
USE SmartBankDB;
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;

INSERT bank.Account
(
    AccountID, CustomerID, AccountType, Balance, AccountStatus,
    OpenedAt, ClosedAt, CreatedBy, ModifiedAt, ModifiedBy
)
SELECT
    p.AccountID, p.CustomerID, p.AccountType, p.Balance, p.AccountStatus,
    p.OpenedAt, p.ClosedAt, p.CreatedBy, p.ModifiedAt, p.ModifiedBy
FROM SmartBankDB_PITR.bank.Account AS p
WHERE p.AccountID = 'AC00000099'
  AND NOT EXISTS
      (SELECT 1 FROM SmartBankDB.bank.Account AS a WHERE a.AccountID = p.AccountID);

SELECT * FROM bank.Account WHERE AccountID = 'AC00000099';
COMMIT TRANSACTION;
GO
*/

/*
5. CUSTOMER recovery template. This copies the original ciphertext and salted
hash exactly. It works when no conflicting CustomerID exists.
*/
/*
USE SmartBankDB;
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;

INSERT bank.Customer
(
    CustomerID, CustomerName, Email, Phone, DateOfBirth,
    ICNumberCipher, AddressCipher, HashSalt, ICNumberHash,
    CustomerStatus, CreatedAt, CreatedBy, ModifiedAt, ModifiedBy
)
SELECT
    p.CustomerID, p.CustomerName, p.Email, p.Phone, p.DateOfBirth,
    p.ICNumberCipher, p.AddressCipher, p.HashSalt, p.ICNumberHash,
    p.CustomerStatus, p.CreatedAt, p.CreatedBy, p.ModifiedAt, p.ModifiedBy
FROM SmartBankDB_PITR.bank.Customer AS p
WHERE p.CustomerID = 'CU0099'
  AND NOT EXISTS
      (SELECT 1 FROM SmartBankDB.bank.Customer AS c WHERE c.CustomerID = p.CustomerID);

SELECT CustomerID, CustomerName, Email, Phone, CustomerStatus
FROM bank.Customer WHERE CustomerID = 'CU0099';
COMMIT TRANSACTION;
GO
*/

/*
6. STAFF recovery template. Recover bank.Staff first, then bank.StaffPrivate.
The salary remains encrypted because SalaryCipher is copied unchanged.
*/
/*
USE SmartBankDB;
GO
SET XACT_ABORT ON;
BEGIN TRANSACTION;

INSERT bank.Staff
(
    StaffID, StaffName, Position, Branch, Phone, IsActive,
    CreatedAt, CreatedBy, ModifiedAt, ModifiedBy
)
SELECT
    p.StaffID, p.StaffName, p.Position, p.Branch, p.Phone, p.IsActive,
    p.CreatedAt, p.CreatedBy, p.ModifiedAt, p.ModifiedBy
FROM SmartBankDB_PITR.bank.Staff AS p
WHERE p.StaffID = 'ST0005'
  AND NOT EXISTS
      (SELECT 1 FROM SmartBankDB.bank.Staff AS s WHERE s.StaffID = p.StaffID);

INSERT bank.StaffPrivate
(
    StaffID, SalaryCipher, SalaryIntegrityHash,
    LastSalaryReviewDate, ModifiedAt, ModifiedBy
)
SELECT
    p.StaffID, p.SalaryCipher, p.SalaryIntegrityHash,
    p.LastSalaryReviewDate, p.ModifiedAt, p.ModifiedBy
FROM SmartBankDB_PITR.bank.StaffPrivate AS p
WHERE p.StaffID = 'ST0005'
  AND NOT EXISTS
      (SELECT 1 FROM SmartBankDB.bank.StaffPrivate AS s WHERE s.StaffID = p.StaffID);

COMMIT TRANSACTION;
GO
*/

/* 6. Show audit evidence for the deletion and recovery insert. */
USE SmartBankDB;
GO
SELECT TOP (100) *
FROM audit.vw_RecentDMLChanges
ORDER BY EventTimeUtc DESC, ChangeAuditID DESC;
GO
