/* Connect a NEW SSMS window using SQL Authentication:
   Login: SB_CUSTOMER02
   Password: Cust2#SmartBank2026!
*/
USE SmartBankDB;
GO

SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser;
EXEC api.usp_GetMyCustomerProfile;

PRINT 'RLS returns CU0002 data, which differs from Customer 1.';
SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT * FROM sec.vw_TransactionAccess ORDER BY TransID;

PRINT 'Customer 2 cannot see Customer 1 account.';
SELECT * FROM sec.vw_AccountAccess WHERE AccountID = 'AC00000001';
GO
