/* Connect a NEW SSMS window using SQL Authentication:
   Login: SB_DBA01
   Password: Dba#SmartBank2026!
*/
USE SmartBankDB;
GO

SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser;
SELECT * FROM sec.vw_PublicStaffDirectory;
SELECT * FROM sec.vw_StaffBasicAccess;
EXEC api.usp_GetMyStaffRecord;

PRINT 'Expected failure: DBA is not allowed to read customer account data.';
BEGIN TRY
    SELECT * FROM sec.vw_AccountAccess;
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;

PRINT 'Expected success: DBA can create and manage a table.';
IF OBJECT_ID(N'bank.DBA_DemoTable', N'U') IS NOT NULL DROP TABLE bank.DBA_DemoTable;
CREATE TABLE bank.DBA_DemoTable
(
    DemoID int NOT NULL CONSTRAINT PK_DBA_DemoTable PRIMARY KEY,
    Notes nvarchar(100) NULL
);

PRINT 'Expected failure: DBA can manage table definitions but cannot manipulate business data.';
BEGIN TRY
    INSERT bank.DBA_DemoTable (DemoID, Notes) VALUES (1, N'Not permitted');
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;

DROP TABLE bank.DBA_DemoTable;
GO
