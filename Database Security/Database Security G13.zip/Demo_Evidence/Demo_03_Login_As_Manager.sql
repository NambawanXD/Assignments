/* Connect a NEW SSMS window using SQL Authentication:
   Login: SB_MANAGER01
   Password: Mgr#SmartBank2026!
*/
USE SmartBankDB;
GO

SELECT ORIGINAL_LOGIN() AS LoginName, USER_NAME() AS DatabaseUser;
SELECT * FROM sec.vw_PublicStaffDirectory;
SELECT * FROM sec.vw_StaffBasicAccess ORDER BY StaffID;
EXEC api.usp_GetMyStaffRecord;
EXEC api.usp_Manager_GetStaffRecords;
SELECT * FROM sec.vw_AccountAccess ORDER BY AccountID;
SELECT * FROM sec.vw_TransactionAccess ORDER BY TransID;

PRINT 'DDM proof: Manager can query customer contact but sees masked values.';
SELECT * FROM sec.vw_CustomerContact ORDER BY CustomerID;

PRINT 'Manager valid update of Bank Officer details and encrypted salary.';
EXEC api.usp_Manager_UpdateBankOfficer
    @StaffID = 'ST0003',
    @Branch = N'Cheras Branch',
    @Phone = '03-21001999',
    @Salary = 5300.00,
    @IsActive = 1;
EXEC api.usp_Manager_GetStaffRecords;

PRINT 'Expected failure: Manager has no direct UPDATE on Account.';
BEGIN TRY
    UPDATE bank.Account SET Balance = Balance + 999 WHERE AccountID = 'AC00000001';
END TRY
BEGIN CATCH
    SELECT ERROR_NUMBER() AS ExpectedErrorNumber, ERROR_MESSAGE() AS ExpectedErrorMessage;
END CATCH;
GO
