#ifndef ADAM_LOADER_HPP
#define ADAM_LOADER_HPP

#include "adam_linkedlist.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>

namespace Adam {

/// Load at most `limit` rows from `filename` into `list`.
/// Inserts every transaction, regardless of channel.
void loadCSV(const std::string& filename, LinkedList& list, int limit = 500000);

} // namespace Adam

#endif // ADAM_LOADER_HPP
