#include "HemanthTransactionManager.hpp"
#include "ArrayCSVLoader.hpp"
#include "json.hpp"
#include <iostream>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <windows.h>
#include <psapi.h>

using json = nlohmann::json;

TransactionManagerH::TransactionManagerH() {
    allTransactions = new Transaction[MAX_TRANSACTIONS];
    filteredTransactions = new Transaction[MAX_TRANSACTIONS];
    filteredByType = new Transaction[MAX_TRANSACTIONS];
}

TransactionManagerH::~TransactionManagerH() {
    delete[] allTransactions;
    delete[] filteredTransactions;
    delete[] filteredByType;
}

bool TransactionManagerH::loadFromCSVH(const std::string& filename) {
    auto start = std::chrono::high_resolution_clock::now();
    bool result = loadCSVH(filename, allTransactions, totalTransactions, MAX_TRANSACTIONS);
    auto end = std::chrono::high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "CSV data loaded successfully.\n";
    std::cout << "Rows processed: " << totalTransactions << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";

    return result;
}

void TransactionManagerH::storeByChannelH() {
    std::cin.ignore();
    std::cout << "Enter payment channel to store (e.g., card, ACH, UPI, wire_transfer): ";
    std::getline(std::cin, currentChannel);

    filteredCount = 0;
    for (int i = 0; i < totalTransactions; ++i) {
        if (allTransactions[i].payment_channel == currentChannel) {
            filteredTransactions[filteredCount++] = allTransactions[i];
        }
    }

    searchCount = 0; // reset any previous search
    std::cout << "Stored " << filteredCount << " transactions for channel '" << currentChannel << "'.\n";
}

void TransactionManagerH::introsortByLocation() {
    auto start = std::chrono::high_resolution_clock::now();
    std::sort(filteredTransactions, filteredTransactions + filteredCount, [](const Transaction& a, const Transaction& b) {
        return a.location < b.location;
    });
    auto end = std::chrono::high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Sorted " << currentChannel << " transactions by location (A-Z).\n";
    std::cout << "Rows processed: " << filteredCount << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
}

void TransactionManagerH::introsortByAmountDescending() {
    auto start = std::chrono::high_resolution_clock::now();
    std::sort(filteredTransactions, filteredTransactions + filteredCount, [](const Transaction& a, const Transaction& b) {
        return a.amount > b.amount;
    });
    auto end = std::chrono::high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Sorted " << currentChannel << " transactions by amount (descending).\n";
    std::cout << "Rows processed: " << filteredCount << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
}

void TransactionManagerH::linearsearchByType(const std::string& type) {
    auto start = std::chrono::high_resolution_clock::now();
    searchCount = 0;

    for (int i = 0; i < filteredCount; ++i) {
        if (filteredTransactions[i].transaction_type == type) {
            filteredByType[searchCount++] = filteredTransactions[i];
        }
    }

    auto end = std::chrono::high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Found " << searchCount << " transactions of type '" << type << "' in channel '" << currentChannel << "'.\n";
    std::cout << "Rows processed: " << filteredCount << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
}

void TransactionManagerH::exportToJsonH(const std::string& filename) const {
    auto start = std::chrono::high_resolution_clock::now();
    json j;

    if (searchCount > 0) {
        for (int i = 0; i < searchCount; ++i) {
            j.push_back({
                {"transaction_id", filteredByType[i].transaction_id},
                {"amount", filteredByType[i].amount},
                {"location", filteredByType[i].location},
                {"type", filteredByType[i].transaction_type},
                {"payment_channel", filteredByType[i].payment_channel}
            });
        }
    } else {
        for (int i = 0; i < filteredCount; ++i) {
            j.push_back({
                {"transaction_id", filteredTransactions[i].transaction_id},
                {"amount", filteredTransactions[i].amount},
                {"location", filteredTransactions[i].location},
                {"type", filteredTransactions[i].transaction_type},
                {"payment_channel", filteredTransactions[i].payment_channel}
            });
        }
    }

    std::ofstream file(filename);
    file << j.dump(4);

    auto end = std::chrono::high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Exported to " << filename << "\n";
    std::cout << "Rows processed: " << (searchCount > 0 ? searchCount : filteredCount) << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
}

void TransactionManagerH::exportFraudToJsonH(const std::string& filename) const {
    auto start = std::chrono::high_resolution_clock::now();
    json j;
    int fraudCount = 0;

    for (int i = 0; i < totalTransactions; ++i) {
        if (allTransactions[i].is_fraud) {
            j.push_back({
                {"transaction_id", allTransactions[i].transaction_id},
                {"amount", allTransactions[i].amount},
                {"location", allTransactions[i].location},
                {"type", allTransactions[i].transaction_type},
                {"payment_channel", allTransactions[i].payment_channel}
            });
            ++fraudCount;
        }
    }

    std::ofstream file(filename);
    file << j.dump(4);

    auto end = std::chrono::high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Exported fraud transactions to " << filename << "\n";
    std::cout << "Rows processed: " << fraudCount << "\n";
    std::cout << "Time taken: " << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
}

void TransactionManagerH::viewSampleH(int count) const {
    for (int i = 0; i < std::min(count, totalTransactions); ++i) {
        std::cout << allTransactions[i].transaction_id << " | "
                  << allTransactions[i].transaction_type << " | "
                  << allTransactions[i].location << " | "
                  << allTransactions[i].amount << "\n";
    }
}

void TransactionManagerH::viewByLocationH(const std::string& location, int count) const {
    int shown = 0;
    for (int i = 0; i < totalTransactions && shown < count; ++i) {
        if (allTransactions[i].location == location) {
            std::cout << allTransactions[i].transaction_id << " | "
                      << allTransactions[i].transaction_type << " | "
                      << allTransactions[i].location << " | "
                      << allTransactions[i].amount << "\n";
            ++shown;
        }
    }
}

void TransactionManagerH::viewByTypeH(const std::string& type, int count) const {
    int shown = 0;
    for (int i = 0; i < totalTransactions && shown < count; ++i) {
        if (allTransactions[i].transaction_type == type) {
            std::cout << allTransactions[i].transaction_id << " | "
                      << allTransactions[i].transaction_type << " | "
                      << allTransactions[i].location << " | "
                      << allTransactions[i].amount << "\n";
            ++shown;
        }
    }
}
