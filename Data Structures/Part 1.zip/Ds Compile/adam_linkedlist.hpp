#ifndef ADAM_LINKEDLIST_HPP
#define ADAM_LINKEDLIST_HPP

#include "adam_transaction.hpp"
#include <iostream>
#include <chrono>
#include <iomanip>
#include <string>

namespace Adam {

struct Node {
    Transaction data;
    Node* next;
    Node(const Transaction& t) : data(t), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;
    int   size;

    Node* split(Node* source, int count);
    Node* sortedMerge(Node* a, Node* b);
    Node* mergeByChannel(Node* a, Node* b);

public:
    LinkedList();
    ~LinkedList();

    void insert(const Transaction& t);
    void clear();
    int  count() const;
    void displayFirst100() const;
    void sortByLocation();
    void sortByChannel();
    void searchByType(const std::string& type) const;
    void exportToJSON(const std::string& filename,
                      const std::string& type) const;

    Node* getHead() const { return head; }
};

} // namespace Adam

#endif // ADAM_LINKEDLIST_HPP
