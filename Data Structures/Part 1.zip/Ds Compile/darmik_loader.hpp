// File: darmik_loader.hpp

#ifndef DARMIK_LOADER_HPP
#define DARMIK_LOADER_HPP

#include "darmik_linkedlist.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <string>

namespace Darmik {

/// Load up to `limit` rows from `filename` into `list`.
/// Inserts every transaction, regardless of channel.
void loadCSV(const std::string& filename,
             LinkedList& list,
             int limit = 500000);

} // namespace Darmik

#endif // DARMIK_LOADER_HPP
