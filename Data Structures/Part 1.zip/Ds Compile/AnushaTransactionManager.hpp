#ifndef ANUSHA_TRANSACTION_MANAGER_HPP
#define ANUSHA_TRANSACTION_MANAGER_HPP

#include "ArrayTransaction.hpp"
#include <string>

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#endif

class TransactionManager {
private:
    static const int MAX_TRANSACTIONS = 500000;

    Transaction* allTransactions;
    Transaction* channelTransactions;  // replaces cardTransactions
    Transaction* filteredByType;

    int totalTransactions = 0;
    int channelCount = 0;
    int searchCount = 0;
    std::string currentChannel;

    void merge(Transaction* arr, int left, int mid, int right, bool byAmountDesc, bool byLocation);
    void mergeSort(Transaction* arr, int left, int right, bool byAmountDesc, bool byLocation);
    int binarySearchType(const std::string& type, int left, int right);

public:
    TransactionManager();
    ~TransactionManager();

    bool loadFromCSV(const std::string& filename);
    void storeByChannel(const std::string& channel);

    void sortByLocation();
    void sortByAmountDescending();
    void searchByType(const std::string& type);

    void exportAllChannelToJson(const std::string& filename) const;
    void exportFilteredToJson(const std::string& filename) const;
    void exportFraudToJson(const std::string& filename) const;

    void viewSample(int count) const;
    void viewByLocation(const std::string& location, int count) const;
    void viewByType(const std::string& type, int count) const;

    bool hasFiltered() const;
};

#endif
