#include "AnushaTransactionManager.hpp"
#include <iostream>

int anushaMain() {
    TransactionManager tm;
    int choice;

    do {
        std::cout << "\n====== Financial Transaction System (MergeSort + BinarySearch) ======\n";
        std::cout << "1. Load data from CSV\n";
        std::cout << "2. Store transactions by payment channel\n";
        std::cout << "3. Sort transactions by location (A-Z)\n";
        std::cout << "4. Sort transactions by amount (desc)\n";
        std::cout << "5. Search transactions by type\n";
        std::cout << "6. Export current transactions to JSON\n";
        std::cout << "7. Export fraud transactions to JSON\n";
        std::cout << "8. View sample transactions\n";
        std::cout << "9. View transactions by location\n";
        std::cout << "10. View transactions by type\n";
        std::cout << "11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                tm.loadFromCSV("financial_fraud_detection_dataset.csv");
                break;
            case 2: {
                std::string channel;
                std::cout << "Enter payment channel (card, ACH, UPI, wire_transfer): ";
                std::cin >> channel;
                tm.storeByChannel(channel);
                break;
            }
            case 3:
                tm.sortByLocation();
                break;
            case 4:
                tm.sortByAmountDescending();
                break;
            case 5: {
                std::string type;
                std::cout << "Enter transaction type: ";
                std::cin.ignore();
                std::getline(std::cin, type);
                tm.searchByType(type);
                break;
            }
            case 6:
                tm.hasFiltered()
                    ? tm.exportFilteredToJson("filtered_transactions.json")
                    : tm.exportAllChannelToJson("channel_transactions.json");
                break;
            case 7:
                tm.exportFraudToJson("fraud_transactions.json");
                break;
            case 8:
                tm.viewSample(100);
                break;
            case 9: {
                std::string loc;
                std::cout << "Enter location: ";
                std::cin.ignore();
                std::getline(std::cin, loc);
                tm.viewByLocation(loc, 100);
                break;
            }
            case 10: {
                std::string type;
                std::cout << "Enter transaction type: ";
                std::cin.ignore();
                std::getline(std::cin, type);
                tm.viewByType(type, 100);
                break;
            }
            case 11:
                std::cout << "Exiting program...\n";
                break;
            default:
                std::cout << "Invalid choice.\n";
        }

    } while (choice != 11);

    return 0;
}
