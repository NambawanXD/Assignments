#ifndef ADAM_TRANSACTION_HPP
#define ADAM_TRANSACTION_HPP

#include <string>

namespace Adam {

struct Transaction {
    std::string transaction_id;
    std::string transaction_type;
    std::string location;
    std::string payment_channel;
    std::string is_fraud;
    double amount;

    Transaction() : amount(0.0) {}
    Transaction(const std::string& id, const std::string& type,
                const std::string& loc, const std::string& channel,
                const std::string& fraud, double amt)
      : transaction_id(id),
        transaction_type(type),
        location(loc),
        payment_channel(channel),
        is_fraud(fraud),
        amount(amt) {}
};

} // namespace Adam

#endif // ADAM_TRANSACTION_HPP
