#pragma once

/// Entry-point for Adam linked-list impl (linear search + merge sort)
int adamMain();
