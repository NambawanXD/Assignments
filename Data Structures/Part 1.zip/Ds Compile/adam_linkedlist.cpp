#include "adam_linkedlist.hpp"
#include <fstream>
#include <chrono>

namespace Adam {

LinkedList::LinkedList() : head(nullptr), size(0) {}
LinkedList::~LinkedList() { clear(); }

void LinkedList::insert(const Transaction& t) {
    Node* newNode = new Node(t);
    newNode->next = head;
    head = newNode;
    size++;
}

void LinkedList::clear() {
    while (head) {
        Node* tmp = head;
        head = head->next;
        delete tmp;
    }
    size = 0;
}

int LinkedList::count() const {
    return size;
}

void LinkedList::displayFirst100() const {
    Node* curr = head;
    int shown = 0;
    while (curr && shown < 100) {
        const Transaction& d = curr->data;
        std::cout << shown+1 << ". ID: " << d.transaction_id
                  << " | Type: " << d.transaction_type
                  << " | Channel: " << d.payment_channel
                  << " | Location: " << d.location
                  << " | Amount: " << d.amount
                  << " | Fraud: " << d.is_fraud
                  << "\n";
        curr = curr->next;
        shown++;
    }
}

Node* LinkedList::split(Node* source, int count) {
    while (--count && source)
        source = source->next;
    if (!source) return nullptr;
    Node* next = source->next;
    source->next = nullptr;
    return next;
}

Node* LinkedList::sortedMerge(Node* a, Node* b) {
    // use brace initialization so 'dummy' is a Node, not a function
    Node dummy{ Transaction() };
    Node* tail = &dummy;
    while (a && b) {
        if (a->data.location <= b->data.location) {
            tail->next = a;
            a = a->next;
        } else {
            tail->next = b;
            b = b->next;
        }
        tail = tail->next;
    }
    tail->next = a ? a : b;
    return dummy.next;
}

void LinkedList::sortByLocation() {
    if (!head || !head->next) return;
    int step = 1;
    while (true) {
        Node* curr = head;
        Node* newHead = nullptr;
        Node* tail = nullptr;
        int merges = 0;
        while (curr) {
            merges++;
            Node* left = curr;
            Node* right = split(left, step);
            curr = split(right, step);
            Node* merged = sortedMerge(left, right);
            if (!newHead) newHead = merged;
            if (tail) tail->next = merged;
            tail = merged;
            while (tail->next) tail = tail->next;
        }
        head = newHead;
        if (merges <= 1) break;
        step *= 2;
    }
}

Node* LinkedList::mergeByChannel(Node* a, Node* b) {
    Node dummy{ Transaction() };
    Node* tail = &dummy;
    while (a && b) {
        if (a->data.payment_channel <= b->data.payment_channel) {
            tail->next = a;
            a = a->next;
        } else {
            tail->next = b;
            b = b->next;
        }
        tail = tail->next;
    }
    tail->next = a ? a : b;
    return dummy.next;
}

void LinkedList::sortByChannel() {
    if (!head || !head->next) return;
    int step = 1;
    while (true) {
        Node* curr = head;
        Node* newHead = nullptr;
        Node* tail = nullptr;
        int merges = 0;
        while (curr) {
            merges++;
            Node* left = curr;
            Node* right = split(left, step);
            curr = split(right, step);
            Node* merged = mergeByChannel(left, right);
            if (!newHead) newHead = merged;
            if (tail) tail->next = merged;
            tail = merged;
            while (tail->next) tail = tail->next;
        }
        head = newHead;
        if (merges <= 1) break;
        step *= 2;
    }
}

void LinkedList::searchByType(const std::string& type) const {
    Node* curr = head;
    int found = 0;
    while (curr) {
        if (curr->data.transaction_type == type) {
            ++found;
            const Transaction& d = curr->data;
            std::cout << found << ". ID: " << d.transaction_id
                      << " | Channel: " << d.payment_channel
                      << " | Location: " << d.location
                      << " | Amount: " << d.amount
                      << "\n";
        }
        curr = curr->next;
    }
}

void LinkedList::exportToJSON(const std::string& filename,
                              const std::string& type) const {
    std::ofstream file(filename);
    file << "{\n  \"filter\": \"" << type << "\",\n"
         << "  \"transactions\": [\n";
    Node* curr = head;
    bool first = true;
    while (curr) {
        const Transaction& d = curr->data;
        if (d.transaction_type == type || d.payment_channel == type) {
            if (!first) file << ",\n";
            first = false;
            file << "    { \"id\": \"" << d.transaction_id
                 << "\", \"type\": \"" << d.transaction_type
                 << "\", \"channel\": \"" << d.payment_channel
                 << "\", \"location\": \"" << d.location
                 << "\", \"amount\": " << d.amount << " }";
        }
        curr = curr->next;
    }
    file << "\n  ]\n}\n";
}

} // namespace Adam
