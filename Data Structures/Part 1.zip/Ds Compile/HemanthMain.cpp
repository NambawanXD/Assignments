#include "HemanthTransactionManager.hpp"
#include <iostream>

int hemanthMain() {
    TransactionManagerH tm;
    int choice;

    do {
        std::cout << "\n====== Financial Transaction System (Array-Based) introsort + linear search ======\n";
        std::cout << "1. Load data from CSV\n";
        std::cout << "2. Store transactions by payment channel\n";
        std::cout << "3. Sort card transactions by location\n";
        std::cout << "4. Sort card transactions by amount (desc)\n";
        std::cout << "5. Search card transactions by type\n";
        std::cout << "6. Export card transactions to JSON\n";
        std::cout << "7. Export fraud transactions to JSON\n";
        std::cout << "8. View sample transactions\n";
        std::cout << "9. View transactions by location\n";
        std::cout << "10. View transactions by type\n";
        std::cout << "11. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::string file = "financial_fraud_detection_dataset.csv";
                if (tm.loadFromCSVH(file)) {
                    std::cout << "Data loaded successfully.\n";
                } else {
                    std::cout << "Failed to load data.\n";
                }
                break;
            }
            case 2:
                tm.storeByChannelH();
                break;
            case 3:
                tm.introsortByLocation();
                break;
            case 4:
                tm.introsortByAmountDescending();
                break;
            case 5: {
                std::string type;
                std::cout << "Enter transaction type: ";
                std::cin.ignore();
                std::getline(std::cin, type);
                tm.linearsearchByType(type);
                break;
            }
            case 6:
                tm.exportToJsonH("channel_transactions.json");
                break;
            case 7:
                tm.exportFraudToJsonH("fraud_transactions.json");
                break;
            case 8:
                tm.viewSampleH(100);
                break;
            case 9: {
                std::string loc;
                std::cout << "Enter location: ";
                std::cin.ignore();
                std::getline(std::cin, loc);
                tm.viewByLocationH(loc, 100);
                break;
            }
            case 10: {
                std::string type;
                std::cout << "Enter transaction type: ";
                std::cin.ignore();
                std::getline(std::cin, type);
                tm.viewByTypeH(type, 100);
                break;
            }
            case 11:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice.\n";
        }

    } while (choice != 11);

    return 0;
}
