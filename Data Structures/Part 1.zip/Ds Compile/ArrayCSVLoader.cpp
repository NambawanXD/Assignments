#include "ArrayCSVLoader.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <algorithm> // for transform and remove_if

bool loadCSV(const std::string& filename, Transaction* transactions, int& count, int max) {
    std::ifstream file(filename);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    count = 0;
    while (std::getline(file, line) && count < max) {
        std::stringstream ss(line);
        std::string value;
        Transaction& t = transactions[count];

        std::getline(ss, t.transaction_id, ',');
        std::getline(ss, t.timestamp, ',');
        std::getline(ss, t.sender_account, ',');
        std::getline(ss, t.receiver_account, ',');
        std::getline(ss, value, ','); t.amount = std::stod(value);
        std::getline(ss, t.transaction_type, ',');
        std::getline(ss, t.merchant_category, ',');
        std::getline(ss, t.location, ',');
        std::getline(ss, t.device_used, ',');

        // Fix: read and normalize fraud flag
        std::getline(ss, value, ',');
        value.erase(std::remove_if(value.begin(), value.end(), ::isspace), value.end());
        std::transform(value.begin(), value.end(), value.begin(), ::tolower);
        t.is_fraud = (value == "true");

        std::getline(ss, t.fraud_type, ',');
        std::getline(ss, value, ','); t.time_since_last_transaction = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, value, ','); t.spending_deviation_score = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, value, ','); t.velocity_score = value.empty() ? 0 : std::stoi(value);
        std::getline(ss, value, ','); t.geo_anomaly_score = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, t.payment_channel, ',');
        std::getline(ss, t.ip_address, ',');
        std::getline(ss, t.device_hash, ',');

        count++;
    }

    return true;
}

bool loadCSVH(const std::string& filename, Transaction* transactions, int& count, int max) {
    std::ifstream file(filename);
    if (!file.is_open()) return false;

    std::string line;
    std::getline(file, line); // skip header

    count = 0;
    while (std::getline(file, line) && count < max) {
        std::stringstream ss(line);
        std::string value;
        Transaction& t = transactions[count];

        std::getline(ss, t.transaction_id, ',');
        std::getline(ss, t.timestamp, ',');
        std::getline(ss, t.sender_account, ',');
        std::getline(ss, t.receiver_account, ',');
        std::getline(ss, value, ','); t.amount = std::stod(value);
        std::getline(ss, t.transaction_type, ',');
        std::getline(ss, t.merchant_category, ',');
        std::getline(ss, t.location, ',');
        std::getline(ss, t.device_used, ',');

        // Fix: read and normalize fraud flag
        std::getline(ss, value, ',');
        value.erase(std::remove_if(value.begin(), value.end(), ::isspace), value.end());
        std::transform(value.begin(), value.end(), value.begin(), ::tolower);
        t.is_fraud = (value == "true");

        std::getline(ss, t.fraud_type, ',');
        std::getline(ss, value, ','); t.time_since_last_transaction = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, value, ','); t.spending_deviation_score = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, value, ','); t.velocity_score = value.empty() ? 0 : std::stoi(value);
        std::getline(ss, value, ','); t.geo_anomaly_score = value.empty() ? 0.0 : std::stod(value);
        std::getline(ss, t.payment_channel, ',');
        std::getline(ss, t.ip_address, ',');
        std::getline(ss, t.device_hash, ',');

        count++;
    }

    return true;
}