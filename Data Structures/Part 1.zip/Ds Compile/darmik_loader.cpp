// File: darmik_loader.cpp

#include "darmik_loader.hpp"

namespace Darmik {

void loadCSV(const std::string& filename, LinkedList& list, int limit) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cout << "Error opening file: " << filename << "\n";
        return;
    }

    std::string line, token;
    std::getline(file, line);  // skip header
    int count = 0;
    while (std::getline(file, line) && count < limit) {
        std::stringstream ss(line);
        Transaction t;
        std::getline(ss, t.transaction_id, ',');
        std::getline(ss, token, ',');  
        std::getline(ss, token, ',');  
        std::getline(ss, token, ',');  
        std::getline(ss, token, ','); t.amount = token.empty() ? 0 : std::stod(token);
        std::getline(ss, t.transaction_type, ',');
        std::getline(ss, token, ',');  
        std::getline(ss, t.location, ',');
        std::getline(ss, token, ',');  
        std::getline(ss, t.is_fraud, ',');
        for (int i = 0; i < 4; ++i) std::getline(ss, token, ',');
        std::getline(ss, token, ',');
        std::getline(ss, t.payment_channel, ',');
        std::getline(ss, token, ',');
        std::getline(ss, token, ',');

        list.insert(t);
        ++count;
        if (count % 50000 == 0)
            std::cout << "[INFO] Processed " << count << " rows...\n";
    }

    file.close();
    std::cout << "Loaded " << list.count()
              << " transactions (up to max " << limit << " rows).\n";
}

} // namespace Darmik
