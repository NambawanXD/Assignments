#include "AnushaTransactionManager.hpp"
#include "ArrayCSVLoader.hpp"
#include "json.hpp"
#include <iostream>
#include <fstream>
#include <chrono>
#include <windows.h>
#include <psapi.h>

using json = nlohmann::json;
using namespace std::chrono;

TransactionManager::TransactionManager() {
    allTransactions = new Transaction[MAX_TRANSACTIONS];
    channelTransactions = new Transaction[MAX_TRANSACTIONS];
    filteredByType = new Transaction[MAX_TRANSACTIONS];
}

TransactionManager::~TransactionManager() {
    delete[] allTransactions;
    delete[] channelTransactions;
    delete[] filteredByType;
}

bool TransactionManager::loadFromCSV(const std::string& filename) {
    auto start = high_resolution_clock::now();
    bool success = loadCSV(filename, allTransactions, totalTransactions, MAX_TRANSACTIONS);
    auto end = high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    if (success) {
        std::cout << "CSV data loaded successfully.\n";
        std::cout << "Rows processed: " << totalTransactions << "\n";
        std::cout << "Time taken: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
        std::cout << "Memory used: " << pmc.WorkingSetSize / 1024 << " KB\n";
    }
    return success;
}

void TransactionManager::storeByChannel(const std::string& channel) {
    currentChannel = channel;
    channelCount = 0;
    for (int i = 0; i < totalTransactions; ++i) {
        if (allTransactions[i].payment_channel == channel) {
            channelTransactions[channelCount++] = allTransactions[i];
        }
    }
    std::cout << "Stored " << channelCount << " transactions for channel: " << channel << "\n";
    searchCount = 0;
}

void TransactionManager::merge(Transaction* arr, int left, int mid, int right, bool byAmountDesc, bool byLocation) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Transaction* L = new Transaction[n1];
    Transaction* R = new Transaction[n2];

    for (int i = 0; i < n1; ++i) L[i] = arr[left + i];
    for (int j = 0; j < n2; ++j) R[j] = arr[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        bool condition;
        if (byAmountDesc)
            condition = L[i].amount >= R[j].amount;
        else if (byLocation)
            condition = L[i].location <= R[j].location;
        else
            condition = L[i].transaction_type <= R[j].transaction_type;

        if (condition)
            arr[k++] = L[i++];
        else
            arr[k++] = R[j++];
    }

    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];

    delete[] L;
    delete[] R;
}

void TransactionManager::mergeSort(Transaction* arr, int left, int right, bool byAmountDesc, bool byLocation) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergeSort(arr, left, mid, byAmountDesc, byLocation);
        mergeSort(arr, mid + 1, right, byAmountDesc, byLocation);
        merge(arr, left, mid, right, byAmountDesc, byLocation);
    }
}

void TransactionManager::sortByLocation() {
    auto start = high_resolution_clock::now();
    mergeSort(channelTransactions, 0, channelCount - 1, false, true);
    auto end = high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Sorted " << currentChannel << " transactions by location (A-Z).\n";
    std::cout << "Rows processed: " << channelCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

void TransactionManager::sortByAmountDescending() {
    auto start = high_resolution_clock::now();
    mergeSort(channelTransactions, 0, channelCount - 1, true, false);
    auto end = high_resolution_clock::now();

    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Sorted " << currentChannel << " transactions by amount (desc).\n";
    std::cout << "Rows processed: " << channelCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

int TransactionManager::binarySearchType(const std::string& type, int left, int right) {
    while (left <= right) {
        int mid = left + (right - left) / 2;
        if (channelTransactions[mid].transaction_type == type)
            return mid;
        else if (channelTransactions[mid].transaction_type < type)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;
}

void TransactionManager::searchByType(const std::string& type) {
    auto start = high_resolution_clock::now();
    mergeSort(channelTransactions, 0, channelCount - 1, false, false);
    int foundIndex = binarySearchType(type, 0, channelCount - 1);
    searchCount = 0;

    if (foundIndex != -1) {
        int left = foundIndex;
        while (left >= 0 && channelTransactions[left].transaction_type == type)
            --left;
        int right = foundIndex;
        while (right < channelCount && channelTransactions[right].transaction_type == type)
            ++right;
        for (int i = left + 1; i < right; ++i)
            filteredByType[searchCount++] = channelTransactions[i];
    }

    auto end = high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Found " << searchCount << " " << currentChannel << " transactions of type '" << type << "'.\n";
    std::cout << "Rows processed: " << channelCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

void TransactionManager::exportAllChannelToJson(const std::string& filename) const {
    auto start = high_resolution_clock::now();

    json j;
    for (int i = 0; i < channelCount; ++i) {
        j.push_back({
            {"transaction_id", channelTransactions[i].transaction_id},
            {"amount", channelTransactions[i].amount},
            {"location", channelTransactions[i].location},
            {"type", channelTransactions[i].transaction_type},
            {"payment_channel", channelTransactions[i].payment_channel}
        });
    }

    std::ofstream file(filename);
    file << j.dump(4);

    auto end = high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Exported " << channelCount << " transactions to " << filename << "\n";
    std::cout << "Rows processed: " << channelCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

void TransactionManager::exportFilteredToJson(const std::string& filename) const {
    auto start = high_resolution_clock::now();

    json j;
    for (int i = 0; i < searchCount; ++i) {
        j.push_back({
            {"transaction_id", filteredByType[i].transaction_id},
            {"amount", filteredByType[i].amount},
            {"location", filteredByType[i].location},
            {"type", filteredByType[i].transaction_type},
            {"payment_channel", filteredByType[i].payment_channel}
        });
    }

    std::ofstream file(filename);
    file << j.dump(4);

    auto end = high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Exported " << searchCount << " filtered transactions to " << filename << "\n";
    std::cout << "Rows processed: " << searchCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

void TransactionManager::exportFraudToJson(const std::string& filename) const {
    auto start = high_resolution_clock::now();

    json j;
    int fraudCount = 0;
    for (int i = 0; i < totalTransactions; ++i) {
        if (allTransactions[i].is_fraud) {
            j.push_back({
                {"transaction_id", allTransactions[i].transaction_id},
                {"amount", allTransactions[i].amount},
                {"location", allTransactions[i].location},
                {"type", allTransactions[i].transaction_type},
                {"payment_channel", allTransactions[i].payment_channel}
            });
            ++fraudCount;
        }
    }

    std::ofstream file(filename);
    file << j.dump(4);

    auto end = high_resolution_clock::now();
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), (PROCESS_MEMORY_COUNTERS*)&pmc, sizeof(pmc));

    std::cout << "Exported fraud transactions to " << filename << "\n";
    std::cout << "Rows processed: " << fraudCount << "\n";
    std::cout << "Time: " << duration_cast<milliseconds>(end - start).count() << " ms\n";
    std::cout << "Memory used: " << pmc.WorkingSetSize << " bytes\n";
}

void TransactionManager::viewSample(int count) const {
    for (int i = 0; i < std::min(count, totalTransactions); ++i) {
        std::cout << allTransactions[i].transaction_id << " | "
                  << allTransactions[i].transaction_type << " | "
                  << allTransactions[i].location << " | "
                  << allTransactions[i].amount << "\n";
    }
}

void TransactionManager::viewByLocation(const std::string& location, int count) const {
    int shown = 0;
    for (int i = 0; i < totalTransactions && shown < count; ++i) {
        if (allTransactions[i].location == location) {
            std::cout << allTransactions[i].transaction_id << " | "
                      << allTransactions[i].transaction_type << " | "
                      << allTransactions[i].location << " | "
                      << allTransactions[i].amount << "\n";
            ++shown;
        }
    }
}

void TransactionManager::viewByType(const std::string& type, int count) const {
    int shown = 0;
    for (int i = 0; i < totalTransactions && shown < count; ++i) {
        if (allTransactions[i].transaction_type == type) {
            std::cout << allTransactions[i].transaction_id << " | "
                      << allTransactions[i].transaction_type << " | "
                      << allTransactions[i].location << " | "
                      << allTransactions[i].amount << "\n";
            ++shown;
        }
    }
}

bool TransactionManager::hasFiltered() const {
    return searchCount > 0;
}
