// File: main.cpp

#include <iostream>
#include <limits>

// Forward declarations for all submenus
int anushaMain();
int hemanthMain();
int adamMain();
int darmikMain();

int arrayMain() {
    while (true) {
        std::cout << "\n--- Array Implementation ---\n"
                  << "1) Anusha (binary search + merge sort)\n"
                  << "2) Hemanth (linear search + introsort)\n"
                  << "0) Back\n"
                  << "Choice: ";
        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input; please enter a number.\n";
            continue;
        }
        if (choice == 0) {
            return 0;   // back to top‐level
        }
        switch (choice) {
            case 1:
                anushaMain();
                break;
            case 2:
                hemanthMain();
                break;
            default:
                std::cout << "Invalid option; try again.\n";
        }
    }
}

int main() {
    while (true) {
        std::cout << "\n=== Data Structure Selection ===\n"
                  << "1) Arrays\n"
                  << "2) Linked Lists\n"
                  << "0) Exit\n"
                  << "Select an option: ";
        int dsChoice;
        if (!(std::cin >> dsChoice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input; please enter a number.\n";
            continue;
        }
        if (dsChoice == 0) {
            std::cout << "Goodbye!\n";
            break;
        }
        switch (dsChoice) {
            case 1:
                arrayMain();
                break;
            case 2:
                // Linked‐list submenu
                while (true) {
                    std::cout << "\n=== Transaction Processor ===\n"
                              << "1) Adam (linear search + merge sort)\n"
                              << "2) Darmik (linear search + introsort)\n"
                              << "0) Back\n"
                              << "Select an option: ";
                    int choice;
                    if (!(std::cin >> choice)) {
                        std::cin.clear();
                        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                        std::cout << "Invalid input; please enter a number.\n";
                        continue;
                    }
                    if (choice == 0) {
                        break;  // back to Data Structure menu
                    }
                    switch (choice) {
                        case 1:
                            adamMain();
                            break;
                        case 2:
                            darmikMain();
                            break;
                        default:
                            std::cout << "Invalid option; try again.\n";
                    }
                }
                break;
            default:
                std::cout << "Invalid choice; please choose 1, 2, or 0.\n";
        }
    }
    return 0;
}
