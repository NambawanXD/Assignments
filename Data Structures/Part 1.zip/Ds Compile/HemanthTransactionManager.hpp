#ifndef HEMANTH_TRANSACTION_MANAGER_HPP
#define HEMANTH_TRANSACTION_MANAGER_HPP

#include <chrono>
#include <windows.h>
#include <psapi.h>
#include "ArrayTransaction.hpp"
#include <string>

#define MAX_TRANSACTIONS 500000

class TransactionManagerH {
private:
    Transaction* allTransactions;
    Transaction* filteredTransactions;  // Based on user-selected channel
    Transaction* filteredByType;

    std::string currentChannel;
    int totalTransactions = 0;
    int filteredCount = 0;
    int searchCount = 0;

public:
    TransactionManagerH();
    ~TransactionManagerH();

    bool loadFromCSVH(const std::string& filename);
    void storeByChannelH();
    void introsortByLocation();
    void introsortByAmountDescending();
    void linearsearchByType(const std::string& type);
    void exportToJsonH(const std::string& filename) const;
    void exportFraudToJsonH(const std::string& filename) const;
    void viewSampleH(int count) const;
    void viewByLocationH(const std::string& location, int count) const;
    void viewByTypeH(const std::string& type, int count) const;
};

#endif
