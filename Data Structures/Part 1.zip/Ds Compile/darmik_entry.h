#pragma once

/// Entry-point for Darmik linked-list impl (linear search + introsort)
int darmikMain();
