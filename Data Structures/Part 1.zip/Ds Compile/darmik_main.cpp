// File: darmik_main.cpp

#include "darmik_loader.hpp"
#include "darmik_linkedlist.hpp"
#include <iostream>
#include <chrono>
#include <limits>
#include <fstream>

using namespace Darmik;

int darmikMain() {
    LinkedList list;
    const std::string filename = "financial_fraud_detection_dataset.csv";
    bool dataLoaded = false;
    double loadTimeMs = 0.0;
    size_t memoryUsed = 0;
    const std::string channels[] = {"card","ACH","UPI","wire_transfer"};
    const std::string types[]    = {"withdrawal","payment","transfer","deposit"};

    while (true) {
        std::cout << "\n--- Financial Transaction System Menu (Darmik) ---\n"
                  << "1) Load all transactions from CSV\n"
                  << "2) Display & export by each payment channel (sorted by location)\n"
                  << "3) Sort all transactions by location (ascending)\n"
                  << "4) Display & export by transaction type\n"
                  << "0) Back to Main Menu\n"
                  << "Select an option: ";

        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
            std::cout<<"Invalid input; enter a number.\n";
            continue;
        }
        if (choice == 0) break;
        if (choice != 1 && !dataLoaded) {
            std::cout<<"You must load data first (option 1).\n";
            continue;
        }

        switch (choice) {
        case 1: {
            std::cout<<"Loading all transactions from CSV...\n";
            auto t0 = std::chrono::high_resolution_clock::now();
            loadCSV(filename, list);
            auto t1 = std::chrono::high_resolution_clock::now();
            loadTimeMs = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
            memoryUsed = list.count()*sizeof(Node);
            std::cout<<"Load time: "<<loadTimeMs<<" ms\n";
            std::cout<<"Memory used: "<<memoryUsed<<" bytes\n";
            dataLoaded = true;
            break;
        }
        case 2: {
            std::cout<<"Display & export by each payment channel:\n";
            std::cout<<"Load time: "<<loadTimeMs<<" ms\n";
            std::cout<<"Memory used: "<<memoryUsed<<" bytes\n";
            for (auto& ch: channels) {
                LinkedList sub;
                for (Node* n=list.getHead(); n; n=n->next)
                    if (n->data.payment_channel==ch) sub.insert(n->data);
                int tot=sub.count();
                std::cout<<"\nChannel: "<<ch<<" (total "<<tot<<")\n";
                std::cout<<"Sorting by location...\n";
                auto s0=std::chrono::high_resolution_clock::now();
                sub.sortByLocation();
                auto s1=std::chrono::high_resolution_clock::now();
                double dt=std::chrono::duration_cast<std::chrono::milliseconds>(s1-s0).count();
                std::cout<<"Sorted in "<<dt<<" ms\n";
                std::cout<<"Displaying first 100 records:\n";
                sub.displayFirst100();
                int shown = tot<100? tot:100;
                std::cout<<"Displayed "<<shown<<" out of "<<tot<<"\n";
                std::string fname=ch+"_by_location.json";
                std::ofstream out(fname);
                out<<"{\n  \"channel\":\""<<ch<<"\",\n  \"transactions\":[\n";
                bool first=true;
                for(Node* n=sub.getHead(); n; n=n->next){
                    if(!first) out<<",\n";
                    first=false;
                    const auto& d=n->data;
                    out<<"    {\"transaction_id\":\""<<d.transaction_id
                       <<"\",\"transaction_type\":\""<<d.transaction_type
                       <<"\",\"location\":\""<<d.location
                       <<"\",\"amount\":"<<d.amount<<"}";
                }
                out<<"\n  ]\n}\n";
                std::cout<<"Exported "<<tot<<" to "<<fname<<"\n";
                out.close();
            }
            break;
        }
        case 3: {
            std::cout<<"Sorting all transactions by LOCATION...\n";
            auto s0=std::chrono::high_resolution_clock::now();
            list.sortByLocation();
            auto s1=std::chrono::high_resolution_clock::now();
            double tm=std::chrono::duration_cast<std::chrono::milliseconds>(s1-s0).count();
            std::cout<<"Sorted in "<<tm<<" ms\n";
            std::cout<<"Load time: "<<loadTimeMs<<" ms\n";
            std::cout<<"Memory used: "<<memoryUsed<<" bytes\n";
            std::cout<<"Displaying first 100 records:\n";
            list.displayFirst100();
            int tot=list.count();
            std::cout<<"Exporting all to all_by_location.json\n";
            std::ofstream out("all_by_location.json");
            out<<"{\n  \"transactions\":[\n";
            bool first=true;
            for(Node* n=list.getHead(); n; n=n->next){
                if(!first) out<<",\n";
                first=false;
                const auto& d=n->data;
                out<<"    {\"transaction_id\":\""<<d.transaction_id
                   <<"\",\"payment_channel\":\""<<d.payment_channel
                   <<"\",\"location\":\""<<d.location
                   <<"\",\"amount\":"<<d.amount<<"}";
            }
            out<<"\n  ]\n}\n";
            out.close();
            std::cout<<"Export complete\n";
            break;
        }
        case 4: {
            while (true) {
                std::cout<<"\nSelect transaction type:\n";
                for(int i=0;i<4;++i)
                    std::cout<<i+1<<") "<<types[i]<<"\n";
                std::cout<<"0) Back\nChoice: ";
                int sub; if(!(std::cin>>sub)){ std::cin.clear(); std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n'); std::cout<<"Invalid\n"; continue;}
                if(sub==0) break;
                if(sub<1||sub>4){ std::cout<<"Invalid\n"; continue;}
                std::string tp=types[sub-1];
                int totalType=0; double sumAll=0.0;
                for(Node* n=list.getHead();n;n=n->next){
                    if(n->data.transaction_type==tp){ ++totalType; sumAll+=n->data.amount; }
                }
                std::cout<<"\nDisplaying first 100 of type: "<<tp<<"\n";
                auto x0=std::chrono::high_resolution_clock::now();
                int shown=0;
                for(Node* n=list.getHead();n&&shown<100;n=n->next){
                    if(n->data.transaction_type==tp){
                        ++shown;
                        const auto& d=n->data;
                        std::cout<<shown<<". ID:"<<d.transaction_id
                                  <<" | Channel:"<<d.payment_channel
                                  <<" | Location:"<<d.location
                                  <<" | Amount:"<<d.amount<<"\n";
                    }
                }
                auto x1=std::chrono::high_resolution_clock::now();
                double st=std::chrono::duration_cast<std::chrono::milliseconds>(x1-x0).count();
                std::cout<<"Displayed "<<shown<<" out of "<<totalType<<"\n";
                std::cout<<"Load time: "<<loadTimeMs<<" ms\n";
                std::cout<<"Search time: "<<st<<" ms\n";
                std::cout<<"Memory used: "<<memoryUsed<<" bytes\n";
                std::string fname=tp+"_total.json";
                std::ofstream out(fname);
                out<<"{\n  \"transaction_type\":\""<<tp<<"\","<<"\n  \"total_amount\": "<<sumAll<<"\n}\n";
                out.close();
                std::cout<<"Exported total amount to "<<fname<<"\n";
            }
            break;
        }
        default:
            std::cout<<"Invalid option; try again.\n";
        }
    }
    return 0;
}
