#ifndef DARMIK_TRANSACTION_HPP
#define DARMIK_TRANSACTION_HPP

#include <string>

namespace Darmik {

// POD‐style struct with inline constructors
struct Transaction {
    std::string transaction_id;
    std::string transaction_type;
    std::string payment_channel;
    std::string location;
    std::string is_fraud;
    double      amount;

    Transaction() : amount(0.0) {}
    Transaction(const std::string& id,
                const std::string& type,
                const std::string& channel,
                const std::string& loc,
                const std::string& fraud,
                double amt)
      : transaction_id(id),
        transaction_type(type),
        payment_channel(channel),
        location(loc),
        is_fraud(fraud),
        amount(amt) {}
};

} // namespace Darmik

#endif // DARMIK_TRANSACTION_HPP
