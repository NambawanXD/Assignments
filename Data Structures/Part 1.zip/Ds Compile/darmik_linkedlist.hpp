// File: darmik_linkedlist.hpp

#ifndef DARMIK_LINKEDLIST_HPP
#define DARMIK_LINKEDLIST_HPP

#include "darmik_transaction.hpp"
#include <iostream>
#include <string>
#include <cmath>

namespace Darmik {

struct Node {
    Transaction data;
    Node*       next;
    Node(const Transaction& t) : data(t), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;
    int   size;

    // Helpers for converting to/from array
    void toArray(Transaction* arr) const;
    void fromArray(Transaction* arr, int n);

    // Introsort routines
    void introsortUtil(Transaction* arr, int begin, int end,
                       int depthLimit,
                       bool (*cmp)(const Transaction&, const Transaction&));
    void heapSort(Transaction* arr, int n,
                  bool (*cmp)(const Transaction&, const Transaction&));
    void insertionSort(Transaction* arr, int n,
                       bool (*cmp)(const Transaction&, const Transaction&));

public:
    LinkedList();
    ~LinkedList();

    void insert(const Transaction& t);
    void clear();
    int  count() const;
    void displayFirst100() const;

    void sortByLocation();
    void sortByChannel();

    void searchByType(const std::string& type) const;
    void exportToJSON(const std::string& filename,
                      const std::string& filter) const;

    Node* getHead() const { return head; }
};

} // namespace Darmik

#endif // DARMIK_LINKEDLIST_HPP
