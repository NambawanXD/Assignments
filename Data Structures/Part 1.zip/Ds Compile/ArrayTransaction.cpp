#include "ArrayTransaction.hpp"

Transaction::Transaction()
    : amount(0.0),
      is_fraud(false),
      time_since_last_transaction(0.0),
      spending_deviation_score(0.0),
      velocity_score(0),
      geo_anomaly_score(0.0) {}
