// File: adam_main.cpp

#include "adam_loader.hpp"
#include "adam_linkedlist.hpp"
#include <iostream>
#include <chrono>
#include <limits>
#include <fstream>

using namespace Adam;

int adamMain() {
    LinkedList list;
    const std::string filename = "financial_fraud_detection_dataset.csv";
    bool dataLoaded = false;
    double loadTimeMs = 0.0;
    size_t memoryUsed = 0;
    const std::string channels[] = {"card", "ACH", "UPI", "wire_transfer"};
    const int channelCount = 4;
    const std::string types[] = {"withdrawal", "payment", "transfer", "deposit"};
    const int typeCount = 4;

    while (true) {
        std::cout << "\n--- Financial Transaction System Menu ---\n"
                  << "1) Load all transactions from CSV\n"
                  << "2) Display & export by each payment channel (sorted by location)\n"
                  << "3) Sort all transactions by location (ascending)\n"
                  << "4) Display & export by transaction type\n"
                  << "0) Back to Main Menu\n"
                  << "Select an option: ";

        int choice;
        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input; enter a number.\n";
            continue;
        }
        if (choice == 0) {
            break;
        }
        if (choice != 1 && !dataLoaded) {
            std::cout << "You must load data first (option 1).\n";
            continue;
        }

        switch (choice) {
        case 1: {
            // LOAD ONLY
            std::cout << "Loading all transactions from CSV...\n";
            auto t0 = std::chrono::high_resolution_clock::now();
            loadCSV(filename, list);
            auto t1 = std::chrono::high_resolution_clock::now();
            loadTimeMs = std::chrono::duration_cast<std::chrono::milliseconds>(t1 - t0).count();
            memoryUsed = list.count() * sizeof(Node);
            std::cout << "Load time: " << loadTimeMs << " ms\n";
            std::cout << "Memory used: " << memoryUsed << " bytes\n";
            dataLoaded = true;
            break;
        }

        case 2: {
            // DISPLAY & EXPORT BY EACH CHANNEL
            std::cout << "Display & export by each payment channel:\n";
            std::cout << "Load time: " << loadTimeMs << " ms\n";
            std::cout << "Memory used: " << memoryUsed << " bytes\n";
            for (int i = 0; i < channelCount; ++i) {
                const std::string& ch = channels[i];
                LinkedList sub;
                for (Node* n = list.getHead(); n; n = n->next)
                    if (n->data.payment_channel == ch)
                        sub.insert(n->data);
                int totalCh = sub.count();
                std::cout << "\nChannel: " << ch << " (total " << totalCh << ")\n";

                std::cout << "Sorting by location...\n";
                auto s0 = std::chrono::high_resolution_clock::now();
                sub.sortByLocation();
                auto s1 = std::chrono::high_resolution_clock::now();
                double dt = std::chrono::duration_cast<std::chrono::milliseconds>(s1 - s0).count();
                std::cout << "Sorted in " << dt << " ms\n";

                std::cout << "Displaying first 100 records:\n";
                sub.displayFirst100();
                int shown = totalCh < 100 ? totalCh : 100;
                std::cout << "Displayed " << shown << " out of " << totalCh << "\n";

                std::string fname = ch + "_by_location.json";
                std::cout << "Exporting all to " << fname << " ...\n";
                std::ofstream out(fname);
                out << "{\n  \"channel\": \"" << ch << "\",\n"
                    << "  \"transactions\": [\n";
                bool firstRec = true;
                for (Node* n = sub.getHead(); n; n = n->next) {
                    if (!firstRec) out << ",\n";
                    firstRec = false;
                    const Transaction& d = n->data;
                    out << "    {\"transaction_id\":\"" << d.transaction_id
                        << "\",\"transaction_type\":\"" << d.transaction_type
                        << "\",\"location\":\"" << d.location
                        << "\",\"amount\":" << d.amount << "}";
                }
                out << "\n  ]\n}\n";
                out.close();
                std::cout << "Exported " << totalCh << " records to " << fname << "\n";
            }
            break;
        }

        case 3: {
            // SORT ALL BY LOCATION
            std::cout << "Sorting all transactions by LOCATION...\n";
            auto s0 = std::chrono::high_resolution_clock::now();
            list.sortByLocation();
            auto s1 = std::chrono::high_resolution_clock::now();
            double sortMs = std::chrono::duration_cast<std::chrono::milliseconds>(s1 - s0).count();
            std::cout << "Sorted in " << sortMs << " ms\n";
            std::cout << "Load time: " << loadTimeMs << " ms\n";
            std::cout << "Memory used: " << memoryUsed << " bytes\n";
            std::cout << "Displaying first 100 records:\n";
            list.displayFirst100();

            int total = list.count();
            std::cout << "Exporting all to all_by_location.json\n";
            std::ofstream out("all_by_location.json");
            out << "{\n  \"transactions\": [\n";
            bool firstRec = true;
            for (Node* n = list.getHead(); n; n = n->next) {
                if (!firstRec) out << ",\n";
                firstRec = false;
                const Transaction& d = n->data;
                out << "    {\"transaction_id\":\"" << d.transaction_id
                    << "\",\"payment_channel\":\"" << d.payment_channel
                    << "\",\"location\":\"" << d.location
                    << "\",\"amount\":" << d.amount << "}";
            }
            out << "\n  ]\n}\n";
            out.close();
            std::cout << "Export complete\n";
            break;
        }

        case 4: {
            // DISPLAY & EXPORT BY TYPE
            while (true) {
                std::cout << "\nSelect transaction type:\n";
                for (int i = 0; i < typeCount; ++i)
                    std::cout << (i+1) << ") " << types[i] << "\n";
                std::cout << "0) Back\nChoice: ";
                int sub;
                if (!(std::cin >> sub)) {
                    std::cin.clear();
                    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                    std::cout << "Invalid input\n";
                    continue;
                }
                if (sub == 0) break;
                if (sub < 1 || sub > typeCount) {
                    std::cout << "Invalid choice\n";
                    continue;
                }
                std::string tp = types[sub - 1];

                // compute counts & sum
                int totalType = 0;
                double sumAll = 0.0;
                for (Node* n = list.getHead(); n; n = n->next) {
                    if (n->data.transaction_type == tp) {
                        ++totalType;
                        sumAll += n->data.amount;
                    }
                }

                // time and display first 100
                std::cout << "\nDisplaying first 100 of type: " << tp << "\n";
                auto s0t = std::chrono::high_resolution_clock::now();
                int shown = 0;
                for (Node* n = list.getHead(); n && shown < 100; n = n->next) {
                    if (n->data.transaction_type == tp) {
                        ++shown;
                        const Transaction& d = n->data;
                        std::cout << shown << ". ID: "       << d.transaction_id
                                  << " | Type: "           << d.transaction_type
                                  << " | Channel: "        << d.payment_channel
                                  << " | Location: "       << d.location
                                  << " | Amount: "         << d.amount
                                  << "\n";
                    }
                }
                auto s1t = std::chrono::high_resolution_clock::now();
                double searchTimeMs = std::chrono::duration_cast<std::chrono::milliseconds>(s1t - s0t).count();

                std::cout << "Displayed " << shown << " out of " << totalType << "\n";
                std::cout << "Load time: " << loadTimeMs << " ms\n";
                std::cout << "Search time: " << searchTimeMs << " ms\n";
                std::cout << "Memory used: " << memoryUsed << " bytes\n";

                // export total sum
                std::string fname = tp + "_total.json";
                std::ofstream out(fname);
                out << "{\n"
                    << "  \"transaction_type\": \"" << tp << "\",\n"
                    << "  \"total_amount\": " << sumAll << "\n"
                    << "}\n";
                out.close();
                std::cout << "Exported total amount to " << fname << "\n";
            }
            break;
        }

        default:
            std::cout << "Invalid option; try again.\n";
        }
    }

    return 0;
}
