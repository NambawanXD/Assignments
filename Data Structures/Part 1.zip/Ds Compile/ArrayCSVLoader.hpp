#ifndef ARRAY_CSV_LOADER_HPP
#define ARRAY_CSV_LOADER_HPP

#include "ArrayTransaction.hpp"
#include <string>

bool loadCSV(const std::string& filename, Transaction* transactions, int& count, int max);

bool loadCSVH(const std::string& filename, Transaction* transactions, int& count, int max);


#endif
