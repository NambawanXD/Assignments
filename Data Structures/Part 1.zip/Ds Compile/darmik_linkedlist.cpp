// File: darmik_linkedlist.cpp

#include "darmik_linkedlist.hpp"
#include <fstream>
#include <algorithm>

namespace Darmik {

LinkedList::LinkedList() : head(nullptr), size(0) {}
LinkedList::~LinkedList() { clear(); }

void LinkedList::insert(const Transaction& t) {
    Node* n = new Node(t);
    n->next = head;
    head = n;
    ++size;
}

void LinkedList::clear() {
    while (head) {
        Node* tmp = head;
        head = head->next;
        delete tmp;
    }
    size = 0;
}

int LinkedList::count() const { return size; }

void LinkedList::displayFirst100() const {
    Node* curr = head;
    int shown = 0;
    while (curr && shown < 100) {
        const auto& d = curr->data;
        std::cout << shown+1
                  << ". ID:"      << d.transaction_id
                  << " | Type:"   << d.transaction_type
                  << " | Channel:"<< d.payment_channel
                  << " | Location:"<< d.location
                  << " | Amount:" << d.amount
                  << "\n";
        curr = curr->next;
        ++shown;
    }
}

void LinkedList::toArray(Transaction* arr) const {
    Node* curr = head;
    for (int i = 0; i < size; ++i) {
        arr[i] = curr->data;
        curr = curr->next;
    }
}

void LinkedList::fromArray(Transaction* arr, int n) {
    clear();
    Node* tail = nullptr;
    for (int i = 0; i < n; ++i) {
        Node* node = new Node(arr[i]);
        if (!head) head = node;
        else        tail->next = node;
        tail = node;
    }
    size = n;
}

// comparators
static bool cmpLocation(const Transaction& a, const Transaction& b) {
    return a.location < b.location;
}
static bool cmpChannel(const Transaction& a, const Transaction& b) {
    return a.payment_channel < b.payment_channel;
}

void LinkedList::sortByLocation() {
    if (size < 2) return;
    Transaction* arr = new Transaction[size];
    toArray(arr);
    int depth = 2 * (int)std::log2(size);
    introsortUtil(arr, 0, size-1, depth, cmpLocation);
    fromArray(arr, size);
    delete[] arr;
}

void LinkedList::sortByChannel() {
    if (size < 2) return;
    Transaction* arr = new Transaction[size];
    toArray(arr);
    int depth = 2 * (int)std::log2(size);
    introsortUtil(arr, 0, size-1, depth, cmpChannel);
    fromArray(arr, size);
    delete[] arr;
}

void LinkedList::introsortUtil(Transaction* arr, int begin, int end,
                               int depthLimit,
                               bool (*cmp)(const Transaction&,const Transaction&)) {
    int n = end - begin + 1;
    if (n < 16) {
        insertionSort(arr + begin, n, cmp);
        return;
    }
    if (depthLimit == 0) {
        heapSort(arr + begin, n, cmp);
        return;
    }
    // median-of-three to pick pivot
    int mid = begin + n/2;
    if (cmp(arr[mid], arr[begin])) std::swap(arr[begin], arr[mid]);
    if (cmp(arr[end], arr[begin])) std::swap(arr[begin], arr[end]);
    if (cmp(arr[end], arr[mid]))   std::swap(arr[mid],   arr[end]);
    std::swap(arr[mid], arr[end]);
    Transaction pivot = arr[end];

    // partition
    int i = begin;
    for (int j = begin; j < end; ++j) {
        if (cmp(arr[j], pivot)) {
            std::swap(arr[i], arr[j]);
            ++i;
        }
    }
    std::swap(arr[i], arr[end]);
    introsortUtil(arr, begin, i-1, depthLimit-1, cmp);
    introsortUtil(arr, i+1, end,   depthLimit-1, cmp);
}

void LinkedList::heapSort(Transaction* arr, int n,
                          bool (*cmp)(const Transaction&,const Transaction&)) {
    auto heapify = [&](int root, int sz, auto&& self) -> void {
        int largest = root;
        int l = 2*root + 1, r = 2*root + 2;
        if (l < sz && cmp(arr[largest], arr[l])) largest = l;
        if (r < sz && cmp(arr[largest], arr[r])) largest = r;
        if (largest != root) {
            std::swap(arr[root], arr[largest]);
            self(largest, sz, self);
        }
    };
    for (int i = n/2 - 1; i >= 0; --i)
        heapify(i, n, heapify);
    for (int i = n-1; i > 0; --i) {
        std::swap(arr[0], arr[i]);
        heapify(0, i, heapify);
    }
}

void LinkedList::insertionSort(Transaction* arr, int n,
                               bool (*cmp)(const Transaction&,const Transaction&)) {
    for (int i = 1; i < n; ++i) {
        Transaction key = arr[i];
        int j = i-1;
        while (j >= 0 && cmp(key, arr[j])) {
            arr[j+1] = arr[j];
            --j;
        }
        arr[j+1] = key;
    }
}

void LinkedList::searchByType(const std::string& type) const {
    Node* curr = head;
    int count = 0;
    while (curr) {
        if (curr->data.transaction_type == type) {
            ++count;
            const auto& d = curr->data;
            std::cout << count << ". ID:" << d.transaction_id
                      << " | Channel:" << d.payment_channel
                      << " | Location:" << d.location
                      << " | Amount:" << d.amount << "\n";
        }
        curr = curr->next;
    }
}

void LinkedList::exportToJSON(const std::string& filename,
                              const std::string& filter) const {
    std::ofstream f(filename);
    f << "{\n  \"filter\": \"" << filter << "\",\n"
      << "  \"transactions\": [\n";
    Node* curr = head;
    bool first = true;
    while (curr) {
        const auto& d = curr->data;
        if (d.transaction_type == filter || d.payment_channel == filter) {
            if (!first) f << ",\n";
            first = false;
            f << "    {\"transaction_id\":\""   << d.transaction_id
              << "\",\"transaction_type\":\"" << d.transaction_type
              << "\",\"payment_channel\":\""  << d.payment_channel
              << "\",\"location\":\""         << d.location
              << "\",\"amount\":"             << d.amount
              << "}";
        }
        curr = curr->next;
    }
    f << "\n  ]\n}\n";
}

} // namespace Darmik
