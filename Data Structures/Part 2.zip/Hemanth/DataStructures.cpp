#include <iostream>
#include "DataStructures.hpp"
#include <cstring>
using namespace std;

// ===============================
// HemanthPriorityQueue
// ===============================
HemanthPriorityQueue::HemanthPriorityQueue() { size = 0; }

bool HemanthPriorityQueue::isEmpty() { return size == 0; }

void HemanthPriorityQueue::enqueue(Player p) {
    int i = size - 1;
    while (i >= 0 && data[i].ranking > p.ranking) {
        data[i + 1] = data[i];
        i--;
    }
    data[i + 1] = p;
    size++;
}

Player HemanthPriorityQueue::dequeue() {
    if (!isEmpty()) return data[--size];
    cout << "Queue Empty!\n";
    return Player();
}

void HemanthPriorityQueue::display() {
    cout << "Registered Players:\n";
    for (int i = 0; i < size; i++) data[i].print();
}

// ===============================
// HemanthMatchQueue
// ===============================
HemanthMatchQueue::HemanthMatchQueue() { front = rear = -1; }

bool HemanthMatchQueue::isEmpty() { return front == -1; }

void HemanthMatchQueue::enqueue(Player p) {
    if (rear == HEMANTH_MAX_PLAYERS - 1) {
        cout << "Match Queue Full!\n";
        return;
    }
    if (isEmpty()) front = 0;
    queue[++rear] = p;
}

Player HemanthMatchQueue::dequeue() {
    if (isEmpty()) return Player();
    Player temp = queue[front];
    (front == rear) ? front = rear = -1 : front++;
    return temp;
}

void HemanthMatchQueue::clear() { front = rear = -1; }

// ===============================
// HemanthStack
// ===============================
HemanthStack::HemanthStack() { top = -1; }

bool HemanthStack::isEmpty() { return top == -1; }

void HemanthStack::push(Player p) {
    if (top == HEMANTH_MAX_PLAYERS - 1) {
        cout << "Stack Overflow!\n";
        return;
    }
    stack[++top] = p;
}

Player HemanthStack::pop() {
    if (isEmpty()) return Player();
    return stack[top--];
}

Player HemanthStack::peek() { return (!isEmpty()) ? stack[top] : Player(); }

void HemanthStack::clear() { top = -1; }

void HemanthStack::display() {
    for (int i = top; i >= 0; i--) stack[i].print();
}

// ===============================
// HemanthCircularQueue
// ===============================
HemanthCircularQueue::HemanthCircularQueue() { front = rear = count = 0; }

bool HemanthCircularQueue::isEmpty() { return count == 0; }

bool HemanthCircularQueue::isFull() { return count == HEMANTH_MAX_PLAYERS; }

void HemanthCircularQueue::enqueue(Player p) {
    if (isFull()) return;
    cq[rear] = p;
    rear = (rear + 1) % HEMANTH_MAX_PLAYERS;
    count++;
}

Player HemanthCircularQueue::dequeue() {
    if (isEmpty()) return Player();
    Player temp = cq[front];
    front = (front + 1) % HEMANTH_MAX_PLAYERS;
    count--;
    return temp;
}

void HemanthCircularQueue::clear() { front = rear = count = 0; }

void HemanthCircularQueue::display() {
    int idx = front;
    for (int i = 0; i < count; i++) {
        cq[idx].print();
        idx = (idx + 1) % HEMANTH_MAX_PLAYERS;
    }
}
