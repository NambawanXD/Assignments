#ifndef PLAYER_HPP
#define PLAYER_HPP

class Player {
public:
    int id;
    char name[30];
    int ranking;

    Player();
    Player(int id, const char* name, int ranking);
    void print();
};

#endif
