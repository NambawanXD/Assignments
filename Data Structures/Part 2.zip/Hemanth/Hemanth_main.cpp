#include <iostream>
#include "MatchSystem.hpp"


using namespace std;

int runHemanthProgram() {
    HemanthMatchSystem system;
    int choice;

    while (true) {
        cout << "\n===== APUEC MATCH SYSTEM =====\n";
        cout << "[1] Load Players from File\n";
        cout << "[2] Show Registered Players\n";
        cout << "[3] Schedule Qualifier Matches\n";
        cout << "[4] Input Scores for Qualifiers\n";
        cout << "[5] Push Winners to Group Stage\n";
        cout << "[6] View Group Stage Players\n";
        cout << "[7] Input Scores for Knockout Rounds\n";
        cout << "[8] Export Match History\n";
        cout << "[0] Exit\n";
        cout << "Select: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                char filename[50];
                cout << "Enter file name (e.g., checked_in_players.txt): ";
                cin >> filename;
                system.loadPlayersFromFile(filename);
                break;
            }
            case 2: system.showRegisteredPlayers(); break;
            case 3: system.scheduleQualifiers(); break;
            case 4: system.simulateQualifierWinners(); break;
            case 5: system.pushToGroupStage(); break;
            case 6: system.viewGroupStage(); break;
            case 7: system.simulateKnockoutRounds(); break;
            case 8: {
                char outFile[50];
                cout << "Enter CSV filename to export (e.g., history.csv): ";
                cin >> outFile;
                system.exportMatchHistory(outFile);
                break;
            }
            case 0: return 0;
            default: cout << "Invalid option.\n";
        }
    }

    return 0;
}

int Hemanth_main() {
    return runHemanthProgram();
}