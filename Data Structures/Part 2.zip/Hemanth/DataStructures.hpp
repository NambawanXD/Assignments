#ifndef HEMANTH_DATA_STRUCTURES_HPP
#define HEMANTH_DATA_STRUCTURES_HPP

#include "Player.hpp"

const int HEMANTH_MAX_PLAYERS = 100;

class HemanthPriorityQueue {
    Player data[HEMANTH_MAX_PLAYERS];
    int size;
public:
    HemanthPriorityQueue();
    bool isEmpty();
    void enqueue(Player p);
    Player dequeue();
    void display();
};

class HemanthMatchQueue {
    Player queue[HEMANTH_MAX_PLAYERS];
    int front, rear;
public:
    HemanthMatchQueue();
    bool isEmpty();
    void enqueue(Player p);
    Player dequeue();
    void clear();
};

class HemanthStack {
public:
    Player stack[HEMANTH_MAX_PLAYERS];
    int top;
    HemanthStack();
    bool isEmpty();
    void push(Player p);
    Player pop();
    Player peek();
    void clear();
    void display();
};

class HemanthCircularQueue {
    Player cq[HEMANTH_MAX_PLAYERS];
    int front, rear, count;
public:
    HemanthCircularQueue();
    bool isEmpty();
    bool isFull();
    void enqueue(Player p);
    Player dequeue();
    void clear();
    void display();
};

#endif
