#include <iostream>
#include <cstring>
#include "Player.hpp"
using namespace std;

Player::Player() {
    id = ranking = 0;
    name[0] = '\0';
}

Player::Player(int id, const char* name, int ranking) {
    this->id = id;
    strcpy(this->name, name);
    this->ranking = ranking;
}

void Player::print() {
    cout << "[" << id << "] " << name << " (Rank: " << ranking << ")\n";
}
