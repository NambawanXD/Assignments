#ifndef HEMANTH_MATCH_SYSTEM_HPP
#define HEMANTH_MATCH_SYSTEM_HPP

#include "DataStructures.hpp"

struct HemanthMatchRecord {
    Player p1, p2, winner;
    int score1, score2;
    char roundLabel[30];
};

class HemanthMatchSystem {
    HemanthPriorityQueue registrationQueue;
    HemanthMatchQueue currentMatches;
    HemanthStack winnersStack;
    HemanthCircularQueue groupStage;
    HemanthMatchRecord matchHistory[200];
    int matchCount;
    int existingIDs[HEMANTH_MAX_PLAYERS];
    int idCount;

public:
    HemanthMatchSystem();

    bool isIDExists(int id);
    void addPlayer(int id, const char* name, int rank);
    void loadPlayersFromFile(const char* filename);
    void showRegisteredPlayers();
    void scheduleQualifiers();
    void simulateQualifierWinners();
    void pushToGroupStage();
    void viewGroupStage();
    void simulateKnockoutRounds();
    void exportMatchHistory(const char* filename);
};

#endif
