#include "MatchSystem.hpp"
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

HemanthMatchSystem::HemanthMatchSystem() {
    matchCount = 0;
    idCount = 0;
}

bool HemanthMatchSystem::isIDExists(int id) {
    for (int i = 0; i < idCount; i++)
        if (existingIDs[i] == id) return true;
    return false;
}

void HemanthMatchSystem::addPlayer(int id, const char* name, int rank) {
    if (id <= 0 || strlen(name) == 0 || rank <= 0 || isIDExists(id)) return;
    registrationQueue.enqueue(Player(id, name, rank));
    existingIDs[idCount++] = id;
}

void HemanthMatchSystem::loadPlayersFromFile(const char* filename) {
    ifstream file(filename);
    if (!file) {
        cout << "[Error] Cannot open file: " << filename << endl;
        return;
    }

    char line[100];
    file.getline(line, 100); // Skip header

    while (!file.eof()) {
        file.getline(line, 100);
        if (strlen(line) == 0) continue;

        int id, rank;
        char name[30];
        char* token = strtok(line, ",");
        if (token) id = atoi(token); else continue;
        token = strtok(NULL, ",");
        if (token) strcpy(name, token); else continue;
        token = strtok(NULL, ",");
        if (token) rank = atoi(token); else continue;

        if (!isIDExists(id))
            addPlayer(id, name, rank);
    }

    cout << "[Success] Players loaded from file.\n";
    file.close();
}

void HemanthMatchSystem::showRegisteredPlayers() {
    registrationQueue.display();
}

void HemanthMatchSystem::scheduleQualifiers() {
    cout << "\n[QUALIFIER MATCH PAIRINGS]\n";
    currentMatches.clear();

    while (!registrationQueue.isEmpty()) {
        Player p1 = registrationQueue.dequeue();
        Player p2 = registrationQueue.dequeue();

        if (strlen(p2.name) == 0) {
            cout << "Odd player auto-advances: ";
            p1.print();
            winnersStack.push(p1);
            break;
        }

        cout << "Match: ";
        p1.print(); cout << " VS "; p2.print(); cout << "\n";

        currentMatches.enqueue(p1);
        currentMatches.enqueue(p2);
    }
}

void HemanthMatchSystem::simulateQualifierWinners() {
    cout << "\n[QUALIFIER WINNERS BASED ON SCORES]\n";
    while (!currentMatches.isEmpty()) {
        Player p1 = currentMatches.dequeue();
        Player p2 = currentMatches.dequeue();

        int s1, s2;
        cout << "Match: " << p1.name << " vs " << p2.name << endl;
        cout << "Enter score for " << p1.name << ": ";
        cin >> s1;
        cout << "Enter score for " << p2.name << ": ";
        cin >> s2;

        Player winner = (s1 > s2) ? p1 : p2;
        cout << "Winner: ";
        winner.print();
        winnersStack.push(winner);

        HemanthMatchRecord rec = { p1, p2, winner, s1, s2 };
        strcpy(rec.roundLabel, "Qualifiers");
        matchHistory[matchCount++] = rec;
    }
}

void HemanthMatchSystem::pushToGroupStage() {
    cout << "\n[GROUP STAGE ENTRIES]\n";
    groupStage.clear();
    while (!winnersStack.isEmpty()) {
        Player p = winnersStack.pop();
        groupStage.enqueue(p);
        p.print();
    }
}

void HemanthMatchSystem::viewGroupStage() {
    cout << "\n[GROUP STAGE LIST]\n";
    groupStage.display();
}

void HemanthMatchSystem::simulateKnockoutRounds() {
    cout << "\n[KNOCKOUT STAGE - SCORE BASED]\n";

    HemanthCircularQueue currentRound;
    HemanthStack nextRound;
    while (!groupStage.isEmpty())
        currentRound.enqueue(groupStage.dequeue());

    const char* rounds[] = { "Round of 16", "Quarter-Finals", "Semi-Finals", "Final" };
    int round = 0;

    while (true) {
        cout << "\n[" << rounds[round] << "]\n";

        while (!currentRound.isEmpty()) {
            Player p1 = currentRound.dequeue();
            Player p2 = currentRound.dequeue();

            if (strlen(p2.name) == 0) {
                cout << "Auto-advance: ";
                p1.print();
                nextRound.push(p1);
                break;
            }

            int s1, s2;
            cout << "Match: " << p1.name << " vs " << p2.name << endl;
            cout << "Enter score for " << p1.name << ": ";
            cin >> s1;
            cout << "Enter score for " << p2.name << ": ";
            cin >> s2;

            Player winner = (s1 > s2) ? p1 : p2;
            cout << "Winner: ";
            winner.print();
            nextRound.push(winner);

            HemanthMatchRecord rec = { p1, p2, winner, s1, s2 };
            strcpy(rec.roundLabel, rounds[round]);
            matchHistory[matchCount++] = rec;
        }

        if (nextRound.top == 0) {
            cout << "\n🏆 FINAL WINNER: ";
            nextRound.peek().print();
            break;
        }

        while (!nextRound.isEmpty())
            currentRound.enqueue(nextRound.pop());

        if (round < 3) round++;
        else break;
    }
}

void HemanthMatchSystem::exportMatchHistory(const char* filename) {
    ofstream out(filename);
    if (!out) {
        cout << "[Error] Could not open file for writing.\n";
        return;
    }

    out << "Player1,Score1,Player2,Score2,Winner\n";
    char lastRound[30] = "";

    for (int i = 0; i < matchCount; i++) {
        if (strcmp(lastRound, matchHistory[i].roundLabel) != 0) {
            out << "(" << matchHistory[i].roundLabel << ")\n";
            strcpy(lastRound, matchHistory[i].roundLabel);
        }

        out << matchHistory[i].p1.name << "," << matchHistory[i].score1 << ","
            << matchHistory[i].p2.name << "," << matchHistory[i].score2 << ","
            << matchHistory[i].winner.name << "\n";
    }

    out.close();
    cout << "[Success] Match history exported to " << filename << endl;
}
