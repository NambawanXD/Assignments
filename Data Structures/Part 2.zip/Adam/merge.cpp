// merge.cpp
#include <iostream>
#include <fstream>
#include <cstring>
#include <limits>
#include <string>
#include "merge.hpp"
using namespace std;

// ────────────────────── Global Definitions ──────────────────────
int              nextPlayerID      = 1;
Queue            normalQueue;
PriorityQueue    priorityQueue;
CircularQueue    lastMinuteQueue;
Stack            withdrawalStack;

// ────────────────────── Helper: isRankTaken ──────────────────────
bool isRankTaken(int r) {
    bool taken = false;
    // scan priorityQueue
    PriorityQueue tmpPQ;
    while (!priorityQueue.isEmpty()) {
        Player p = priorityQueue.dequeue();
        if (p.rank == r) taken = true;
        tmpPQ.enqueue(p);
    }
    priorityQueue = tmpPQ;
    // scan normalQueue
    Queue tmpNQ;
    while (!normalQueue.isEmpty()) {
        Player p = normalQueue.dequeue();
        if (p.rank == r) taken = true;
        tmpNQ.enqueue(p);
    }
    normalQueue = tmpNQ;
    // scan lastMinuteQueue
    CircularQueue tmpCQ;
    while (!lastMinuteQueue.isEmpty()) {
        Player p = lastMinuteQueue.dequeue();
        if (p.rank == r) taken = true;
        tmpCQ.enqueue(p);
    }
    lastMinuteQueue = tmpCQ;
    return taken;
}

// ────────────────────── registerPlayer ──────────────────────
void registerPlayer() {
    Player newPlayer;
    newPlayer.id = nextPlayerID++;

    string line;
    // Name (non-empty)
    do {
        cout<<"\nEnter player name: ";
        getline(cin,line);
        if (line.empty()) cout<<"Name cannot be blank.\n";
    } while (line.empty());
    strncpy(newPlayer.name, line.c_str(), sizeof(newPlayer.name)-1);
    newPlayer.name[sizeof(newPlayer.name)-1] = '\0';

    // Rank (numeric & unique)
    int rankInput;
    while (true) {
        cout<<"Enter player rank: ";
        getline(cin,line);
        try { rankInput = stoi(line); }
        catch(...) { cout<<"Invalid number.\n"; continue; }
        if (isRankTaken(rankInput)) {
            cout<<"Rank "<<rankInput<<" already taken.\n";
            continue;
        }
        break;
    }
    newPlayer.rank = rankInput;

    // Entry Type (1–3)
    int typeChoice;
    while (true) {
        cout<<"\nFilter by Entry Type: \n";
        cout<<"1.Early-Bird\n";
        cout<<"2.Wildcard\n";
        cout<<"3.Normal\n";
        cout<<"Select (1-3): ";
        getline(cin,line);
        try { typeChoice = stoi(line); }
        catch(...) { cout<<"Invalid choice.\n"; continue; }
        if (typeChoice<1||typeChoice>3) { cout<<"Enter 1,2,or 3.\n"; continue; }
        break;
    }
    newPlayer.entryType = EntryType(typeChoice);
    newPlayer.status = REGISTERED;
    newPlayer.note[0] = '\0';

    // Enqueue
    if (newPlayer.entryType == NORMAL) {
        // last-minute? (y/n)
        char yn;
        while (true) {
            cout<<"Is this a last-minute entry? (y/n): ";
            getline(cin,line);
            if (line.size()==1 && (line[0]=='y'||line[0]=='Y'||line[0]=='n'||line[0]=='N')) {
                yn=line[0]; break;
            }
            cout<<"Please enter 'y' or 'n'.\n";
        }
        if (yn=='y'||yn=='Y') {
            lastMinuteQueue.enqueue(newPlayer);
            cout<<"Added to last-minute queue.\n";
        } else {
            normalQueue.enqueue(newPlayer);
            cout<<"Added to normal queue.\n";
        }
    } else {
        priorityQueue.enqueue(newPlayer);
        cout<<"Added to priority queue.\n";
    }
}

// ────────────────────── withdrawPlayer ──────────────────────
void withdrawPlayer() {
    string line; int targetID;
    while (true) {
        cout<<"\nEnter Player ID to withdraw: ";
        getline(cin,line);
        try { targetID = stoi(line); break; }
        catch(...) { cout<<"Invalid input. Numeric only.\n"; }
    }

    bool found=false;
    // priorityQueue
    PriorityQueue tmpPQ;
    while(!priorityQueue.isEmpty()) {
        Player p=priorityQueue.dequeue();
        if(p.id==targetID) { p.status=WITHDRAWN; withdrawalStack.push(p); found=true; }
        else tmpPQ.enqueue(p);
    }
    priorityQueue=tmpPQ;
    if(found) { cout<<"Withdrawn from priority queue.\n"; return; }

    // normalQueue
    Queue tmpNQ;
    while(!normalQueue.isEmpty()) {
        Player p=normalQueue.dequeue();
        if(p.id==targetID) { p.status=WITHDRAWN; withdrawalStack.push(p); found=true; }
        else tmpNQ.enqueue(p);
    }
    normalQueue=tmpNQ;
    if(found) { cout<<"Withdrawn from normal queue.\n"; return; }

    // circularQueue
    CircularQueue tmpCQ;
    while(!lastMinuteQueue.isEmpty()) {
        Player p=lastMinuteQueue.dequeue();
        if(p.id==targetID) { p.status=WITHDRAWN; withdrawalStack.push(p); found=true; }
        else tmpCQ.enqueue(p);
    }
    lastMinuteQueue=tmpCQ;
    if(found) { cout<<"Withdrawn from last-minute queue.\n"; }
    else     { cout<<"Player ID "<<targetID<<" not found.\n"; }
}

// ────────────────────── undoLastWithdrawal ──────────────────────
void undoLastWithdrawal() {
    if (withdrawalStack.isEmpty()) {
        cout<<"No withdrawals to undo.\n"; return;
    }
    Player p = withdrawalStack.pop();
    p.status = REGISTERED;
    if (p.entryType == NORMAL) normalQueue.enqueue(p);
    else                        priorityQueue.enqueue(p);
    cout<<"Restored "<<p.name<<" to ";
    cout<<(p.entryType==NORMAL?"normal":"priority")<<" queue.\n";
}

// ────────────────────── checkInPlayer ──────────────────────
void checkInPlayer() {
    string line; int targetID;
    while (true) {
        cout<<"\nEnter Player ID to check-in: ";
        getline(cin,line);
        try { targetID=stoi(line); break; }
        catch(...) { cout<<"Invalid input. Numeric only.\n"; }
    }

    bool found=false;
    // priorityQueue
    PriorityQueue tmpPQ;
    while(!priorityQueue.isEmpty()) {
        Player p=priorityQueue.dequeue();
        if(p.id==targetID) { p.status=CHECKED_IN; cout<<"Checked in (priority).\n"; found=true; }
        tmpPQ.enqueue(p);
    }
    priorityQueue=tmpPQ;
    if(found) return;

    // normalQueue
    Queue tmpNQ;
    while(!normalQueue.isEmpty()) {
        Player p=normalQueue.dequeue();
        if(p.id==targetID) { p.status=CHECKED_IN; cout<<"Checked in (normal).\n"; found=true; }
        tmpNQ.enqueue(p);
    }
    normalQueue=tmpNQ;
    if(found) return;

    // circularQueue
    CircularQueue tmpCQ;
    while(!lastMinuteQueue.isEmpty()) {
        Player p=lastMinuteQueue.dequeue();
        if(p.id==targetID) { p.status=CHECKED_IN; cout<<"Checked in (last-minute).\n"; found=true; }
        tmpCQ.enqueue(p);
    }
    lastMinuteQueue=tmpCQ;
    if(!found) cout<<"Player ID not found.\n";
}

// ────────────────────── displayAllQueues ──────────────────────
void displayAllQueues() {
    cout<<"\n--- Priority Queue ---\n";    priorityQueue.display();
    cout<<"\n--- Normal Queue ---\n";      normalQueue.display();
    cout<<"\n--- Last-Minute Queue ---\n"; lastMinuteQueue.display();
}

// ────────────────────── viewAllRegisteredPlayers ──────────────────────
void viewAllRegisteredPlayers() {
    cout<<"\n=== All Registered Players ===\n";
    // priorityQueue
    PriorityQueue tmpPQ;
    while(!priorityQueue.isEmpty()) {
        Player p=priorityQueue.dequeue();
        cout<<"["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<")\n";
        tmpPQ.enqueue(p);
    }
    priorityQueue = tmpPQ;
    // normalQueue
    Queue tmpNQ;
    while(!normalQueue.isEmpty()) {
        Player p=normalQueue.dequeue();
        cout<<"["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<")\n";
        tmpNQ.enqueue(p);
    }
    normalQueue = tmpNQ;
    // circularQueue
    CircularQueue tmpCQ;
    while(!lastMinuteQueue.isEmpty()) {
        Player p=lastMinuteQueue.dequeue();
        cout<<"["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<")\n";
        tmpCQ.enqueue(p);
    }
    lastMinuteQueue = tmpCQ;
}

// ────────────────────── showStatsDashboard ──────────────────────
void showStatsDashboard() {
    int reg=0, cinCount=0, wd=0;
    auto scan = [&](auto &q){
        auto tmp = q;
        while(!tmp.isEmpty()) {
            Player p=tmp.dequeue();
            if(p.status==REGISTERED) reg++;
            else if(p.status==CHECKED_IN) cinCount++;
            else if(p.status==WITHDRAWN) wd++;
        }
    };
    scan(priorityQueue); scan(normalQueue); scan(lastMinuteQueue);
    cout<<"\n==== Stats Dashboard ====\n"
        <<"Registered Players: "<<reg<<"\n"
        <<"Checked-In Players: "<<cinCount<<"\n"
        <<"Withdrawn (Removed from Queue): "<<withdrawalStack.getSize()<<"\n"
        <<"Current in Priority Queue: "<<priorityQueue.getSize()<<"\n"
        <<"Current in Normal Queue:   "<<normalQueue.getSize()<<"\n"
        <<"Current in Last-Minute Queue: "<<lastMinuteQueue.getSize()<<"\n";
}

// ────────────────────── exportCheckInList ──────────────────────
void exportCheckInList() {
    ofstream file("checked_in_players.txt");
    if (!file) { cout<<"Failed to open export file.\n"; return; }
    file<<"ID,Name,Rank,Entry Type,Note\n";
    auto exportQ = [&](auto &q){
        auto tmp=q;
        while(!tmp.isEmpty()) {
            Player p=tmp.dequeue();
            if(p.status==CHECKED_IN) {
                file<<p.id<<","<<p.name<<","<<p.rank<<","
                    <<(p.entryType==EARLY_BIRD?"Early-Bird":p.entryType==WILDCARD?"Wildcard":"Normal")
                    <<","<<p.note<<"\n";
            }
        }
    };
    exportQ(priorityQueue);
    exportQ(normalQueue);
    exportQ(lastMinuteQueue);
    cout<<"Exported checked-in list.\n";
}

// ────────────────────── filterByEntryType ──────────────────────
void filterByEntryType() {
    string line; int choice;
    while(true){
        cout<<"\nFilter by Entry Type:";
        cout<<"\n1.Early-Bird ";
        cout<<"\n2.Wildcard";
        cout<<"\n3.Normal";
        cout<<"\nSelect (1-3): ";
        getline(cin,line);
        try{ choice=stoi(line);} catch(...){ cout<<"Enter 1,2 or 3.\n"; continue;}
        if(choice<1||choice>3){cout<<"Enter 1,2 or 3.\n"; continue;}
        break;
    }
    EntryType t = EntryType(choice);
    cout<<"\n--- Filter Results ---\n";
    auto scan=[&](auto &q){
        auto tmp=q;
        while(!tmp.isEmpty()){
            Player p=tmp.dequeue();
            if(p.entryType==t)
                cout<<"["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<") | Status: "
                    <<(p.status==REGISTERED?"Registered":p.status==CHECKED_IN?"In":"Wildcard")
                    <<"\n";
        }
    };
    scan(priorityQueue); scan(normalQueue); scan(lastMinuteQueue);
}

// ────────────────────── addNoteToPlayer ──────────────────────
void addNoteToPlayer() {
    string line; int targetID;
    while(true){
        cout<<"\nEnter Player ID to add note: ";
        getline(cin,line);
        try{ targetID=stoi(line);} catch(...){ cout<<"Invalid ID.\n"; continue;}
        break;
    }
    bool found=false;
    auto noteHelper=[&](Player &p){
        do{
            cout<<"Enter note for '"<<p.name<<"': ";
            getline(cin,line);
            if(line.empty()) cout<<"Note cannot be blank.\n";
        }while(line.empty());
        strncpy(p.note,line.c_str(),sizeof(p.note)-1);
        p.note[sizeof(p.note)-1]='\0';
        cout<<"Note added.\n";
        found=true;
    };
    // scan all three
    PriorityQueue tp1;
    while(!priorityQueue.isEmpty()){
        Player p=priorityQueue.dequeue();
        if(p.id==targetID) noteHelper(p);
        tp1.enqueue(p);
    }
    priorityQueue=tp1;
    if(found) return;
    Queue tq2;
    while(!normalQueue.isEmpty()){
        Player p=normalQueue.dequeue();
        if(p.id==targetID) noteHelper(p);
        tq2.enqueue(p);
    }
    normalQueue=tq2;
    if(found) return;
    CircularQueue tc3;
    while(!lastMinuteQueue.isEmpty()){
        Player p=lastMinuteQueue.dequeue();
        if(p.id==targetID) noteHelper(p);
        tc3.enqueue(p);
    }
    lastMinuteQueue=tc3;
    if(!found) cout<<"Player ID not found.\n";
}

// ────────────────────── simulateTournamentStart ──────────────────────
void simulateTournamentStart() {
    cout<<"\n=== Tournament Start List ===\n";
    auto scan=[&](auto &q,const string &name){
        auto tmp=q;
        cout<<"["<<name<<"]\n";
        while(!tmp.isEmpty()){
            Player p=tmp.dequeue();
            if(p.status==CHECKED_IN)
                cout<<p.id<<": "<<p.name<<" (Rank "<<p.rank<<")\n";
        }
    };
    scan(priorityQueue,"Priority");
    scan(normalQueue,  "Normal");
    scan(lastMinuteQueue,"Last-Minute");
}

// ────────────────────── searchPlayer ──────────────────────
void searchPlayer() {
    string line; int mode;
    while(true){
        cout<<"\nSearch by:";
        cout<<"\n1.ID ";
        cout<<"\n2.Name ";
        cout<<"\nEnter your choice: ";
        getline(cin,line);
        try{ mode=stoi(line);} catch(...){ cout<<"Enter 1 or 2.\n"; continue;}
        if(mode!=1 && mode!=2){ cout<<"Enter 1 or 2.\n"; continue; }
        break;
    }
    int targetID=-1; string targetName;
    if(mode==1){
        while(true){
            cout<<"Enter Player ID: ";
            getline(cin,line);
            try{ targetID=stoi(line); break; }
            catch(...){ cout<<"Invalid ID.\n"; }
        }
    } else {
        do {
            cout<<"Enter Player Name: ";
            getline(cin,targetName);
            if(targetName.empty()) cout<<"Name cannot be blank.\n";
        } while(targetName.empty());
    }
    bool found=false;
    auto scan=[&](auto &q,const string &qn){
        auto tmp=q;
        while(!tmp.isEmpty()){
            Player p=tmp.dequeue();
            if((mode==1 && p.id==targetID) ||
               (mode==2 && targetName==p.name)) {
                cout<<"Found in "<<qn<<": ["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<")\n";
                found=true;
            }
        }
    };
    scan(priorityQueue,"Priority Queue");
    scan(normalQueue,  "Normal Queue");
    scan(lastMinuteQueue,"Last-Minute Queue");
    if(!found) cout<<"No matching player found.\n";
}
