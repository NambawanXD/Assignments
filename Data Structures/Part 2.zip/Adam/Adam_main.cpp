// Adam_main.cpp
#include <iostream>
#include <string>
#include <cstdlib>
#include <cstring>
#include <limits>
#include "merge.hpp"
using namespace std;

// externs link to the globals defined in merge.cpp
extern int           nextPlayerID;
extern Queue         normalQueue;
extern PriorityQueue priorityQueue;
extern CircularQueue lastMinuteQueue;
extern Stack         withdrawalStack;

void showMainMenu() {
    cout << "\n==== Tournament Registration & Player Queueing ====\n"
         << "1.  Register Player\n"
         << "2.  Withdraw Player\n"
         << "3.  Check-In Player\n"
         << "4.  View All Queues\n"
         << "5.  Undo Last Withdrawal\n"
         << "6.  Show Stats Dashboard\n"
         << "7.  Export Check-In List to File\n"
         << "8.  Filter Players by Entry Type\n"
         << "9.  Add Note to Player\n"
         << "10. Simulate Tournament Start\n"
         << "11. View All Registered Players\n"
         << "12. Search Player by ID or Name\n"
         << "0.  Exit\n"
         << "Select an option: ";
}

int runAdamProgram() {
    while (true) {
        showMainMenu();
        string line;
        getline(cin, line);

        int choice;
        try {
            choice = stoi(line);
        } catch (...) {
            cout << "Invalid input. Please enter a number between 0 and 12.\n\n";
            continue;
        }
        if (choice < 0 || choice > 12) {
            cout << "Invalid input. Please enter a number between 0 and 12.\n\n";
            continue;
        }

        switch (choice) {
            case 1:  registerPlayer();           break;
            case 2:  withdrawPlayer();           break;
            case 3:  checkInPlayer();            break;
            case 4:  displayAllQueues();         break;
            case 5:  undoLastWithdrawal();       break;
            case 6:  showStatsDashboard();       break;
            case 7:  exportCheckInList();        break;
            case 8:  filterByEntryType();        break;
            case 9:  addNoteToPlayer();          break;
            case 10: simulateTournamentStart();   break;
            case 11: viewAllRegisteredPlayers(); break;
            case 12: searchPlayer();             break;
            case 0:
                cout << "Exiting system...\n";
                return 0;
        }
        cout << "\n";  // blank line before menu
    }
}

int Adam_main() {
    return runAdamProgram();
}
