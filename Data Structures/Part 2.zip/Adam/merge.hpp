// merge.hpp
#ifndef ALL_STRUCTURES_HPP
#define ALL_STRUCTURES_HPP

#include <iostream>
#include <cstring>
#include <string>

enum EntryType { EARLY_BIRD = 1, WILDCARD = 2, NORMAL = 3 };
enum Status    { REGISTERED, CHECKED_IN, WITHDRAWN };

struct Player {
    int        id;
    char       name[50];
    int        rank;
    EntryType  entryType;
    Status     status;
    char       note[100];
};

// ─────────────────────────────────────────────────────────────────
//   QUEUE
// ─────────────────────────────────────────────────────────────────
const int MAX_QUEUE_SIZE = 100;
class Queue {
private:
    Player queue[MAX_QUEUE_SIZE];
    int front, rear;
public:
    Queue(): front(0), rear(-1) {}
    bool isEmpty() const { return front > rear; }
    bool isFull()  const { return rear  == MAX_QUEUE_SIZE - 1; }
    bool enqueue(const Player& p) {
        if (isFull()) {
            std::cout << "Normal queue is full.\n";
            return false;
        }
        queue[++rear] = p;
        return true;
    }
    Player dequeue() {
        Player dummy = {-1,"",0,NORMAL,REGISTERED,""};
        if (isEmpty()) { std::cout << "Normal queue empty.\n"; return dummy; }
        return queue[front++];
    }
    void display() const {
        if (isEmpty()) { std::cout << "Queue is empty.\n"; return; }
        for (int i = front; i <= rear; i++) {
            const Player& p = queue[i];
            std::cout << "["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<") - ";
            switch(p.entryType){
              case EARLY_BIRD: std::cout<<"Early-Bird"; break;
              case WILDCARD:   std::cout<<"Wildcard";   break;
              case NORMAL:     std::cout<<"Normal";     break;
            }
            std::cout<<" | Status: ";
            switch(p.status){
              case REGISTERED: std::cout<<"Registered"; break;
              case CHECKED_IN: std::cout<<"Checked-In"; break;
              case WITHDRAWN:  std::cout<<"Withdrawn";  break;
            }
            std::cout<<" | Note: "<<p.note<<"\n";
        }
    }
    int getSize() const { return rear - front + 1; }
};

// ─────────────────────────────────────────────────────────────────
//   PRIORITY QUEUE
// ─────────────────────────────────────────────────────────────────
const int MAX_PRIORITY_SIZE = 100;
class PriorityQueue {
private:
    Player queue[MAX_PRIORITY_SIZE];
    int    size;
    int getPriority(const Player& p) const { return static_cast<int>(p.entryType); }
public:
    PriorityQueue(): size(0) {}
    bool isEmpty() const { return size == 0; }
    bool isFull()  const { return size == MAX_PRIORITY_SIZE; }
    bool enqueue(const Player& p) {
        if (isFull()) {
            std::cout << "Priority queue is full.\n";
            return false;
        }
        int pr = getPriority(p), i = size-1;
        for (; i>=0 && getPriority(queue[i]) > pr; i--)
            queue[i+1] = queue[i];
        queue[i+1] = p;
        size++;
        return true;
    }
    Player dequeue() {
        Player dummy = {-1,"",0,NORMAL,REGISTERED,""};
        if (isEmpty()) { std::cout << "Priority queue empty.\n"; return dummy; }
        return queue[--size];
    }
    void display() const {
        if (isEmpty()) { std::cout<<"Priority queue empty.\n"; return; }
        std::cout<<"Priority Queue (Early-Bird > Wildcard > Normal):\n";
        for (int i=size-1; i>=0; i--) {
            const Player& p = queue[i];
            std::cout << "["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<") - ";
            switch(p.entryType){
              case EARLY_BIRD: std::cout<<"Early-Bird"; break;
              case WILDCARD:   std::cout<<"Wildcard";   break;
              case NORMAL:     std::cout<<"Normal";     break;
            }
            std::cout<<" | Status: ";
            switch(p.status){
              case REGISTERED: std::cout<<"Registered"; break;
              case CHECKED_IN: std::cout<<"Checked-In"; break;
              case WITHDRAWN:  std::cout<<"Withdrawn";  break;
            }
            std::cout<<" | Note: "<<p.note<<"\n";
        }
    }
    int getSize() const { return size; }
};

// ─────────────────────────────────────────────────────────────────
//   CIRCULAR QUEUE
// ─────────────────────────────────────────────────────────────────
const int MAX_CIRCULAR_SIZE = 100;
class CircularQueue {
private:
    Player queue[MAX_CIRCULAR_SIZE];
    int    front, rear, count;
public:
    CircularQueue(): front(0), rear(-1), count(0) {}
    bool isEmpty() const { return count == 0; }
    bool isFull()  const { return count == MAX_CIRCULAR_SIZE; }
    bool enqueue(const Player& p) {
        if (isFull()) {
            std::cout<<"Circular queue full.\n"; return false;
        }
        rear = (rear+1) % MAX_CIRCULAR_SIZE;
        queue[rear] = p; count++;
        return true;
    }
    Player dequeue() {
        Player dummy = {-1,"",0,NORMAL,REGISTERED,""};
        if (isEmpty()) { std::cout<<"Circular queue empty.\n"; return dummy;}
        Player p = queue[front];
        front = (front+1)%MAX_CIRCULAR_SIZE; count--;
        return p;
    }
    void display() const {
        if (isEmpty()) { std::cout<<"Circular queue empty.\n"; return; }
        std::cout<<"Last-minute entries:\n";
        int idx = front;
        for (int i=0; i<count; i++, idx=(idx+1)%MAX_CIRCULAR_SIZE) {
            const Player& p = queue[idx];
            std::cout<<"["<<p.id<<"] "<<p.name<<" (Rank "<<p.rank<<") - ";
            switch(p.entryType){
              case EARLY_BIRD: std::cout<<"Early-Bird"; break;
              case WILDCARD:   std::cout<<"Wildcard";   break;
              case NORMAL:     std::cout<<"Normal";     break;
            }
            std::cout<<" | Status: ";
            switch(p.status){
              case REGISTERED: std::cout<<"Registered"; break;
              case CHECKED_IN: std::cout<<"Checked-In"; break;
              case WITHDRAWN:  std::cout<<"Withdrawn";  break;
            }
            std::cout<<" | Note: "<<p.note<<"\n";
        }
    }
    int getSize() const { return count; }
};

// ─────────────────────────────────────────────────────────────────
//   STACK
// ─────────────────────────────────────────────────────────────────
const int MAX_STACK_SIZE = 100;
class Stack {
private:
    Player stack[MAX_STACK_SIZE];
    int    top;
public:
    Stack(): top(-1) {}
    bool isEmpty() const { return top == -1; }
    bool isFull()  const { return top == MAX_STACK_SIZE-1; }
    bool push(const Player& p) {
        if (isFull()) { std::cout<<"Stack full.\n"; return false; }
        stack[++top] = p; return true;
    }
    Player pop() {
        Player dummy={-1,"",0,NORMAL,REGISTERED,""};
        if (isEmpty()) { std::cout<<"Stack empty.\n"; return dummy; }
        return stack[top--];
    }
    int getSize() const { return top+1; }
    void display() const {
        if (isEmpty()) { std::cout<<"Stack empty.\n"; return; }
        std::cout<<"Withdrawn (stack):\n";
        for (int i=top; i>=0; i--) {
            const Player& p = stack[i];
            std::cout<<"["<<p.id<<"] "<<p.name<<" | Status: Withdrawn\n";
        }
    }
};

// ─────────────────────────────────────────────────────────────────
//   FUNCTION DECLARATIONS
// ─────────────────────────────────────────────────────────────────
void registerPlayer();
void withdrawPlayer();
void undoLastWithdrawal();
void checkInPlayer();
void displayAllQueues();
void viewAllRegisteredPlayers();
void showStatsDashboard();
void exportCheckInList();
void filterByEntryType();
void addNoteToPlayer();
void simulateTournamentStart();
void searchPlayer();

#endif // ALL_STRUCTURES_HPP
