#include "Anusha.hpp"

int runAnushaProgram() {
    GameLogger logger;
    int choice;
    string playerName;

    do {
        cout << "\n===== Game Result Logging Menu =====\n";
        cout << "1. Log Match Result\n";
        cout << "2. View Recent Matches\n";
        cout << "3. View Player Stats\n";
        cout << "4. Show Top Players\n";
        cout << "0. Exit\nChoice: ";
        cin >> choice; cin.ignore();

        switch (choice) {
            case 1: logger.logMatch(); break;
            case 2: logger.viewRecentMatches(); break;
            case 3:
                cout << "Enter player name: ";
                getline(cin, playerName);
                logger.viewPlayerStats(playerName);
                break;
            case 4: logger.showTopPlayers(); break;
        }
    } while (choice != 0);

    return 0;
}

int Anusha_main() {
    return runAnushaProgram();
}
