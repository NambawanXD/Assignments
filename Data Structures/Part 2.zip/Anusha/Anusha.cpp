#include "Anusha.hpp"

void GameLogger::logMatch() {
    Match m;
    cout << "Enter Player 1: ";
    getline(cin, m.player1);
    cout << "Enter Score 1: ";
    cin >> m.score1; cin.ignore();
    cout << "Enter Player 2: ";
    getline(cin, m.player2);
    cout << "Enter Score 2: ";
    cin >> m.score2; cin.ignore();
    cout << "Enter Stage (Qualifier/Group/Knockout): ";
    getline(cin, m.stage);

    m.winner = (m.score1 > m.score2) ? m.player1 : m.player2;

    // Maintain recent match queue (circular behavior)
    if (recentMatches.size() == MAX_RECENT)
        recentMatches.pop_front();
    recentMatches.push_back(m);

    // Ensure both players are initialized in histories
    if (histories.find(m.player1) == histories.end())
        histories[m.player1].name = m.player1;
    if (histories.find(m.player2) == histories.end())
        histories[m.player2].name = m.player2;

    // Update player history
    histories[m.player1].matches.push_back(m);
    histories[m.player2].matches.push_back(m);

    // Track win count
    winCount[m.winner]++;

    cout << "Match logged successfully. Winner: " << m.winner << endl;
}

void GameLogger::viewRecentMatches() {
    cout << "\n--- Recent Matches (Last 10) ---\n";
    int i = 1;
    for (const auto& m : recentMatches) {
        cout << i++ << ". " << m.player1 << " (" << m.score1 << ") vs "
             << m.player2 << " (" << m.score2 << ") | Stage: " << m.stage
             << " | Winner: " << m.winner << endl;
    }
}

void GameLogger::viewPlayerStats(const string& name) {
    if (histories.find(name) == histories.end()) {
        cout << "No match history found for " << name << endl;
        return;
    }

    PlayerHistory& ph = histories[name];
    cout << "\n--- Match History for " << name << " ---\n";
    for (const auto& m : ph.matches) {
        cout << m.player1 << " (" << m.score1 << ") vs " << m.player2
             << " (" << m.score2 << ") | Stage: " << m.stage
             << " | Winner: " << m.winner << endl;
    }
}

void GameLogger::showTopPlayers() {
    cout << "\n--- Top Players by Wins ---\n";
    priority_queue<pair<int, string>> pq;

    for (const auto& entry : winCount)
        pq.push({entry.second, entry.first});

    int rank = 1;
    while (!pq.empty()) {
        auto [wins, name] = pq.top(); pq.pop();
        cout << rank++ << ". " << name << " with " << wins << " wins\n";
    }
}
