#ifndef TASK4_HPP
#define TASK4_HPP

#include <iostream>
#include <deque>
#include <map>
#include <vector>
#include <string>

using namespace std;

struct Match {
    string player1;
    string player2;
    string winner;
    int score1;
    int score2;
    string stage;
};

struct PlayerHistory {
    string name;
    vector<Match> matches;
};

class GameLogger {
private:
    deque<Match> recentMatches;           // Fixed-size recent match log
    const size_t MAX_RECENT = 10;
    map<string, PlayerHistory> histories; // Player-wise match history
    map<string, int> winCount;            // For tracking player wins

public:
    void logMatch();
    void viewRecentMatches();
    void viewPlayerStats(const string& name);
    void showTopPlayers();
};

#endif

