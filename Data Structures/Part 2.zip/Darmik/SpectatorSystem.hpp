#ifndef SPECTATOR_SYSTEM_HPP
#define SPECTATOR_SYSTEM_HPP

#include <iostream>
#include <queue>
#include <stack>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

struct Spectator {
    string name;
    int priority; // Higher value = higher priority (VIP > Influencer > General)
    Spectator(string n, int p) : name(n), priority(p) {}
};

// Priority comparator for VIP seating
struct ComparePriority {
    bool operator()(Spectator const& a, Spectator const& b) {
        return a.priority < b.priority;
    }
};

class SpectatorSystem {
private:
    queue<string> generalQueue;                // Normal spectators
    stack<string> streamerStack;               // Live streaming setup stack
    priority_queue<Spectator, vector<Spectator>, ComparePriority> vipQueue; // VIP priority
    vector<string> circularQueue;              // Circular queue storage
    int cqFront, cqRear, cqSize, cqCapacity;

public:
    SpectatorSystem(int cqCap);

    // Queue operations
    void addGeneralSpectator(string name);
    void serveGeneralSpectator();

    // Stack operations
    void addStreamer(string name);
    void removeStreamer();

    // Priority queue operations
    void addVIP(string name, int priority);
    void serveVIP();

    // Circular queue operations
    void addOverflowSpectator(string name);
    void serveOverflowSpectator();

    // Display methods
    void displayGeneralQueue();
    void displayStreamerStack();
    void displayVIPQueue();
    void displayOverflowQueue();
};

#endif
