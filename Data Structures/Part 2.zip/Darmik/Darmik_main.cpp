#include "SpectatorSystem.hpp"

int runDarmikProgram() {
    SpectatorSystem system(5); // Circular queue capacity = 5
    int choice;
    string name;
    int priority;

    do {
        cout << "\n--- APUEC Live Stream & Spectator Management ---\n";
        cout << "1. Add General Spectator\n2. Serve General Spectator\n";
        cout << "3. Add Streamer\n4. Remove Streamer\n";
        cout << "5. Add VIP\n6. Serve VIP\n";
        cout << "7. Add Overflow Spectator\n8. Serve Overflow Spectator\n";
        cout << "9. Display All Queues\n0. Exit\nChoose: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter spectator name: "; cin >> name;
            system.addGeneralSpectator(name); break;
        case 2:
            system.serveGeneralSpectator(); break;
        case 3:
            cout << "Enter streamer name: "; cin >> name;
            system.addStreamer(name); break;
        case 4:
            system.removeStreamer(); break;
        case 5:
            cout << "Enter VIP name: "; cin >> name;
            cout << "Enter priority (1=Low, 5=High): "; cin >> priority;
            system.addVIP(name, priority); break;
        case 6:
            system.serveVIP(); break;
        case 7:
            cout << "Enter overflow spectator name: "; cin >> name;
            system.addOverflowSpectator(name); break;
        case 8:
            system.serveOverflowSpectator(); break;
        case 9:
            system.displayGeneralQueue();
            system.displayStreamerStack();
            system.displayVIPQueue();
            system.displayOverflowQueue();
            break;
        case 0:
            cout << "Exiting...\n"; break;
        default:
            cout << "Invalid choice!\n";
        }
    } while (choice != 0);

    return 0;
}

int Darmik_main() {
    return runDarmikProgram();
}