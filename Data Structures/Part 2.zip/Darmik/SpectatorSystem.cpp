#include "SpectatorSystem.hpp"

// Constructor for Circular Queue
SpectatorSystem::SpectatorSystem(int cqCap) {
    cqCapacity = cqCap;
    cqSize = 0;
    cqFront = 0;
    cqRear = -1;
    circularQueue.resize(cqCap);
}

// General Queue
void SpectatorSystem::addGeneralSpectator(string name) {
    generalQueue.push(name);
    cout << name << " added to General Spectator Queue.\n";
}
void SpectatorSystem::serveGeneralSpectator() {
    if (generalQueue.empty()) cout << "No spectators in queue.\n";
    else {
        cout << generalQueue.front() << " served from General Queue.\n";
        generalQueue.pop();
    }
}

// Streamer Stack
void SpectatorSystem::addStreamer(string name) {
    streamerStack.push(name);
    cout << name << " added to Streamer Stack.\n";
}
void SpectatorSystem::removeStreamer() {
    if (streamerStack.empty()) cout << "No streamers to remove.\n";
    else {
        cout << streamerStack.top() << " removed from Streamer Stack.\n";
        streamerStack.pop();
    }
}

// VIP Priority Queue
void SpectatorSystem::addVIP(string name, int priority) {
    vipQueue.push(Spectator(name, priority));
    cout << name << " added to VIP Queue with priority " << priority << ".\n";
}
void SpectatorSystem::serveVIP() {
    if (vipQueue.empty()) cout << "No VIPs waiting.\n";
    else {
        cout << vipQueue.top().name << " served from VIP Queue.\n";
        vipQueue.pop();
    }
}

// Circular Queue
void SpectatorSystem::addOverflowSpectator(string name) {
    if (cqSize == cqCapacity) {
        cout << "Overflow Queue is full!\n";
        return;
    }
    cqRear = (cqRear + 1) % cqCapacity;
    circularQueue[cqRear] = name;
    cqSize++;
    cout << name << " added to Overflow Circular Queue.\n";
}
void SpectatorSystem::serveOverflowSpectator() {
    if (cqSize == 0) {
        cout << "No spectators in Overflow Queue.\n";
        return;
    }
    cout << circularQueue[cqFront] << " served from Overflow Queue.\n";
    cqFront = (cqFront + 1) % cqCapacity;
    cqSize--;
}

// Display Methods
void SpectatorSystem::displayGeneralQueue() {
    queue<string> temp = generalQueue;
    cout << "[General Queue]: ";
    while (!temp.empty()) { cout << temp.front() << " "; temp.pop(); }
    cout << endl;
}
void SpectatorSystem::displayStreamerStack() {
    stack<string> temp = streamerStack;
    cout << "[Streamer Stack]: ";
    while (!temp.empty()) { cout << temp.top() << " "; temp.pop(); }
    cout << endl;
}
void SpectatorSystem::displayVIPQueue() {
    priority_queue<Spectator, vector<Spectator>, ComparePriority> temp = vipQueue;
    cout << "[VIP Queue]: ";
    while (!temp.empty()) { cout << temp.top().name << "(" << temp.top().priority << ") "; temp.pop(); }
    cout << endl;
}
void SpectatorSystem::displayOverflowQueue() {
    cout << "[Overflow Circular Queue]: ";
    for (int i = 0; i < cqSize; i++) {
        cout << circularQueue[(cqFront + i) % cqCapacity] << " ";
    }
    cout << endl;
}
