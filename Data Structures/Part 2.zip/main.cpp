#include <iostream>
#include <string>

// Declare the entry points for each person's module
int Anusha_main();
int Hemanth_main();
int Adam_main();
int Darmik_main();

using namespace std;

void showModuleMenu() {
    cout << "\n==== Team Project Launcher ====\n";
    cout << "1. Game Result and Performance History\n";
    cout << "2. Match Schedule and Player Progression\n";
    cout << "3. Registration and Queueing\n";
    cout << "4. Live Stream and Spectator Queue Management\n";
    cout << "0. Exit\n";
    cout << "Choose an option: ";
}

int main() {
    while (true) {
        showModuleMenu();

        string input;
        getline(cin, input);

        int choice;
        try {
            choice = stoi(input);
        } catch (...) {
            cout << "Invalid input. Enter a number.\n";
            continue;
        }

        switch (choice) {
            case 1: cout << "\n>>> Game Result and Performance History...\n"; Anusha_main(); break;
            case 2: cout << "\n>>> Match Schedule and Player Progression...\n"; Hemanth_main(); break;
            case 3: cout << "\n>>> Registration and Queueing...\n"; Adam_main(); break;
            case 4: cout << "\n>>> Live Stream and Spectator Queue Management...\n"; Darmik_main(); break;
            case 0: cout << "Exiting program.\n"; return 0;
            default: cout << "Invalid option! Try again.\n";
        }
    }
}
