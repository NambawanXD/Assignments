# pip install python-ping
from pythonping import ping

# Get ip address or hostname
host_address = input("Enter single IP address or hostname: ")
while True:
    try:
        # Ping host
        result = ping(
            host_address,
            count=10000,
            size=1000,
            timeout=1
        )

        print(result)

    except KeyboardInterrupt:
        print("\n Ping flood stopped by user.")
        break

    except Exception as e:
        print(f"\n Error: {e}")
        break

input("\n Press Enter to continue . . .CTRL-c to stop.")