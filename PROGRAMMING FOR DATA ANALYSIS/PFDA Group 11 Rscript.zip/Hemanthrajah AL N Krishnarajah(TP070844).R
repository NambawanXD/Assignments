# Load necessary libraries
library(ggplot2)
library(reshape2)

# Read the CSV file
df <- read.csv("C:\\Users\\heman\\Downloads\\cleaned_hackingData.csv", stringsAsFactors = FALSE)

# Convert the 'Date' column to Date type and extract year (assuming format yyyy-mm-dd)
df$Date <- as.Date(df$Date, format = "%Y-%m-%d")
df$year <- as.numeric(format(df$Date, "%Y"))
df$month <- as.numeric(format(df$Date, "%m"))


# Remove rows with NA values in critical columns
df <- df[!is.na(df$Loss) & !is.na(df$year) & !is.na(df$month), ]

#--------------------
# Analysis 1. MATRIX PLOT: The relationships between Year, DownTime, and Loss
#--------------------
# Create a subset with only the numeric columns needed
matrix_data <- data.frame(
  Year = df$year,
  DownTime = df$DownTime,
  Loss = df$Loss
)

# Save scatterplot matrix as an image
png("matrix_plot_final.png", width = 800, height = 600, res = 100)
pairs(matrix_data,
      main = "Scatterplot Matrix of Year, DownTime, and Loss",
      pch = 19,
      col = rgb(0, 0, 1, 0.3),
      labels = c("Year", "DownTime", "Loss"))
dev.off()

#--------------------
# Print Summary Statistics and Correlation Matrix
#--------------------
cat("\nSummary Statistics:\n")
print(summary(matrix_data))

cat("\nCorrelation Matrix:\n")
print(cor(matrix_data, use = "complete.obs"))


#--------------------
# Analysis 2. Heatmap: Average Monthly Financial Loss by Year
#--------------------
# Calculate average loss for each month-year combination

monthly_yearly_loss <- aggregate(Loss ~ year + month, data = df, FUN = mean)

# Create heatmap: x-axis: month, y-axis: year, fill: average loss
p2 <- ggplot(monthly_yearly_loss, aes(x = factor(month), y = factor(year), fill = Loss)) +
    geom_tile() +
    scale_fill_gradient2(low = "white", high = "red", mid = "pink",
                        midpoint = mean(monthly_yearly_loss$Loss)) +
    labs(title = "Average Monthly Financial Losses by Year",
         x = "Month",
         y = "Year",
         fill = "Average Loss ($)") +
    theme_minimal()

# Save heatmap
png("monthly_yearly_heatmap.png", width = 800, height = 600, res = 100)
print(p2)
dev.off()

# Print summary statistics
summary_stats <- summary(monthly_yearly_loss$Loss)
print(summary_stats)