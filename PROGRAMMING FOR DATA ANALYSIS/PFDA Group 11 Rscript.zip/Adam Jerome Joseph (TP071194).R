#Analysis 1:

# Load necessary libraries
library(dplyr)
library(ggplot2)
library(readr)

# Define the file path (adjust accordingly if needed)
file_path <- "C:/Users/Adam JJ/Desktop/SEM 1/PFDA/cleaned_hackingData.csv"

# Load the cleaned dataset
data <- read_csv(file_path, locale = locale(encoding = "latin1"))

# Display column names to verify correct reference
print(colnames(data))

# Ensure the date column name is correct (modify if needed)
# If the column storing the attack date is named differently, replace "Date" with the correct name
data$Year <- format(as.Date(data$Date, format = "%Y-%m-%d"), "%Y")

yearly_trend <- data %>%
  filter(!is.na(Year)) %>%  # Remove NA values in the Year column
  group_by(Year) %>%
  summarise(Num_Incidents = n())

# Count Incidents Per Year
yearly_trends <- data %>%
  group_by(Year) %>%
  summarise(Incidents = n()) %>%
  arrange(Year)

print(yearly_trends)

# Plotting of the yearly trend of hacking incidents
ggplot(yearly_trend, aes(x = Year, y = Num_Incidents)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  theme_minimal() +
  labs(title = "Yearly Web Hacking Incidents Trend", x = "Year", y = "Number of Incidents") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#Analysis 2:

# Load necessary libraries
library(dplyr)
library(ggplot2)
library(readr)
library(stringr)

# Load the cleaned dataset
file_path <- "C:/Users/Adam JJ/Desktop/SEM 1/PFDA/cleaned_hackingData.csv"
data <- read_csv(file_path, locale = locale(encoding = "latin1"))

# Standardize notifier names (remove leading/trailing spaces, fix case inconsistencies)
data <- data %>%
  mutate(Notify = str_trim(Notify))

# Total number of incidents for each notifier
notifier_counts <- data %>%
  group_by(Notify) %>%
  summarise(Num_Reports = n(), .groups = "drop") %>%
  arrange(desc(Num_Reports))

# Check the top 10 notifiers
print(head(notifier_counts, 10))

# Select the top 10 notifiers
top_notifiers <- notifier_counts %>%
  slice_head(n = 10)

# Plotting top 10 notifiers using ggplot2
ggplot(top_notifiers, aes(x = reorder(Notify, -Num_Reports), y = Num_Reports)) +
  geom_bar(stat = "identity", fill = "blue") +
  coord_flip() +  # Flip coordinates for better readability
  theme_minimal() +
  labs(title = "Top 10 Notifiers of Web Attacks", x = "Notifier", y = "Number of Reports")
