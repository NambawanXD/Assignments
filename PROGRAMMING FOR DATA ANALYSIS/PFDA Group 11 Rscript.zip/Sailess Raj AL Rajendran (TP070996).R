# Load necessary library
library(ggplot2)
library(dplyr)

# Load dataset
data <- read.csv("C://Users//User//OneDrive//Desktop//PFDA//hackingData.csv")

# 1. Number of Incidents by Operating System (OS)
os_counts <- data %>% 
  filter(OS != "" & !is.na(OS)) %>% 
  group_by(OS) %>% 
  summarise(Count = n()) %>% 
  filter(Count > 0) %>% 
  arrange(desc(Count)) %>% 
  head(10)  # Show only top 10 OS


# vertical bar chart for OS incidents
ggplot(os_counts, aes(x = reorder(OS, Count), y = Count, fill = OS)) + 
  geom_bar(stat = "identity") + 
  geom_text(aes(label = format(Count, big.mark=",")), hjust = -0.2, size = 4) +  
  coord_flip() + 
  theme_minimal() + 
  labs(title = "Number of Incidents by OS", x = "Operating System", y = "Incident Count") +
  theme(legend.position = "none", 
        plot.title = element_text(hjust = 0.5), 
        axis.text.x = element_text(angle = 0, hjust = 0.5)) +
  scale_y_continuous(labels = scales::comma) 

# 2. Number of Incidents by Web Server Type
webserver_counts <- data %>% 
  filter(WebServer != "" & !is.na(WebServer)) %>% 
  group_by(WebServer) %>% 
  summarise(Count = n()) %>% 
  filter(Count > 0) %>% 
  arrange(desc(Count)) %>% 
  head(10)  # Show only top 10 Web Servers

#vertical bar chart for web server incidents
ggplot(webserver_counts, aes(x = reorder(WebServer, Count), y = Count, fill = WebServer)) + 
  geom_bar(stat = "identity") + 
  geom_text(aes(label = format(Count, big.mark=",")), hjust = -0.2, size = 4) +  
  coord_flip() + 
  theme_minimal() + 
  labs(title = "Number of Incidents by Web Server", x = "Web Server", y = "Incident Count") +
  theme(legend.position = "none", 
        plot.title = element_text(hjust = 0.5), # Center aligns the title
        axis.text.x = element_text(angle = 0, hjust = 0.5)) +
  scale_y_continuous(labels = scales::comma)  

