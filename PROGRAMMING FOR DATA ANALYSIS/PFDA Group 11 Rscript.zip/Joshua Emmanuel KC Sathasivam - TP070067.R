#Web Hacking Trends

#Joshua Emmanuel KC Sathasivam - TP070067

#Objective: To Investigate the Relationship Between Key Geographical Trends and Yearly Trend Comparison of Web Hacking Incidents.

# Install Required Packages
install.packages("lubridate")

# Load Required Libraries
library(ggplot2)
library(dplyr)
library(readr)
library(tidyr)
library(lubridate)

# Load The Dataset
CleanedData <- read_csv("/Users/PRINCE_J/Library/CloudStorage/OneDrive-AsiaPacificUniversity/PFDA/Group Assignment/Cleaned Data.csv")

# Convert Date Column To Date Format
CleanedData$Date <- as.Date(CleanedData$Date, format="%m/%d/%Y")

# Check Structure of Data
str("CleanedData.csv")

# Analysis 1-1: Geographical Distribution of Web Hacking Incidents

# Count Incidents Per Country
country_incidents <- CleanedData %>% 
  filter(Country != "UNKNOWN") %>%
  group_by(Country) %>% 
  summarise(Incident_Count = n()) %>% 
  arrange(desc(Incident_Count))

# Display The Top 10 Countries Affected by Web Hacking Incidents
top_10_countries <- head(country_incidents, 10)

# Plot The Top 10 Countries Affected by Web Hacking Incidents
ggplot(country_incidents[1:10, ], aes(x = reorder(Country, -Incident_Count), y = Incident_Count, fill = Country)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label = Incident_Count), hjust = 0.6, size = 4, color = "black") +  # Adding Labels
  coord_flip() +
  labs(title = "Top 10 Countries Affected by Web Hacking Incidents",
       x = "Country",
       y = "Number of Incidents") +
  theme_minimal()



# Analysis 1-2: Yearly & Geographical Trend Comparison of Web Hacking Incidents

# Extract The Year From The Date Column
CleanedData$Year <- year(CleanedData$Date)

# Modify Country Name in The Dataset
top_year_countries_incident <- top_year_countries_incident %>%
  mutate(Country = ifelse(Country == "Netherlands\"", "Netherlands", Country))

top_year_countries_incident <- top_year_countries_incident %>%
  mutate(Country = ifelse(Country == "Southamerica", "South America", Country))

# Count Incidents Per Year and Country
yearly_country_trends <- CleanedData %>%
  filter(Country != "UNKNOWN") %>%
  group_by(Year, Country) %>%
  summarise(Incidents = n(), .groups = 'drop')

# Display The Most Countries Affected Per Year by Web Hacking Incidents
top_year_countries_incident <- yearly_country_trends %>%
  group_by(Year) %>%
  slice_max(order_by = Incidents, n = 10, with_ties = FALSE)

# Plot The Countries Affected Per Year by Web Hacking Incidents
ggplot(top_year_countries_incident , aes(x = factor(Year), y = Incidents, fill = Country)) +
  geom_bar(stat = "identity", position = "stack") +
  labs(title = "Countries Affected Per Year by Web Hacking Incidents",
       x = "Year", y = "Number of Incidents") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
