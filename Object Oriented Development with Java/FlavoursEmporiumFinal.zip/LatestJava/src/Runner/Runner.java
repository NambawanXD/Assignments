/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */


import java.io.*;
import javax.swing.JOptionPane;

public class Runner {
    private String runnerID;
    private String password;

    public Runner(String runnerID, String password) {
        this.runnerID = runnerID;
        this.password = password;
    }

    public boolean authenticate() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/txt/runners.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    String storedID = parts[0].trim();
                    String storedPassword = parts[3].trim();
                    if (storedID.equals(this.runnerID) && storedPassword.equals(this.password)) {
                        return true; // ✅ Valid runner
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading runners.txt file.");
        }
        return false; // ❌ Runner not found
    }


    public String getRunnerID() {
        return runnerID;
    }
}

