/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package flavoursemporium;
/**
 *
 * @author heman
 */


import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DeliveryTask {
    private String runnerID;

    public DeliveryTask(String runnerID) {
        this.runnerID = runnerID;
    }

    public void loadTasks(DefaultTableModel model) {
        model.setRowCount(0); // ✅ Clear table before loading

        try (BufferedReader br = new BufferedReader(new FileReader("src/txt/DeliveryTasks.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5) {
                    String orderID = parts[0].trim();
                    String itemName = parts[1].trim();
                    String quantity = parts[2].trim();
                    String price = parts[3].trim();
                    String status = parts[4].trim();
                    String assignedRunner = (parts.length > 5) ? parts[5].trim() : "";

                    // ✅ Only load tasks assigned to the logged-in runner
                    if (assignedRunner.equals(this.runnerID)) {
                        model.addRow(new Object[]{orderID, itemName, quantity, price, status});
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading DeliveryTasks.txt file.");
        }
    }

    public void markTaskAsCompleted(String orderID) {
        File inputFile = new File("src/txt/DeliveryTasks.txt");
        File tempFile = new File("src/txt/temp_DeliveryTasks.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(orderID + ",")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 5) {
                        parts[4] = "Delivered"; // Update the status
                        line = String.join(",", parts);
                    }
                }
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error updating DeliveryTasks.txt: " + e.getMessage());
        }

        // ✅ Replace original file with updated file
        if (inputFile.delete()) {
            tempFile.renameTo(inputFile);
        }

        // ✅ Also update order.txt
        updateOrderStatus(orderID, "Delivered");
    }
    
    
    
    
    private void updateOrderStatus(String orderID, String newStatus) {
        File inputFile = new File("src/txt/order.txt");
        File tempFile = new File("src/txt/temp_order.txt");

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith(orderID + ",")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 7) {
                        parts[6] = "Status: " + newStatus;
                        line = String.join(",", parts);
                    }
                }
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error updating order.txt: " + e.getMessage());
        }

        // ✅ Replace original order.txt with the updated one
        if (inputFile.delete()) {
            tempFile.renameTo(inputFile);
        }
    }
}
