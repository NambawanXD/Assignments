/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */
public class Review {
    private String reviewID;
    private String customerID;
    private String vendorID;
    private String orderID;
    private String runnerID;
    private String runnerName;
    private int rating;
    private String comments;

    public Review(String reviewID, String customerID, String vendorID, String orderID, String runnerID, String runnerName, int rating, String comments) {
        this.reviewID = reviewID;
        this.customerID = customerID;
        this.vendorID = vendorID;
        this.orderID = orderID;
        this.runnerID = runnerID;
        this.runnerName = runnerName;
        this.rating = rating;
        this.comments = comments;
    }

    // Getters and setters
    public String getReviewID() { return reviewID; }
    public String getCustomerID() { return customerID; }
    public String getVendorID() { return vendorID; }
    public String getOrderID() { return orderID; }
    public String getRunnerID() { return runnerID; }
    public String getRunnerName() { return runnerName; }
    public int getRating() { return rating; }
    public String getComments() { return comments; }
}
