/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package flavoursemporium;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.*;

/**
 *
 * @author heman
 */
public class DeliveryRunnerPerformance extends javax.swing.JFrame {
    private static final String DELIVERY_TASKS_FILE = "src/txt/DeliveryTasks.txt";
    private static final String RUNNERS_FILE = "src/txt/runners.txt";
    /**
     * Creates new form DeliveryRunnerPerformance
     */
     
    public DeliveryRunnerPerformance() {
        initComponents();
        refreshTable();
    }
    
    
    private void refreshTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear table before loading data

        Map<String, String> runnerEmails = loadRunnerEmails();
        Set<String> processedOrders = new HashSet<>(); // Track unique orders for revenue calculation

        try (BufferedReader br = new BufferedReader(new FileReader(DELIVERY_TASKS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 6) continue; // Ensure valid format

                String orderID = parts[0].trim();
                String itemName = parts[1].trim();
                String quantity = parts[2].trim();
                String price = parts[3].trim();
                String status = parts[4].trim();
                String runnerID = parts[5].trim();

                // Only include "Delivered" tasks
                if (!status.equalsIgnoreCase("Delivered")) continue;

                String runnerEmail = runnerEmails.getOrDefault(runnerID, "Unknown");
                double revenue = processedOrders.contains(orderID) ? 0 : 5; // Add $5 once per unique OrderID
                processedOrders.add(orderID);

                model.addRow(new Object[]{runnerID, runnerEmail, orderID, itemName, quantity, price, revenue});
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading delivery tasks.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Loads Runner ID to Email mapping from `runners.txt`
     */
    private Map<String, String> loadRunnerEmails() {
        Map<String, String> runnerEmails = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(RUNNERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String runnerID = parts[0].trim();
                    String runnerEmail = parts[2].trim();
                    runnerEmails.put(runnerID, runnerEmail);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading runners file.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return runnerEmails;
    }

    /**
     * Filters table based on Runner ID or Runner Email.
     */
    private void searchRunnerPerformance() {
        String query = SearchTextfield.getText().trim().toLowerCase();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        if (query.isEmpty()) {
            refreshTable();
            return;
        }

        DefaultTableModel filteredModel = new DefaultTableModel(
                new String[]{"Runner ID", "Runner Email", "OrderID", "Item Name", "Quantity", "Price", "Revenue"}, 0);

        for (int i = 0; i < model.getRowCount(); i++) {
            String runnerID = model.getValueAt(i, 0).toString().toLowerCase();
            String runnerEmail = model.getValueAt(i, 1).toString().toLowerCase();

            if (runnerID.contains(query) || runnerEmail.contains(query)) {
                filteredModel.addRow(new Object[]{
                        model.getValueAt(i, 0),
                        model.getValueAt(i, 1),
                        model.getValueAt(i, 2),
                        model.getValueAt(i, 3),
                        model.getValueAt(i, 4),
                        model.getValueAt(i, 5),
                        model.getValueAt(i, 6)
                });
            }
        }

        jTable1.setModel(filteredModel);
    }

    /**
     * Calculates total revenue for displayed results.
     */
    private void calculateTotalRevenue() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        double totalRevenue = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            totalRevenue += Double.parseDouble(model.getValueAt(i, 6).toString());
        }

        JOptionPane.showMessageDialog(this, "Total Revenue: $" + String.format("%.2f", totalRevenue));
    }




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        SearchTextfield = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        TotalRevenueButton = new javax.swing.JButton();
        RefreshButton = new javax.swing.JButton();
        Return = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(179, 204, 193));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Mshtakan", 1, 24)); // NOI18N
        jLabel1.setText("DeliveryRunnerPerformance");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(233, 27, -1, -1));

        jTable1.setBackground(new java.awt.Color(255, 239, 225));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Runner ID", "Runner Email", "OrderID", "Item Name", "Quantity", "Price", "Revenue"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 92, 614, 309));

        jLabel2.setText("Search:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 140, -1, -1));

        SearchTextfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchTextfieldActionPerformed(evt);
            }
        });
        jPanel1.add(SearchTextfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 140, 190, -1));

        SearchButton.setText("Search");
        SearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchButtonActionPerformed(evt);
            }
        });
        jPanel1.add(SearchButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 180, -1, -1));

        DeleteButton.setText("Delete");
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });
        jPanel1.add(DeleteButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, -1, -1));

        TotalRevenueButton.setText("Total Revenue");
        TotalRevenueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalRevenueButtonActionPerformed(evt);
            }
        });
        jPanel1.add(TotalRevenueButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 370, -1, -1));

        RefreshButton.setText("Refresh");
        RefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtonActionPerformed(evt);
            }
        });
        jPanel1.add(RefreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 370, -1, -1));

        Return.setText("←");
        Return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnActionPerformed(evt);
            }
        });
        jPanel1.add(Return, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 940, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SearchTextfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchTextfieldActionPerformed
        searchRunnerPerformance();
    }//GEN-LAST:event_SearchTextfieldActionPerformed

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed
        searchRunnerPerformance();
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow != -1) { // ✅ Ensure a row is selected
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.removeRow(selectedRow);
            JOptionPane.showMessageDialog(this, "Selected row deleted.");
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_DeleteButtonActionPerformed

    private void TotalRevenueButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalRevenueButtonActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        double totalRevenue = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            totalRevenue += Double.parseDouble(model.getValueAt(i, 6).toString()); // Column 6 is Revenue
        }

        JOptionPane.showMessageDialog(this, "Total Revenue: $" + String.format("%.2f", totalRevenue));
    }//GEN-LAST:event_TotalRevenueButtonActionPerformed

    private void RefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtonActionPerformed
        refreshTable();
    }//GEN-LAST:event_RefreshButtonActionPerformed

    private void ReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnActionPerformed
        Managerhome mghome = new Managerhome();
        mghome.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DeliveryRunnerPerformance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DeliveryRunnerPerformance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DeliveryRunnerPerformance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DeliveryRunnerPerformance.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DeliveryRunnerPerformance().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton RefreshButton;
    private javax.swing.JButton Return;
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField SearchTextfield;
    private javax.swing.JButton TotalRevenueButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
