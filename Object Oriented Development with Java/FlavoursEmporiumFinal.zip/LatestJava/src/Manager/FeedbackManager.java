/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackManager {

    private static final String FEEDBACK_FILE = "src/txt/Feedback.txt";
    private static final String FEEDBACK_REPLY_FILE = "src/txt/FeedbackReply.txt";
    private static final String CUSTOMERS_FILE = "src/txt/Customers.txt";

    public List<FeedbackM> getPendingFeedback() {
        List<FeedbackM> feedbackList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FEEDBACK_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5 && "Ongoing".equalsIgnoreCase(parts[4].trim())) {
                    String name = parts[0];
                    String email = parts[1];
                    int rating = Integer.parseInt(parts[2]);
                    String feedbackText = parts[3];
                    String customerID = getCustomerIDByEmail(email);
                    feedbackList.add(new FeedbackM(customerID, name, email, rating, feedbackText, "Ongoing"));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }

    public boolean saveReply(String email, String reply) {
        boolean updated = updateFeedbackStatus(email, "Completed");
        if (!updated) return false;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FEEDBACK_REPLY_FILE, true))) {
            String name = getNameByEmail(email);
            bw.write(name + "," + email + "," + reply);
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean updateFeedbackStatus(String email, String newStatus) {
        List<String> lines = new ArrayList<>();
        boolean updated = false;

        try (BufferedReader br = new BufferedReader(new FileReader(FEEDBACK_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 5 && email.equalsIgnoreCase(parts[1].trim())) {
                    parts[4] = newStatus;
                    updated = true;
                }
                lines.add(String.join(",", parts));
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FEEDBACK_FILE))) {
            for (String line : lines) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return updated;
    }

    public List<FeedbackM> filterFeedbackByEmail(String email) {
        List<FeedbackM> allFeedback = getPendingFeedback();
        List<FeedbackM> filtered = new ArrayList<>();
        for (FeedbackM feedback : allFeedback) {
            if (feedback.getEmail().toLowerCase().contains(email)) {
                filtered.add(feedback);
            }
        }
        return filtered;
    }

    private String getCustomerIDByEmail(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader(CUSTOMERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && email.equalsIgnoreCase(parts[2].trim())) {
                    return parts[0];
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String getNameByEmail(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader(CUSTOMERS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && email.equalsIgnoreCase(parts[2].trim())) {
                    return parts[1];
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}
