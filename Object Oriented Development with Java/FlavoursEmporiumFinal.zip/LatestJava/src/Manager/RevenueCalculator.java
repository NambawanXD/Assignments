/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author heman
 */
package flavoursemporium;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class RevenueCalculator {

    public Map<String, Vendor> loadVendors(String filePath) {
        Map<String, Vendor> vendors = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line = br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String vendorID = parts[0];
                String vendorName = parts[3];
                vendors.put(vendorID, new Vendor(vendorID, vendorName));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return vendors;
    }

    public List<Transaction> loadTransactions(String filePath) {
        List<Transaction> transactions = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line = br.readLine(); // Skip header
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue; // ✅ Skip empty lines

                String[] parts = line.split(",");
                if (parts.length < 6) { // ✅ Validate correct number of columns
                    System.err.println("Skipping malformed line: " + line);
                    continue;
                }

                String transactionID = parts[0];
                String orderID = parts[1];
                String vendorId = parts[2];
                double amount = Double.parseDouble(parts[3]);
                String transactionType = parts[4];
                String date = parts[5];

                transactions.add(new Transaction(transactionID, orderID, vendorId, amount, transactionType, date));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return transactions;
    }


    public Map<String, Map<String, Double>> calculateMonthlyRevenue(
        Map<String, Vendor> vendors, List<Transaction> transactions) {
        Map<String, Map<String, Double>> revenueData = new HashMap<>();

        for (Transaction transaction : transactions) {
            String vendorId = transaction.getVendorId();
            String month = transaction.getMonth();
            double amount = transaction.getAmount();

            if (vendors.containsKey(vendorId)) {
                Vendor vendor = vendors.get(vendorId);
                String vendorName = vendor.getName();

                revenueData.putIfAbsent(vendorName, new HashMap<>());
                Map<String, Double> monthlyRevenue = revenueData.get(vendorName);
                monthlyRevenue.put(month, monthlyRevenue.getOrDefault(month, 0.0) + amount);
            }
        }

        return revenueData;
    }
}
