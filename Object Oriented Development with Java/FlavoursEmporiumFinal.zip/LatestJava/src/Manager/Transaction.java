/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */
public class Transaction {
    private String transactionID;
    private String orderID;
    private String vendorId;
    private double amount;
    private String transactionType;
    private String date;

    // ✅ Update the constructor to match loadTransactions()
    public Transaction(String transactionID, String orderID, String vendorId, double amount, String transactionType, String date) {
        this.transactionID = transactionID;
        this.orderID = orderID;
        this.vendorId = vendorId;
        this.amount = amount;
        this.transactionType = transactionType;
        this.date = date;
    }

    // Getters for accessing data
    public String getTransactionID() {
        return transactionID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getVendorId() {
        return vendorId;
    }

    public double getAmount() {
        return amount;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public String getDate() {
        return date;
    }

    public String getMonth() {
        return date.substring(0, 7); // Extracts "YYYY-MM" from the date
    }
}

