/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableModel;

public class ReviewManager {
    private List<Review> reviews = new ArrayList<>();

    public ReviewManager(String reviewFile, String runnerFile) {
        loadReviews(reviewFile, runnerFile);
    }
    
    public void reloadReviews() {
        reviews.clear();
        loadReviews("src/txt/Reviews.txt", "src/txt/DeliveryRunners.txt");
    }


    private void loadReviews(String reviewFile, String runnerFile) {
        Map<String, String> runnerMap = new HashMap<>();
        try (BufferedReader runnerReader = new BufferedReader(new FileReader(runnerFile))) {
            String line = runnerReader.readLine(); // Skip header row
            while ((line = runnerReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    runnerMap.put(parts[0], parts[2]); // Map RunnerID to RunnerName
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try (BufferedReader reviewReader = new BufferedReader(new FileReader(reviewFile))) {
            String line = reviewReader.readLine(); // Skip header row
            while ((line = reviewReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    String runnerName = runnerMap.getOrDefault(parts[4], "Unknown");
                    try {
                        reviews.add(new Review(
                            parts[0], 
                            parts[1], 
                            parts[2], 
                            parts[3], 
                            parts[4], 
                            runnerName, 
                            Integer.parseInt(parts[5]), // Parse rating
                            parts[6]
                        ));
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid rating: " + parts[5]);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public DefaultTableModel getTableModel() {
        String[] columns = {"ReviewID", "CustomerID", "VendorID", "OrderID", "RunnerID", "RunnerName", "Rating", "Comments"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        for (Review review : reviews) {
            model.addRow(new Object[]{review.getReviewID(), review.getCustomerID(), review.getVendorID(), review.getOrderID(), review.getRunnerID(), review.getRunnerName(), review.getRating(), review.getComments()});
        }
        return model;
    }

    public DefaultTableModel search(String query) {
        String[] columns = {"ReviewID", "CustomerID", "VendorID", "OrderID", "RunnerID", "RunnerName", "Rating", "Comments"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        query = query.toLowerCase(); // Make the search case-insensitive

        for (Review review : reviews) {
            // Check if the query matches any field in the review object
            if (review.getReviewID().toLowerCase().contains(query) ||
                review.getCustomerID().toLowerCase().contains(query) ||
                review.getVendorID().toLowerCase().contains(query) ||
                review.getOrderID().toLowerCase().contains(query) ||
                review.getRunnerID().toLowerCase().contains(query) ||
                review.getRunnerName().toLowerCase().contains(query) ||
                String.valueOf(review.getRating()).toLowerCase().contains(query) ||
                review.getComments().toLowerCase().contains(query)) {

                // Add the matching row to the table model
                model.addRow(new Object[]{
                    review.getReviewID(),
                    review.getCustomerID(),
                    review.getVendorID(),
                    review.getOrderID(),
                    review.getRunnerID(),
                    review.getRunnerName(),
                    review.getRating(),
                    review.getComments()
                });
            }
        }

        return model.getRowCount() > 0 ? model : getTableModel(); // Return the search results or the original table model if no matches
    }


   
    
    public boolean delete(String reviewID) {
        System.out.println("Attempting to delete reviewID: " + reviewID); // Debug
        return deleteReviewFromFile(reviewID);
    }

    
   public boolean deleteReviewFromFile(String reviewID) {
        File file = new File("D:\\Java\\Assignment\\src\\main\\java\\JavaG21\\Reviews.txt");
        File tempFile = new File("tempReviews.txt");
        boolean isDeleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                String[] fields = currentLine.split(",");
                if (fields.length > 0 && fields[0].trim().equals(reviewID.trim())) {
                    System.out.println("Deleting line: " + currentLine);
                    isDeleted = true;
                    continue; // Skip writing this line to the temp file
                }
                writer.write(currentLine);
                writer.newLine();
            }

            writer.flush();

            if (isDeleted) {
                // Close the resources and delay delete to ensure file release
                reader.close();
                writer.close();

                // Delete the original file
                try {
                    Files.delete(file.toPath());
                } catch (IOException e) {
                    System.err.println("Error deleting file: " + e.getMessage());
                    e.printStackTrace();
                    return false;
                }

                // Rename temp file to original file
                if (!tempFile.renameTo(file)) {
                    System.err.println("Error renaming temp file to original.");
                    return false;
                }
            } else {
                System.out.println("No matching reviewID found: " + reviewID);
                tempFile.delete();
            }
            return isDeleted;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }



    public DefaultTableModel getAverageRatings() {
        String[] columns = {"RunnerID", "RunnerName", "Average Rating"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        Map<String, List<Integer>> runnerRatings = new HashMap<>();
        for (Review review : reviews) {
            runnerRatings.computeIfAbsent(review.getRunnerID(), k -> new ArrayList<>()).add(review.getRating());
        }

        for (Map.Entry<String, List<Integer>> entry : runnerRatings.entrySet()) {
            String runnerID = entry.getKey();
            List<Integer> ratings = entry.getValue();
            double average = ratings.stream().mapToInt(Integer::intValue).average().orElse(0);
            String runnerName = reviews.stream().filter(r -> r.getRunnerID().equals(runnerID)).findFirst().map(Review::getRunnerName).orElse("Unknown");
            model.addRow(new Object[]{runnerID, runnerName, average});
        }

        return model;
    }

}

