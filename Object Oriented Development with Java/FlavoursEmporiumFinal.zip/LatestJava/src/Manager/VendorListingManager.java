/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */
import java.io.*;
import java.util.*;

public class VendorListingManager {
    private final String filePath;

    public VendorListingManager() {
        // Set the file path for the MenuItems.txt file
        this.filePath = "src/txt/Menu.txt";
    }

    public List<String[]> loadMenuItems() throws IOException {
        List<String[]> menuItems = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                menuItems.add(line.split(","));
            }
        }
        return menuItems;
    }

    public void saveMenuItems(List<String[]> menuItems) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (String[] item : menuItems) {
                bw.write(String.join(",", item));
                bw.newLine();
            }
        }
    }

    public List<String[]> searchByVendorID(String vendorID) throws IOException {
        List<String[]> filteredItems = new ArrayList<>();
        for (String[] item : loadMenuItems()) {
            if (item[1].equals(vendorID)) {
                filteredItems.add(item);
            }
        }
        return filteredItems;
    }
}