/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author heman
 */

public class FeedbackM {
    private String customerID;
    private String name;
    private String email;
    private int rating;
    private String feedbackText;
    private String status;

    public FeedbackM(String customerID, String name, String email, int rating, String feedbackText, String status) {
        this.customerID = customerID;
        this.name = name;
        this.email = email;
        this.rating = rating;
        this.feedbackText = feedbackText;
        this.status = status;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getRating() {
        return rating;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
