/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

public class FeedbackCustomer {
    private String name;
    private String email;
    private int rating;
    private String feedback;

    public FeedbackCustomer(String name, String email, int rating, String feedback) {
        this.name = name;
        this.email = email;
        this.rating = rating;
        this.feedback = feedback;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public int getRating() { return rating; }
    public String getFeedback() { return feedback; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setRating(int rating) { this.rating = rating; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public boolean isValidEmail() {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailRegex);
    }

    @Override
    public String toString() {
        return name + "," + email + "," + rating + "," + feedback;
    }
}

