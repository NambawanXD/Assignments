package flavoursemporium;

public class TransactionRecord {
    private String transactionID;
    private String orderID;
    private String vendorID;
    private String amount;
    private String transactionType;
    private String transactionDate;
    private String customerID;
    private String customerName;

    public TransactionRecord(String transactionID, String orderID, String vendorID, String amount,
                             String transactionType, String transactionDate, String customerID, String customerName) {
        this.transactionID = transactionID;
        this.orderID = orderID;
        this.vendorID = vendorID;
        this.amount = amount;
        this.transactionType = transactionType;
        this.transactionDate = transactionDate;
        this.customerID = customerID;
        this.customerName = customerName;
    }

    public String getTransactionID() {
        return transactionID;
    }

    public String getOrderID() {
        return orderID;
    }

    public String getVendorID() {
        return vendorID;
    }

    public String getAmount() {
        return amount;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public String getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }
}
