/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

public class Status {
    private String orderID;
    private String items;
    private String totalPrice;
    private String status;

    public Status(String orderID, String items, String totalPrice, String status) {
        this.orderID = orderID;
        this.items = items;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    public String getOrderID() { return orderID; }
    public String getItems() { return items; }
    public String getTotalPrice() { return totalPrice; }
    public String getStatus() { return status; }

    public void setOrderID(String orderID) { this.orderID = orderID; }
    public void setItems(String items) { this.items = items; }
    public void setTotalPrice(String totalPrice) { this.totalPrice = totalPrice; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return orderID + "," + items + "," + totalPrice + "," + status;
    }
}

