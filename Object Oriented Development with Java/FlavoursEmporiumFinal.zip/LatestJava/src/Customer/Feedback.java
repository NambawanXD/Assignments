/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;



public class Feedback {
    private String name;
    private String email;
    private int rating;
    private String feedbackText;

    public Feedback(String name, String email, int rating, String feedbackText) {
        this.name = name;
        this.email = email;
        this.rating = rating;
        this.feedbackText = feedbackText;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public int getRating() {
        return rating;
    }

    public String getFeedbackText() {
        return feedbackText;
    }
}
