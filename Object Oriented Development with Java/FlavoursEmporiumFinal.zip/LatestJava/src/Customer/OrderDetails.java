/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

public class OrderDetails {
    private String customerID;
    private String orderID;
    private String itemName;
    private int quantity;
    private double price;
    private double totalPrice;
    private String serviceOption;
    private String status;

    public OrderDetails(String customerID, String orderID, String itemName, int quantity, double price, double totalPrice, String serviceOption, String status) {
        this.customerID = customerID;
        this.orderID = orderID;
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.totalPrice = totalPrice;
        this.serviceOption = serviceOption;
        this.status = status;
    }

    public String getCustomerID() { return customerID; }
    public String getOrderID() { return orderID; }
    public String getItemName() { return itemName; }
    public int getQuantity() { return quantity; }
    public double getPrice() { return price; }
    public double getTotalPrice() { return totalPrice; }
    public String getServiceOption() { return serviceOption; }
    public String getStatus() { return status; }
}







