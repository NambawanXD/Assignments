/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author anushadevybrahmataran
 */
public class MenuItem {
    private String menuItemID;
    private String vendorID;
    private String itemName;
    private String description;
    private double price;
    private String category;

    public MenuItem(String menuItemID, String vendorID, String itemName, String description, double price, String category) {
        this.menuItemID = menuItemID;
        this.vendorID = vendorID;
        this.itemName = itemName;
        this.description = description;
        this.price = price;
        this.category = category;
    }

    public String getMenuItemID() { return menuItemID; }
    public String getVendorID() { return vendorID; }
    public String getItemName() { return itemName; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public String getCategory() { return category; }

    public void setMenuItemID(String menuItemID) { this.menuItemID = menuItemID; }
    public void setVendorID(String vendorID) { this.vendorID = vendorID; }
    public void setItemName(String itemName) { this.itemName = itemName; }
    public void setDescription(String description) { this.description = description; }
    public void setPrice(double price) { this.price = price; }
    public void setCategory(String category) { this.category = category; }

    @Override
    public String toString() {
        return menuItemID + "," + vendorID + "," + itemName + "," + description + "," + price + "," + category;
    }
}
