/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package flavoursemporium;

import javax.swing.table.DefaultTableModel;
import java.io.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;



public class Cart extends javax.swing.JFrame {
    private DefaultTableModel model;
    private ArrayList<CartItem> cartItems;
    

    public Cart() {
        model = new DefaultTableModel(new String[]{"Name", "Price", "Quantity"}, 0);
        cartItems = new ArrayList<>();

        loadCartFromFile(); 
        initComponents();
        calculateTotalPrice();
    }
    
    private void loadCartFromFile() {
        try {
            FileReader fr = new FileReader("src/txt/Cart.txt");
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 6) {
                    String name = values[2].trim();
                    double price = Double.parseDouble(values[4].trim());
                    int quantity = 1;
                    CartItem item = new CartItem(name, price, quantity);
                    cartItems.add(item);
                    model.addRow(new Object[]{name, price, quantity});
                }
            }
            br.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
      
    private void calculateTotalPrice() {
        double totalPrice = 0.0;

        for (CartItem item : cartItems) {
            totalPrice += item.getPrice() * item.getQuantity();
        }

        double deliveryCharge = 0.0;
        String deliveryText = jTextField2.getText();
        if (!deliveryText.isEmpty()) {
            try {
                deliveryCharge = Double.parseDouble(deliveryText);
            } catch (NumberFormatException e) {
                System.err.println("Invalid delivery charge format: " + e.getMessage());
            }
        }

        totalPrice += deliveryCharge;
        jTextField1.setText(String.format("%.2f", totalPrice));
    }

    private void increaseQuantity(java.awt.event.ActionEvent evt) {
        int row = jTable1.getSelectedRow();
        if (row != -1) {
            CartItem item = cartItems.get(row);
            item.setQuantity(item.getQuantity() + 1);
            model.setValueAt(item.getQuantity(), row, 2);
            updateFile();
            calculateTotalPrice();
        }
    }

    private void decreaseQuantity(java.awt.event.ActionEvent evt) {
        int row = jTable1.getSelectedRow();
        if (row != -1) {
            CartItem item = cartItems.get(row);
            if (item.getQuantity() > 1) {
                item.setQuantity(item.getQuantity() - 1);
                model.setValueAt(item.getQuantity(), row, 2);
                updateFile();
                calculateTotalPrice();
            }
        }
    }

    private void removeItem() {
        int row = jTable1.getSelectedRow();
        if (row != -1) {
            cartItems.remove(row);
            model.removeRow(row);
            updateFile();
            calculateTotalPrice();
        }
    }

    private void emptyCart() {
        cartItems.clear();
        model.setRowCount(0);
        jTextField1.setText("0.00");

        try {
            FileWriter fw = new FileWriter("src/txt/Cart.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("");
            bw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error clearing the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String generateOrderID() {
        int orderNumber = (int) (Math.random() * 9000 + 1000);
        return "ORD" + orderNumber;
    }

    private void placeOrder() {
        if (cartItems.isEmpty()) {
            JOptionPane.showMessageDialog(this, "The cart is empty. Please add items before placing an order.", "Empty Cart", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double totalPrice = 0.0;
        for (CartItem item : cartItems) {
            totalPrice += item.getPrice() * item.getQuantity();
        }

        // Get Email and Customer ID
        String email = JOptionPane.showInputDialog(this, "Enter your Email:");
        if (email == null) return;
        email = email.trim().toLowerCase();

        String customerId = JOptionPane.showInputDialog(this, "Enter your Customer ID:");
        if (customerId == null) return;
        customerId = customerId.trim();

        // Validate Email and Customer ID
        if (!validateCustomer(email, customerId)) {
            JOptionPane.showMessageDialog(this, "Invalid Email or Customer ID. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double balance = getBalanceByCustomerId(customerId);
        String orderID = generateOrderID();
        String serviceOption = (String) jComboBox1.getSelectedItem();

        // ✅ Add RM5 if service option is "Delivery"
        if ("Delivery".equalsIgnoreCase(serviceOption)) {
            totalPrice += 5.00;
        }

        // ✅ If balance is sufficient, place order
        if (balance >= totalPrice) {
            saveOrderToFile(orderID, totalPrice, serviceOption); 
            updateBalance(customerId, balance - totalPrice);

            // ✅ Save each Transaction with Credit Type and **CustomerID**
            saveTransactionToFile(orderID, "Credit", customerId);

            JOptionPane.showMessageDialog(this, "Order placed successfully! Total Price: " + totalPrice, "Order Placed", JOptionPane.INFORMATION_MESSAGE);
            emptyCart();  // ✅ Clear cart after placing order
        } else {
            JOptionPane.showMessageDialog(this, "Insufficient balance! Redirecting to Credit page to top up.", "Insufficient Balance", JOptionPane.WARNING_MESSAGE);
            Credit creditPage = new Credit(email);
            creditPage.setVisible(true); 
            this.dispose();
        }
    }




    private String generateTransactionID() {
    String filePath = "src/txt/Transactions.txt";
    int maxID = 0;

    try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length > 0 && parts[0].startsWith("TR")) {
                int id = Integer.parseInt(parts[0].substring(2)); // Extract numeric part of TR ID
                if (id > maxID) {
                    maxID = id;
                }
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading Transactions.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    return String.format("TR%03d", maxID + 1); // Format as TR001, TR002, etc.
}


    private void saveTransactionToFile(String orderID, String transactionType, String customerID) {
        String filePath = "src/txt/Transactions.txt";
        String transactionDate = java.time.LocalDate.now().toString();
        StringBuilder transactionData = new StringBuilder();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            for (CartItem item : cartItems) {
                // ✅ Get Vendor ID from Menu.txt
                String vendorID = getVendorIDFromMenu(item.getName());

                if (vendorID == null || vendorID.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "⚠️ Vendor ID not found for item: " + item.getName(), "Error", JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                // ✅ Generate unique Transaction ID
                String transactionID = generateTransactionID();

                // ✅ Write transaction with **CustomerID included**
                transactionData.append(transactionID).append(",")  
                               .append(orderID).append(",")  
                               .append(vendorID).append(",")  
                               .append(String.format("%.2f", item.getPrice() * item.getQuantity())).append(",")  
                               .append(transactionType).append(",")  
                               .append(transactionDate).append(",")  
                               .append(customerID)  // ✅ CustomerID now always included!
                               .append(System.lineSeparator());
            }

            writer.write(transactionData.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving transaction: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }




    private String getVendorIDFromCart(String itemName) {
        String filePath = "src/txt/Cart.txt";
        String vendorID = null;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 6 && values[2].trim().equalsIgnoreCase(itemName.trim())) {
                    vendorID = values[1].trim(); // Vendor ID is the second column
                    break; // Exit once Vendor ID is found for the item
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Cart.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return vendorID;
    }
    
    private String getVendorIDFromMenu(String itemName) {
        String filePath = "src/txt/Menu.txt";
        String vendorID = null;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length >= 6 && values[2].trim().equalsIgnoreCase(itemName.trim())) {
                    vendorID = values[1].trim(); // ✅ Vendor ID is in the second column
                    break;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Menu.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return vendorID;
    }






    
    private void saveOrderToFile(String orderID, double totalPrice, String serviceOption) {
        String filePath = "src/txt/Order.txt";
        StringBuilder orderData = new StringBuilder();

        for (CartItem item : cartItems) {
            double itemTotal = item.getPrice() * item.getQuantity();
            orderData.append(orderID).append(",")  // Order ID
                    .append(item.getName()).append(",")  // Item Name
                    .append(item.getQuantity()).append(",")  // Quantity
                    .append(String.format("%.2f", item.getPrice())).append(",")  // Unit Price
                    .append(String.format("%.2f", itemTotal)).append(",")  // Total Price for Item
                    .append(serviceOption).append(", Status: Pending")  // Service Option & Status
                    .append(System.lineSeparator());
        }

        // ✅ Append final **Total Price** at the end of the order
        orderData.append("Total Price: ").append(String.format("%.2f", totalPrice))
                 .append(System.lineSeparator()).append(System.lineSeparator());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(orderData.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving order: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }





    
    private boolean validateCustomer(String email, String customerId) {
        try (BufferedReader br = new BufferedReader(new FileReader("src/txt/customers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[0].equals(customerId) && parts[2].equalsIgnoreCase(email)) {
                    return true;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading customers.txt", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    
    private void updateBalance(String customerId, double newBalance) {
        String filePath = "src/txt/topup.txt";
        StringBuilder updatedContent = new StringBuilder();
        boolean balanceUpdated = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length == 2 && parts[0].equals(customerId)) {
                    // Update balance for the matching customer ID
                    updatedContent.append(customerId).append(",").append(newBalance).append(System.lineSeparator());
                    balanceUpdated = true;
                } else {
                    // Keep the existing lines as is
                    updatedContent.append(line).append(System.lineSeparator());
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading topup.txt", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // If the customer was not found, add a new entry for the balance
        if (!balanceUpdated) {
            updatedContent.append(customerId).append(",").append(newBalance).append(System.lineSeparator());
        }

        // Save the updated content back to the file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(updatedContent.toString().trim());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating topup.txt", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private double getBalanceByCustomerId(String customerId) {
    try (BufferedReader br = new BufferedReader(new FileReader("src/txt/topup.txt"))) {
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 2 && parts[0].equals(customerId)) {
                return Double.parseDouble(parts[1]);
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading topup.txt", "Error", JOptionPane.ERROR_MESSAGE);
    }
    return 0.0;
}


    private void updateFile() {
        try {
            FileWriter fw = new FileWriter("src/txt/Cart.txt", false);
            BufferedWriter bw = new BufferedWriter(fw);

            for (CartItem item : cartItems) {
                bw.write(item.toString());
                bw.newLine();
            }

            bw.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }









    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(179, 204, 193));

        jButton4.setText("←");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTable1.setBackground(new java.awt.Color(255, 239, 225));
        jTable1.setModel(model);
        jTable1.setSelectionBackground(new java.awt.Color(177, 103, 0));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jButton1.setText("➕");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jButton2.setText("➖");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jButton3.setText("🗑");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton6.setText("Empty Cart");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton5.setText("Place Order");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Total:");

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        jLabel3.setText("Delivery Charge:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dine-In", "Takeaway", "Delivery" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Service Option:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton5))
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(169, 169, 169)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(18, 18, 18)
                        .addComponent(jButton3)
                        .addGap(364, 364, 364)))
                .addGap(71, 71, 71))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton5)
                            .addComponent(jButton6))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        increaseQuantity(evt);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        decreaseQuantity(evt);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        HomePage home = new HomePage();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        removeItem();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        int confirm = JOptionPane.showConfirmDialog(this, 
        "Are you sure you want to empty the entire cart?", 
        "Confirm Empty Cart", 
        JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {       
        emptyCart(); // Clear the cart
    }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        placeOrder();
        updateFile();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        String serviceOption = (String) jComboBox1.getSelectedItem();

    // Save the selected service option to a text file
    try 
        (BufferedWriter writer = new BufferedWriter(new FileWriter("Order.txt"))) {
        writer.write(serviceOption);  // Write the service option to the file
        writer.newLine();  // Optional: Add a new line after writing
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error saving service option: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    // Handle the delivery charge logic
    if ("Delivery".equals(serviceOption)) {
        jTextField2.setText("5.00"); // Set delivery charge to 5.00
    } else {
        jTextField2.setText("0.00");  // Set delivery charge to 0.00
    }

    calculateTotalPrice();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        
    }//GEN-LAST:event_jTextField1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cart().setVisible(true);
            }
        });
    }




    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
