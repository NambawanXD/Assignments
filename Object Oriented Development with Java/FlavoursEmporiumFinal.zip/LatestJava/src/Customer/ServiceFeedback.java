/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

public class ServiceFeedback {
    private String vendor;
    private String deliveryRunner;

    public ServiceFeedback(String vendor, String deliveryRunner) {
        this.vendor = vendor;
        this.deliveryRunner = deliveryRunner;
    }

    public String getVendor() { return vendor; }
    public String getDeliveryRunner() { return deliveryRunner; }

    public void setVendor(String vendor) { this.vendor = vendor; }
    public void setDeliveryRunner(String deliveryRunner) { this.deliveryRunner = deliveryRunner; }

    @Override
    public String toString() {
        return vendor + "," + deliveryRunner;
    }
}

