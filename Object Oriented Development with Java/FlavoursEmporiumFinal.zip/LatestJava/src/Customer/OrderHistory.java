/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package flavoursemporium;

import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class OrderHistory extends javax.swing.JFrame {
    private DefaultTableModel model;
    private List<OrderDetails> orderTransactions; // ✅ Declare properly

    public OrderHistory() {
        initComponents();
        orderTransactions = new ArrayList<>(); // ✅ Initialize
        model = new DefaultTableModel(
        new String[]{"CustomerID", "OrderID", "ItemName", "Quantity", "Price", "TotalPrice", "ServiceOption", "Status"}, 0
    );
    }

    private void searchOrdersByEmail() {
        String email = EmailTextField.getText().trim().toLowerCase();
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an email to search!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Get CustomerID from customers.txt using the email
        String customerID = getCustomerIDByEmail(email);
        if (customerID == null) {
            JOptionPane.showMessageDialog(this, "No customer found with this email!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Load transactions and orders for the found CustomerID
        loadTransactions("src/txt/Transactions.txt", "src/txt/Order.txt", customerID);
    }


    /**
     * Retrieves CustomerID based on email from `customers.txt`
     */
    private String getCustomerIDByEmail(String email) {
        try (BufferedReader br = new BufferedReader(new FileReader("src/txt/customers.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3 && parts[2].trim().equalsIgnoreCase(email)) {
                    System.out.println("✅ Found CustomerID for email [" + email + "]: " + parts[0].trim());
                    return parts[0].trim(); // ✅ Return CustomerID
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading customers.txt", "Error", JOptionPane.ERROR_MESSAGE);
        }
        System.out.println("❌ No CustomerID found for email [" + email + "]");
        return null;
    }



    /**
     * Loads transactions and orders for a specific CustomerID
     */
    private void loadTransactions(String transacFile, String orderFile, String customerID) {
        orderTransactions.clear();
        Set<String> validOrders = new HashSet<>();
        Map<String, List<String[]>> orderItemsMap = new HashMap<>();
        Map<String, String> orderStatusMap = new HashMap<>();
        Map<String, String> orderServiceMap = new HashMap<>();

        System.out.println("🔍 Searching Transactions.txt for CustomerID: " + customerID);

        // ✅ Step 1: Read Transactions.txt and store valid OrderIDs
        try (BufferedReader transacReader = new BufferedReader(new FileReader(transacFile))) {
            String line;
            while ((line = transacReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 7) {
                    String orderID = parts[1].trim();
                    String transCustomerID = parts[6].trim();

                    if (transCustomerID.equals(customerID)) {
                        validOrders.add(orderID);
                        System.out.println("✅ Found OrderID [" + orderID + "] for CustomerID [" + customerID + "]");
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading transactions.txt", "Error", JOptionPane.ERROR_MESSAGE);
        }

        if (validOrders.isEmpty()) {
            System.out.println("❌ No orders found for CustomerID: " + customerID);
            return;
        } else {
            System.out.println("📌 Valid orders to search in Order.txt: " + validOrders);
        }

        // ✅ Step 2: Read Order.txt and store order details
        try (BufferedReader orderReader = new BufferedReader(new FileReader(orderFile))) {
            String line;
            String currentOrderID = null;
            String serviceOption = "Unknown";
            String status = "Pending";

            while ((line = orderReader.readLine()) != null) {
                line = line.trim();

                if (line.isEmpty()) continue; // ✅ Skip empty lines

                if (line.startsWith("ORD")) { 
                    // ✅ Detecting new Order ID and storing service & status
                    String[] parts = line.split(",");
                    if (parts.length >= 7) {
                        currentOrderID = parts[0].trim();
                        String itemName = parts[1].trim();
                        int quantity = Integer.parseInt(parts[2].trim());
                        double price = Double.parseDouble(parts[3].trim());
                        double totalPrice = Double.parseDouble(parts[4].trim());
                        serviceOption = parts[5].trim();
                        status = parts[6].split(":")[1].trim();

                        if (validOrders.contains(currentOrderID)) {
                            orderStatusMap.put(currentOrderID, status);
                            orderServiceMap.put(currentOrderID, serviceOption);
                            orderItemsMap.putIfAbsent(currentOrderID, new ArrayList<>());

                            // ✅ Directly store item details along with the OrderID
                            orderItemsMap.get(currentOrderID).add(new String[]{itemName, String.valueOf(quantity), String.valueOf(price), String.valueOf(totalPrice)});

                            System.out.println("✅ Stored Order: " + currentOrderID + " | Item: " + itemName);
                        } else {
                            currentOrderID = null; // ✅ Reset if order is not needed
                        }
                    }
                } 
                // ✅ Additional items under the same OrderID
                else if (currentOrderID != null && validOrders.contains(currentOrderID)) {
                    if (line.startsWith("Total Price")) {
                        currentOrderID = null; // ✅ Stop processing this order
                        continue;
                    }

                    String[] parts = line.split(",");
                    if (parts.length >= 5) {
                        String itemName = parts[1].trim();
                        int quantity = Integer.parseInt(parts[2].trim());
                        double price = Double.parseDouble(parts[3].trim());
                        double totalPrice = Double.parseDouble(parts[4].trim());

                        orderItemsMap.get(currentOrderID).add(new String[]{itemName, String.valueOf(quantity), String.valueOf(price), String.valueOf(totalPrice)});
                        System.out.println("✅ Added additional item to order: " + currentOrderID + " | Item: " + itemName);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading order.txt", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // ✅ Step 3: Add orders to `orderTransactions`
        System.out.println("📌 Adding orders to table...");
        for (String orderID : validOrders) {
            if (orderItemsMap.containsKey(orderID)) {
                System.out.println("📌 Processing Order: " + orderID + " with " + orderItemsMap.get(orderID).size() + " items.");

                for (String[] itemDetails : orderItemsMap.get(orderID)) {
                    String itemName = itemDetails[0];
                    int quantity = Integer.parseInt(itemDetails[1]);
                    double price = Double.parseDouble(itemDetails[2]);
                    double totalPrice = Double.parseDouble(itemDetails[3]);

                    // ✅ Ensure orders are actually added
                    orderTransactions.add(new OrderDetails(
                        customerID, orderID, itemName, quantity, price, totalPrice,
                        orderServiceMap.getOrDefault(orderID, "Unknown"),
                        orderStatusMap.getOrDefault(orderID, "Pending")
                    ));
                    System.out.println("✅ Final Order to Table: " + orderID + " | Item: " + itemName);
                }
            } else {
                System.out.println("❌ Order ID not found in Order.txt: " + orderID);
            }
        }

        System.out.println("📌 Final Orders Retrieved for Display: " + orderTransactions.size());

        // ✅ Update JTable
        updateTable();
    }

    private void updateTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // ✅ Clear previous data

        System.out.println("📌 Updating Table with Orders...");

        if (orderTransactions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No orders found for this customer!", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        for (OrderDetails order : orderTransactions) {
            model.addRow(new Object[]{
                    order.getCustomerID(),
                    order.getOrderID(),
                    order.getItemName(),
                    order.getQuantity(),
                    order.getPrice(),                    
                    order.getServiceOption(),
                    order.getStatus()
            });
            System.out.println("✅ Displaying: " + order.getOrderID() + " | " + order.getItemName());
        }
    }












    /**
     * Clears table data
     */
    private void refreshTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // ✅ Clear table
        EmailTextField.setText(""); // ✅ Clear search field
        orderTransactions.clear(); // ✅ Clear stored transaction data
    }

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        EmailTextField = new javax.swing.JTextField();
        SearchButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        RefreshButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(179, 204, 193));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton4.setText("←");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel1.setText("Search by Email:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, -1, -1));

        EmailTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmailTextFieldActionPerformed(evt);
            }
        });
        jPanel1.add(EmailTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, 284, -1));

        SearchButton.setText("🔍");
        SearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchButtonActionPerformed(evt);
            }
        });
        jPanel1.add(SearchButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 40, -1, -1));

        model = new DefaultTableModel(
            new String[]{"CustomerID", "OrderID", "ItemName", "Quantity", "Price", "ServiceOption", "Status"}, 0
        );
        jTable1.setBackground(new java.awt.Color(255, 239, 225));
        jTable1.setModel(model);
        jTable1.setSelectionBackground(new java.awt.Color(177, 103, 0));
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 647, 290));

        RefreshButton.setText("Refresh");
        RefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtonActionPerformed(evt);
            }
        });
        jPanel1.add(RefreshButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 370, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchButtonActionPerformed
        String email = EmailTextField.getText().trim().toLowerCase();
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter an email to search!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Get CustomerID from customers.txt using the email
        String customerID = getCustomerIDByEmail(email);
        if (customerID == null) {
            JOptionPane.showMessageDialog(this, "No customer found with this email!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ✅ Load transactions and orders for the found CustomerID
        loadTransactions("src/txt/Transactions.txt", "src/txt/Order.txt", customerID);
    }//GEN-LAST:event_SearchButtonActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        HomePage home = new HomePage();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void RefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtonActionPerformed
                                             
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);  // ✅ Clears table content
        EmailTextField.setText("");  // ✅ Clears email search field
        orderTransactions.clear();  // ✅ Clears stored transaction data
    
    }//GEN-LAST:event_RefreshButtonActionPerformed

    private void EmailTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmailTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_EmailTextFieldActionPerformed

  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]){
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new OrderHistory().setVisible(true);
        }
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField EmailTextField;
    private javax.swing.JButton RefreshButton;
    private javax.swing.JButton SearchButton;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
