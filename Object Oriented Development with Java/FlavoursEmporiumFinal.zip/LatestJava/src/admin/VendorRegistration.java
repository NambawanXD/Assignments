package flavoursemporium;

/**
 *
 * @author Adam JJ
 */
public class VendorRegistration {

    private String vendorID;
    private String email;
    private String password;
    private String vendorName;
    private String location;

    // Constructor
    public VendorRegistration(String vendorID, String email, String password, String vendorName, String location) {
        this.vendorID = vendorID;
        this.email = email;
        this.password = password;
        this.vendorName = vendorName;
        this.location = location;
    }

    // Getters and Setters
    public String getVendorID() {
        return vendorID;
    }

    public void setVendorID(String vendorID) {
        this.vendorID = vendorID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    // Override toString() method to represent the object as a string
    @Override
    public String toString() {
        return vendorID + "," + email + "," + password + "," + vendorName + "," + location;
    }
} 
