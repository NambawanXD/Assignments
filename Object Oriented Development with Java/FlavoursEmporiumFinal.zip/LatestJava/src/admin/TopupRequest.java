package flavoursemporium;

/**
 *
 * @author Adam JJ
 */
public class TopupRequest {

    private String customerID;
    private String email;
    private double topupAmount;
    private String status;

    // Constructor
    public TopupRequest(String customerID, String email, double topupAmount, String status) {
        this.customerID = customerID;
        this.email = email;
        this.topupAmount = topupAmount;
        this.status = status;
    }

    // Getters and Setters
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getTopupAmount() {
        return topupAmount;
    }

    public void setTopupAmount(double topupAmount) {
        this.topupAmount = topupAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Method to format data for saving to file
    public String toFileFormat() {
        return customerID + "," + email + "," + topupAmount + "," + status;
    }
}
