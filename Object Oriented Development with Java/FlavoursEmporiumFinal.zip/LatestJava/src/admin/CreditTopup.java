package flavoursemporium;
/**
 *
 * @author Adam JJ
 */
public class CreditTopup {

    private String customerID;
    private double balance;

    // Constructor
    public CreditTopup(String customerID, double balance) {
        this.customerID = customerID;
        this.balance = balance;
    }

    // Getters and Setters
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    // Method to update balance
    public void topUpBalance(double amount) {
        this.balance += amount;
    }

    // Override toString() method for file writing
    @Override
    public String toString() {
        return customerID + "," + balance;
    }
}
