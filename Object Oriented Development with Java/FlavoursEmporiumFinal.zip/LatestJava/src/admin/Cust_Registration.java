package flavoursemporium;

import java.io.*;
import javax.swing.*;
import java.util.regex.*;
import javax.swing.table.DefaultTableModel;

public class Cust_Registration extends javax.swing.JFrame {
    private DefaultTableModel model = new DefaultTableModel();
    private String[]columnName = {"CustomerID", "Name", "Email", "Password", "Contact Number", "Address"};
    private int row = -1;
    /**
     * Creates new form Cust_Registration
     */
    public Cust_Registration() {
        model.setColumnIdentifiers(columnName);
        try{
            FileReader fr = new FileReader("src/txt/customers.txt");
            BufferedReader br = new BufferedReader(fr);
            
            String line = null;
            while((line = br.readLine()) != null){
                String values[] = line.split(",");
                CustRegistration customer = new CustRegistration(values[0], values[1], values[2], values[3], values[4], values[5]);
                model.addRow(new Object[]{customer.getCustomerID(), customer.getName(), customer.getEmail(), customer.getPassword(), customer.getContactNumber(), customer.getAddress()});
            }
            
            br.close();
            fr.close();
            
        }catch(IOException e){
            e.printStackTrace();
        }
        initComponents();
    }
    
    private void saveToFile() {
    try (FileWriter writer = new FileWriter("src/txt/customers.txt")) {
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString());
                    if (j < model.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.write(System.lineSeparator());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving customer data!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void addCustomerToTopupFile(String customerID) {
        String fileName = "src/txt/topup.txt";
        String defaultBalance = "0.00"; // Default balance

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(customerID + "," + defaultBalance); // Save CustomerID with default balance
            writer.newLine();
            } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while adding CustomerID to topup.txt: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteCustomerFromTopup(String customerIDToDelete) {
        String fileName = "src/txt/topup.txt";
        StringBuilder updatedContent = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0) {
                    String currentCustomerID = parts[0].trim();
                    // Only keep lines that do not match the CustomerID to delete
                    if (!currentCustomerID.equals(customerIDToDelete)) {
                        updatedContent.append(line).append(System.lineSeparator());
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while reading the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write back the filtered content
            writer.write(updatedContent.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while updating the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateCustomerIDInTopup(String oldCustomerID, String newCustomerID) {
        String fileName = "src/txt/topup.txt";
        StringBuilder updatedContent = new StringBuilder();
        boolean isUpdated = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(","); // Split by comma (assuming "CustomerID,Balance" format)
                if (parts[0].trim().equals(oldCustomerID)) {
                    parts[0] = newCustomerID; // Update CustomerID
                    isUpdated = true;
                }
                updatedContent.append(String.join(",", parts)).append(System.lineSeparator());
            }
        } catch (IOException e) {
            return;
        }

        if (!isUpdated) {
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Write the updated content back to the file
            writer.write(updatedContent.toString());
            } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "An error occurred while updating the file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
      
    private boolean isEmailUnique(String email) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 2).toString().equalsIgnoreCase(email)) {
                return false;
            }
        }
        return true;
    }
        
    private boolean isContactNumberUnique(String contactNumber) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 4).toString().equals(contactNumber)) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(179, 204, 193));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Mshtakan", 1, 24)); // NOI18N
        jLabel5.setText("Customer Registration");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 10, 280, -1));
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 137, -1));

        jButton4.setText("Delete");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, -1, -1));
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 180, 137, -1));

        jTable1.setBackground(new java.awt.Color(255, 239, 225));
        jTable1.setModel(model);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTable1MouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 70, 566, 390));
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 280, 128, -1));

        jButton1.setText("Create");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 420, -1, -1));

        jLabel6.setText("Address:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 67, -1));

        jLabel1.setText("CustomerID:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, 74, -1));
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 330, 137, -1));

        jLabel2.setText("Name:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, 49, -1));

        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jButton2.setText("←");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        jLabel3.setText("Email:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 49, -1));

        jLabel7.setText("Password:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 67, -1));

        jLabel4.setText("Contact Number:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, -1, -1));
        jPanel1.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 128, -1));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 137, -1));

        jButton3.setText("Update");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 420, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 998, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Admin_Home ah = new Admin_Home();
        ah.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    
    private boolean isValidPassword(String password) {
    String passwordPattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
    Pattern pattern = Pattern.compile(passwordPattern);
    Matcher matcher = pattern.matcher(password);
    return matcher.matches();
    }
    
    private boolean isCustomerIDUnique(String customerID) {
    try (BufferedReader reader = new BufferedReader(new FileReader("src/txt/customers.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (data[0].equals(customerID)) {
                return false; // Duplicate found
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error reading customer data!", "Error", JOptionPane.ERROR_MESSAGE);
    }
            return true; // No duplicates
    }
    
    private boolean isCustomerIDUnique(String customerID, int selectedRow) {
    for (int i = 0; i < model.getRowCount(); i++) {
        // Skip the currently selected row
        if (i != selectedRow && model.getValueAt(i, 0).toString().equals(customerID)) {
            return false;
        }
    }
    return true;
    }
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String customerID = jTextField1.getText().trim();
        String name = jTextField2.getText().trim();
        String email = jTextField3.getText().trim();
        String password = new String(jPasswordField1.getPassword()).trim();
        String contactNumber = jTextField4.getText().trim();
        String address = jTextField5.getText().trim();
        
        // Create a CustRegistration object
        CustRegistration customer = new CustRegistration(customerID, name, email, password, contactNumber, address);
        
        if (!isCustomerIDUnique(customerID)) {
        JOptionPane.showMessageDialog(this, "CustomerID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        // Validation
        if (customerID.isEmpty() || name.isEmpty() || email.isEmpty() ||  password.isEmpty() || contactNumber.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!contactNumber.matches("\\d{10,11}")) {
        JOptionPane.showMessageDialog(this, "Contact number must be 10 to 11 digits!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        if (!isValidPassword(password)) {
        JOptionPane.showMessageDialog(this, "Password must be at least 8 characters long and include:\n"
                + "- At least one uppercase letter\n"
                + "- At least one number\n"
                + "- At least one special character", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        // Check for unique email and password
        if (!isEmailUnique(email)) {
            JOptionPane.showMessageDialog(this, "Email already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!isContactNumberUnique(contactNumber)) {
            JOptionPane.showMessageDialog(this, "Contact number already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Add customer to the table
        String[] values = {customer.getCustomerID(), customer.getName(), customer.getEmail(), customer.getPassword(), customer.getContactNumber(), customer.getAddress()};
        model.addRow(values);
        saveToFile();
        
        if (customerID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "CustomerID is required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(this, "Customer details created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        // Add customer to topup file
        addCustomerToTopupFile(customer.getCustomerID());
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jPasswordField1.setText("");
        jTextField4.setText("");
        jTextField5.setText("");     
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Check if a row is selected
        int selectedRow = jTable1.getSelectedRow(); // Assuming 'jTable1' is the table variable
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a customer before updating data!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String oldCustomerID = model.getValueAt(selectedRow, 0).toString(); // Get the old CustomerID
        String customerID = jTextField1.getText().trim();
        String name = jTextField2.getText().trim();
        String email = jTextField3.getText().trim();
        String password = new String(jPasswordField1.getPassword()).trim();
        String contactNumber = jTextField4.getText().trim();
        String address = jTextField5.getText().trim();
        
        // Create a CustRegistration object
        CustRegistration customer = new CustRegistration(customerID, name, email, password, contactNumber, address);
        
        // Validation: Check unique CustomerID
        if (!isCustomerIDUnique(customerID,selectedRow)) {
        JOptionPane.showMessageDialog(this, "CustomerID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        // Validation
        
        if (customerID.isEmpty() || name.isEmpty() || email.isEmpty() ||  password.isEmpty() || contactNumber.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
            JOptionPane.showMessageDialog(this, "Invalid email format!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Check if email is unique
        for (int i = 0; i < model.getRowCount(); i++) {
            if (i != selectedRow && model.getValueAt(i, 2).toString().equalsIgnoreCase(email)) {
                JOptionPane.showMessageDialog(this, "Email already exists in another record!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        if (!contactNumber.matches("\\d{10,11}")) {
        JOptionPane.showMessageDialog(this, "Contact number must be 10 to 11 digits!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
        
        // Check if contact number is unique
        for (int i = 0; i < model.getRowCount(); i++) {
            if (i != selectedRow && model.getValueAt(i, 4).toString().equals(contactNumber)) {
                JOptionPane.showMessageDialog(this, "Contact number already exists in another record!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
    
        if (!isValidPassword(password)) {
        JOptionPane.showMessageDialog(this, "Password must be at least 8 characters long and include:\n"
                + "- At least one uppercase letter\n"
                + "- At least one number\n"
                + "- At least one special character", "Error", JOptionPane.ERROR_MESSAGE);
        return;
        }
    
        // Update the table
        String[] values = {customer.getCustomerID(), customer.getName(), customer.getEmail(), customer.getPassword(), customer.getContactNumber(), customer.getAddress()};
        model.removeRow(selectedRow);
        model.insertRow(selectedRow, values);
        saveToFile();
        
        // Update CustomerID in topup.txt
        if (!oldCustomerID.equals(customer.getCustomerID())) {
            updateCustomerIDInTopup(oldCustomerID, customer.getCustomerID());
        }
    
        JOptionPane.showMessageDialog(this, "Customer details updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jPasswordField1.setText("");
        jTextField4.setText("");
        jTextField5.setText("");  
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // Check if a row is selected
        int selectedRow = jTable1.getSelectedRow(); // Assuming 'jTable1' is the table variable
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a customer before deleting data!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (row >= 0) {
          model.removeRow(row);
          saveToFile();
            JOptionPane.showMessageDialog(this, "Customer deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            row = -1;
        } else {
            JOptionPane.showMessageDialog(this, "No row selected!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        String customerID = jTextField1.getText().trim();
        if (customerID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Customer ID is missing!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Call the method to delete customer from topup.txt
        deleteCustomerFromTopup(customerID);
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jPasswordField1.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jTable1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseReleased
        row = jTable1.getSelectedRow();
        
        String customerID = String.valueOf(model.getValueAt(row, 0));
        String name = String.valueOf(model.getValueAt(row, 1));
        String email = String.valueOf(model.getValueAt(row, 2));
        String password = String.valueOf(model.getValueAt(row, 3));
        String contactNumber = String.valueOf(model.getValueAt(row, 4));
        String address = String.valueOf(model.getValueAt(row, 5));
        
        jTextField1.setText(customerID);
        jTextField2.setText(name);
        jTextField3.setText(email);
        jPasswordField1.setText(password);
        jTextField4.setText(contactNumber);
        jTextField5.setText(address);
    }//GEN-LAST:event_jTable1MouseReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cust_Registration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cust_Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}