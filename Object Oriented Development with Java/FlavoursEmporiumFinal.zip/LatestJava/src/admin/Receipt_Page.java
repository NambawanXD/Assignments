package flavoursemporium;

import java.io.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Receipt_Page extends javax.swing.JFrame {

    private static final String RECEIPT_FILE = "src/txt/receipt.txt";
    
    /**
     * Creates new form Receipt_Page
     */
    private static final String CUSTOMERS_FILE = "src/txt/customers.txt";
    
    public Receipt_Page(String customerID, double topUpAmount, double currentBalance) {
        initComponents();

        // Debugging - Print received values
        System.out.println("DEBUG: Received customerID = " + customerID);
        System.out.println("DEBUG: Received topUpAmount = " + topUpAmount);
        System.out.println("DEBUG: Received currentBalance BEFORE top-up = " + currentBalance);

        // Generate unique ReceiptID
        String receiptID = generateNextReceiptID();
        jTextField1.setText(receiptID);

        // Fetch customer details
        String[] customerDetails = fetchCustomerDetails(customerID);
        String customerName = (customerDetails != null) ? customerDetails[0] : "Unknown";
        String contactNumber = (customerDetails != null) ? customerDetails[1] : "Unknown";

        // ✅ Correct balance calculation (Only update once)
        double updatedBalance = currentBalance + topUpAmount;

        // ✅ Set UI text fields
        jTextField3.setText(customerID);
        jTextField2.setText(new DecimalFormat("0.00").format(topUpAmount));
        jTextField4.setText(new DecimalFormat("0.00").format(updatedBalance));
        jTextField5.setText(customerName);
        jTextField6.setText(contactNumber);

        // Get current date and time
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String date = now.format(dateFormatter);
        String time = now.format(timeFormatter);

        jLabel5.setText(date);
        jLabel6.setText(time);

        // ✅ Create Receipt object
        Receipt receipt = new Receipt(receiptID, customerID, customerName, contactNumber, topUpAmount, updatedBalance, date, time);

        // ✅ Debugging to verify balance correctness
        System.out.println("DEBUG: Receipt - Updated Balance: " + receipt.getUpdatedBalance());

        // ✅ Save receipt data once
        saveReceiptData(receipt);
    }

    private String[] fetchCustomerDetails(String customerID) {
        try (BufferedReader reader = new BufferedReader(new FileReader(CUSTOMERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(","); // Assuming the file format is: customerID,customerName,contactNumber
                if (parts.length > 2 && parts[0].trim().equals(customerID.trim())) {
                    return new String[]{parts[1].trim(), parts[4].trim()}; // Return the customer name and contact number
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading customer file: " + e.getMessage());
        }
        return null; // Return null if no match is found
    }
    
    private String generateNextReceiptID() {
        int maxReceiptNumber = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader(RECEIPT_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length > 0 && parts[0].startsWith("RC")) {
                    String numberPart = parts[0].substring(2); // Extract numeric part
                    try {
                        int receiptNumber = Integer.parseInt(numberPart);
                        maxReceiptNumber = Math.max(maxReceiptNumber, receiptNumber);
                    } catch (NumberFormatException e) {
                        // Ignore invalid receipt IDs
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read receipt file: " + e.getMessage());
        }

        // Increment and format as RC###
        return "RC" + String.format("%03d", maxReceiptNumber + 1);
    }
    
    private void saveReceiptData(Receipt receipt) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RECEIPT_FILE, true))) {
            writer.write(receipt.toFileFormat());
            writer.newLine(); // Add a new line after each receipt entry
        } catch (IOException e) {

        }
    }
    
    
    
    // Rest of your Receipt_Page class code remains the same
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(179, 204, 193));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Mshtakan", 1, 24)); // NOI18N
        jLabel1.setText("Official Receipt");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 10, -1, -1));

        jTextField1.setEditable(false);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 121, -1));

        jTextField2.setEditable(false);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, 121, -1));

        jTextField3.setEditable(false);
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 220, 121, -1));

        jTextField4.setEditable(false);
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 121, -1));

        jLabel2.setText("Top-up Amount:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 120, -1, -1));

        jLabel8.setText("Customer Name:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 270, 90, -1));

        jLabel3.setText("Updated Balance:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 100, -1));

        jTextField5.setEditable(false);
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 270, 121, -1));

        jLabel4.setText("CustomerID:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, -1, -1));

        jLabel9.setText("Contact Number:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 320, 100, -1));

        jLabel5.setText("Date");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 390, 76, -1));
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 320, 121, -1));

        jLabel6.setText("Time");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 390, 76, -1));

        jLabel7.setText("ReceiptID:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, -1, -1));

        jButton1.setText("Send Notification");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 390, -1, -1));

        jButton2.setText("←");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        Credit_Topup ct = new Credit_Topup();
        ct.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private static final String NOTIFICATIONS_FILE = "src/txt/notifications.txt";

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Retrieve values from text fields
    String receiptID = jTextField1.getText();
    String customerID = jTextField3.getText();
    String customerName = jTextField5.getText();
    double topUpAmount = Double.parseDouble(jTextField2.getText());
    double updatedBalance = Double.parseDouble(jTextField4.getText());
    String date = jLabel5.getText();
    String time = jLabel6.getText();
    
     Receipt receipt = new Receipt(receiptID, customerID, customerName, "", topUpAmount, updatedBalance, date, time);
     
    // Create the notification message
    String notificationMessage = "Dear " + customerName + " (ID: " + customerID + "), "
            + "your top-up of RM" + topUpAmount + " has been processed successfully on " 
            + date + " at " + time + ". Your new balance is RM" + updatedBalance + ".";

    // Append to notifications.txt
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(NOTIFICATIONS_FILE, true))) {
        writer.write(receipt.generateNotificationMessage());
        writer.newLine(); // Move to the next line for next entry
        javax.swing.JOptionPane.showMessageDialog(this, "Notification sent successfully!", "Success", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        javax.swing.JOptionPane.showMessageDialog(this, "Error saving notification: " + e.getMessage(), "Error", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Receipt_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Receipt_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Receipt_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Receipt_Page.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Receipt_Page("", 0,0).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
