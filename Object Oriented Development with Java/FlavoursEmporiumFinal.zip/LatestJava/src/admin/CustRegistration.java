package flavoursemporium;

/**
 *
 * @author Adam JJ
 */
public class CustRegistration {
    private String customerID;
    private String name;
    private String email;
    private String password;
    private String contactNumber;
    private String address;

    // Constructor
    public CustRegistration(String customerID, String name, String email, String password, String contactNumber, String address) {
        this.customerID = customerID;
        this.name = name;
        this.email = email;
        this.password = password;
        this.contactNumber = contactNumber;
        this.address = address;
    }

    // Getters and Setters
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Override toString() method to represent the object as a string
    @Override
    public String toString() {
        return customerID + "," + name + "," + email + "," + password + "," + contactNumber + "," + address;
    }
}
