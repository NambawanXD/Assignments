package flavoursemporium;

/**
 *
 * @author Adam JJ
 */
public class RunnerRegistration {

    private String runnerID;
    private String email;
    private String password;
    private String runnerName;

    // Constructor
    public RunnerRegistration(String runnerID, String email, String password, String runnerName) {
        this.runnerID = runnerID;
        this.email = email;
        this.password = password;
        this.runnerName = runnerName;
    }

    // Getters and Setters
    public String getRunnerID() {
        return runnerID;
    }

    public void setRunnerID(String runnerID) {
        this.runnerID = runnerID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRunnerName() {
        return runnerName;
    }

    public void setRunnerName(String runnerName) {
        this.runnerName = runnerName;
    }

    // Override toString() method for easy display
    @Override
    public String toString() {
        return runnerID + "," + email + "," + password + "," + runnerName;
    }
}
