package flavoursemporium;

import java.text.DecimalFormat;
/**
 *
 * @author Adam JJ
 */
public class Receipt {

    private String receiptID;
    private String customerID;
    private String customerName;
    private String contactNumber;
    private double topUpAmount;
    private double updatedBalance;
    private String date;
    private String time;

    // Constructor
    public Receipt(String receiptID, String customerID, String customerName, String contactNumber, double topUpAmount, double updatedBalance, String date, String time) {
        this.receiptID = receiptID;
        this.customerID = customerID;
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.topUpAmount = topUpAmount;
        this.updatedBalance = updatedBalance;
        this.date = date;
        this.time = time;
    }

    // Getters and Setters
    public String getReceiptID() {
        return receiptID;
    }

    public void setReceiptID(String receiptID) {
        this.receiptID = receiptID;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public double getTopUpAmount() {
        return topUpAmount;
    }

    public void setTopUpAmount(double topUpAmount) {
        this.topUpAmount = topUpAmount;
    }

    public double getUpdatedBalance() {
        return updatedBalance;
    }

    public void setUpdatedBalance(double updatedBalance) {
        this.updatedBalance = updatedBalance;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    // Method to format receipt data for saving to file
    public String toFileFormat() {
        DecimalFormat df = new DecimalFormat("0.00");
        return receiptID + "," +
               df.format(topUpAmount) + "," +
               df.format(updatedBalance) + "," +
               customerID + "," +
               customerName + "," +
               contactNumber + "," +
               date + "," +
               time;
    }

    // Method to generate notification message
    public String generateNotificationMessage() {
        return "Dear " + customerName + " (ID: " + customerID + "), " +
               "your top-up of RM" + new DecimalFormat("0.00").format(topUpAmount) + " has been processed successfully on " +
               date + " at " + time + ". Your new balance is RM" + new DecimalFormat("0.00").format(updatedBalance) + ".";
    }
}
