/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;

/**
 *
 * @author anushadevybrahmataran
 */
public class VendorUser extends User{
    public VendorUser(String name, String email, String password){
        super(name, email, password);
        setRole("Vendor");
    }
    
    @Override
    public String getRole(){
        return "Vendor";
    }
}
