/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flavoursemporium;
/**
 *
 * @author anushadevybrahmataran
 */
public class CustomerUser extends User{
    public CustomerUser(String name, String email, String password){
        super(name, email, password);
        setRole("Customer");
    }
    
    @Override
    public String getRole(){
        return "Customer";
    }
}
